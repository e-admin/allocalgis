package es.satec.localgismobile.fw.net.communications.core;


public class Constantes {

	public static int CONNECTION_TIMEOUT=32;

}


