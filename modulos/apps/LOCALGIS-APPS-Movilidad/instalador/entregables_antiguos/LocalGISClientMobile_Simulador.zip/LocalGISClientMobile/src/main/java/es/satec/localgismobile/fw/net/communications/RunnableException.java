package es.satec.localgismobile.fw.net.communications;




public interface RunnableException   {



	public Object run () throws Exception ;
	
	

}