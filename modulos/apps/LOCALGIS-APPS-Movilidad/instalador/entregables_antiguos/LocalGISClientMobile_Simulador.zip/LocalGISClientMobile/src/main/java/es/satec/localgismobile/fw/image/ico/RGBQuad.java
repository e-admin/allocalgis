package es.satec.localgismobile.fw.image.ico;

public class RGBQuad {
	byte red;
	byte green;
	byte blue;
}
