package es.satec.localgismobile.ui.screens;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import org.apache.log4j.Logger;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import com.tinyline.svg.SVGChangeEvent;
import com.tinyline.svg.SVGNode;

import es.satec.localgismobile.fw.Global;
import es.satec.localgismobile.fw.Messages;
import es.satec.svgviewer.localgis.MetaInfo;

public class MetaInfoListScreenComposite extends Composite {

	private static final String ATT_NUM_BIENES = "N�mero de Bienes";
	private MetaInfoScreen screenMetaInfo;
	private SVGNode currentNode;
	private MetaInfo metaInfo;
	private Hashtable params;
	
	private Table table;

	private static final String ACTION_BUTTON_ADD = "ADD";
	private static final String ACTION_BUTTON_UPDATE = "UPDATE";
	private static final String ACTION_BUTTON_DELETE = "DELETE";
	private static final String ACTION_BUTTON_VIEW= "VIEW";
	
	private boolean editable=false;
	
	private static Logger logger = Global.getLoggerFor(MetaInfoListScreenComposite.class);

	public MetaInfoListScreenComposite(MetaInfoScreen screenMetaInfo, SVGNode currentNode, MetaInfo metaInfo, Hashtable params) {
		super(screenMetaInfo.getShell(), SWT.NONE);
		this.screenMetaInfo = screenMetaInfo;
		this.currentNode = currentNode;
		this.metaInfo = metaInfo;
		this.params = params;
		this.editable=currentNode.parent.editable;
		initialize();
	}

	private void initialize() {
		setLayout(new GridLayout());
		
		String titleKey = (String) params.get("title");
		if (titleKey != null) {
			String title = Messages.getMessage(titleKey);
			Label titleLabel = new Label(this, SWT.NONE);
			titleLabel.setText(title);
			screenMetaInfo.getShell().setText(title);
		}

		table = new Table(this, SWT.BORDER | SWT.FULL_SELECTION | SWT.V_SCROLL | SWT.H_SCROLL);
		table.setHeaderVisible(true);
		GridData gridData = new GridData();
		gridData.horizontalAlignment = GridData.FILL;
		gridData.grabExcessHorizontalSpace = true;
		gridData.grabExcessVerticalSpace = true;
		gridData.verticalAlignment = GridData.FILL;
		table.setLayoutData(gridData);
		
		loadTable();

		Composite buttonsComposite = new Composite(this, SWT.NONE);
		GridData gridData2 = new GridData();
		gridData2.horizontalAlignment = GridData.CENTER;
		gridData2.verticalAlignment = GridData.CENTER;
		buttonsComposite.setLayoutData(gridData2);
		RowLayout rowLayout = new RowLayout();
		buttonsComposite.setLayout(rowLayout);
		
		String actions = (String) params.get("actions");
		if (actions != null) {
			if ((actions.indexOf(ACTION_BUTTON_ADD) != -1) && (editable)) {
				Button addButton = new Button(buttonsComposite, SWT.NONE);
				addButton.setText(Messages.getMessage("MetaInfoScreen.buttons.add"));
				addButton.addSelectionListener(new SelectionListener() {
					public void widgetSelected(SelectionEvent arg0) {
						addItem();
					}

					public void widgetDefaultSelected(SelectionEvent arg0) {
					}
				});
			}
			if ((actions.indexOf(ACTION_BUTTON_UPDATE) != -1) && (editable)) {
				Button updateButton = new Button(buttonsComposite, SWT.NONE);
				updateButton.setText(Messages.getMessage("MetaInfoScreen.buttons.update"));
				updateButton.addSelectionListener(new SelectionListener() {
					public void widgetSelected(SelectionEvent arg0) {
						updateItem();
					}

					public void widgetDefaultSelected(SelectionEvent arg0) {
					}
				});
			}
			if (actions.indexOf(ACTION_BUTTON_VIEW) != -1) {
				Button viewButton = new Button(buttonsComposite, SWT.NONE);
				viewButton.setText(Messages.getMessage("MetaInfoScreen.buttons.view"));
				viewButton.addSelectionListener(new SelectionListener() {
					public void widgetSelected(SelectionEvent arg0) {
						viewItem();
					}

					public void widgetDefaultSelected(SelectionEvent arg0) {
					}
				});
			}
			if ((actions.indexOf(ACTION_BUTTON_DELETE) != -1) && (editable)) {
				Button deleteButton = new Button(buttonsComposite, SWT.NONE);
				deleteButton.setText(Messages.getMessage("MetaInfoScreen.buttons.delete"));
				deleteButton.addSelectionListener(new SelectionListener() {
					public void widgetSelected(SelectionEvent arg0) {
						deleteItem();
					}

					public void widgetDefaultSelected(SelectionEvent arg0) {
					}
				});
			}
		}
	}

	private void loadTable() {
		table.removeAll();

		// Obtener nodos con la metainformacion
		Vector metaInfoNodes = null;
		try {
			int pos = currentNode.parent.getPosByNameLayertAtt(metaInfo.getKeyAttribute());
			String idFeature = currentNode.getValueLayertAtt(pos);
			metaInfoNodes = metaInfo.getElementsByIdFeature(idFeature);
			SVGNode parent = metaInfo.getMetaInfoLayerElement();

			if (parent != null && parent.nameAtts != null) {
				
				if (table.getColumnCount() == 0) {
					Enumeration e = parent.nameAtts.elements();
					while (e.hasMoreElements()) {
						TableColumn column = new TableColumn(table, SWT.NONE);
						column.setText((String) e.nextElement());
						column.pack();
					}
				}
				
				if (metaInfoNodes != null) {
					Enumeration e = metaInfoNodes.elements();
					while (e.hasMoreElements()) {
						SVGNode metaInfoNode = (SVGNode) e.nextElement();
						// Filtrar los marcados para eliminar
						if (metaInfoNode.changeEvent != null &&
							(metaInfoNode.changeEvent.getChangeType() & SVGChangeEvent.CHANGE_TYPE_DELETED) != 0)
							continue;
						TableItem tableItem = new TableItem(table, SWT.CENTER);
						tableItem.setData(metaInfoNode);
						for (int i=0; i<metaInfoNode.nameAtts.size(); i++) {
							tableItem.setText(i, (String) metaInfoNode.nameAtts.elementAt(i));
						}
					}
					
					//en inventario de patrimonio para el repintado del nodo seg�n el n�mero de bienes
					int numAttBienes = currentNode.parent.getPosByNameLayertAtt(ATT_NUM_BIENES);
					if(numAttBienes>=0){
						String metadataSize = String.valueOf(table.getItemCount());
						currentNode.setExtendedAttributeAndRecordEvent(numAttBienes, metadataSize);
						//para evitar que se env�e el nodo
						currentNode.changeEvent = null;
						//para inventario de calles propagamos la informaci�n del nodo para el resto de nodos del mismo grupo
						int featGroup = currentNode.getGroup();
						if(featGroup!=-1){
							Object[] nodeList = currentNode.parent.children.data;
							SVGNode nodeChild = null;
							Vector nameAtts = currentNode.nameAtts;
							for (int i = 0; i < nodeList.length; i++) {
								nodeChild = (SVGNode) nodeList[i];
								if(nodeChild!=null && !currentNode.equals(nodeChild) && nodeChild.getGroup()==featGroup){
									//igualamos cada nodo a los del nodo actual
									for (int j = 0; j < nameAtts.size(); j++) {
										try {
											nodeChild.setExtendedAttributeAndRecordEvent(j, (String) nameAtts.get(j));
										} catch (Exception e2) {
											logger.error("Error al igualar el nodo " + currentNode + " :" +e2, e2);
										}
									}		
									nodeChild.changeEvent = null;
								}
							}
						}
					}
					
				}
			}
			
			
		} catch (Exception e) {
			logger.error("Error al obtener los nodos de metainformacion", e);
		}
	}

	private void addItem() {
		try {
			SVGNode prototype = metaInfo.getPrototypeElement();
			// Clonar el prototipo con sus metadatos
			SVGNode newElem = prototype.copyExtendedNode();
			// Copiar la geometria
			currentNode.copyGeometryTo(newElem);

			// Rellenar el id de la feature
			int pos = currentNode.parent.getPosByNameLayertAtt(metaInfo.getKeyAttribute());
			String idFeature = (String) currentNode.nameAtts.elementAt(pos);
			pos = prototype.parent.getPosByNameLayertAtt(metaInfo.getKeyAttribute());
			newElem.nameAtts.setElementAt(idFeature, pos);
			
			screenMetaInfo.goDetail(newElem, prototype.parent,true,true);
		} catch (Exception e) {
			logger.error("Error al crear nuevo elemento", e);
			MessageBox mb = new MessageBox(screenMetaInfo.getShell(), SWT.ICON_ERROR | SWT.OK);
			mb.setMessage(Messages.getMessage("MetaInfoScreen.errorAdd"));
			mb.open();
		}
	}
	
	private void updateItem() {
		if (table.getSelectionCount() == 0) {
			MessageBox mb = new MessageBox(screenMetaInfo.getShell(), SWT.ICON_WARNING | SWT.OK);
			mb.setMessage(Messages.getMessage("MetaInfoScreen.noSelection"));
			mb.open();
		}
		else {
			SVGNode selectedNode = (SVGNode) table.getSelection()[0].getData();
			screenMetaInfo.goDetail(selectedNode, null,false,true);
		}
	}
	private void viewItem() {
		if (table.getSelectionCount() == 0) {
			MessageBox mb = new MessageBox(screenMetaInfo.getShell(), SWT.ICON_WARNING | SWT.OK);
			mb.setMessage(Messages.getMessage("MetaInfoScreen.noSelection"));
			mb.open();
		}
		else {
			SVGNode selectedNode = (SVGNode) table.getSelection()[0].getData();
			screenMetaInfo.goDetail(selectedNode, null,false,false);
		}
	}
	
	private void deleteItem() {
		if (table.getSelectionCount() == 0) {
			MessageBox mb = new MessageBox(screenMetaInfo.getShell(), SWT.ICON_WARNING | SWT.OK);
			mb.setMessage(Messages.getMessage("MetaInfoScreen.noSelection"));
			mb.open();
		}
		else {
			SVGNode selectedNode = (SVGNode) table.getSelection()[0].getData();
			SVGNode parent = selectedNode.parent;
			if (parent != null) {
				int pos = parent.children.indexOf(selectedNode, 0);
				if (pos != -1) {
					parent.removeChildAndRecordEvent(pos);
					loadTable();
				}
			}
		}
	}
}
