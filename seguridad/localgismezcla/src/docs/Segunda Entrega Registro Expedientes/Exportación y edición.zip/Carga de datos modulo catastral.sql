

insert into Domains (ID, NAME,ID_CATEGORY)values(10054,'C�digo de valor base','3');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(402,'es_ES','C�digo de valor base');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(790,'10054','?',402,4,null,null);
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(403,'es_ES','Aplicaci�n del coeficiente de incremento medio');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(791,'10054','M',403,7,null,'790');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(404,'es_ES','Incorporaci�n del suelo V.B=0');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(792,'10054','S',404,7,null,'790');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(405,'es_ES','Base liquidable anterior fijado por el agente colaborador');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(793,'10054','I',405,7,null,'790');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(406,'es_ES','Base liquidable anterior');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(794,'10054','V',406,7,null,'790');
insert into Domains (ID, NAME,ID_CATEGORY)values(10055,'Categor�a de construcci�n','3');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(407,'es_ES','Categor�a de construcci�n');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(795,'10055','?',407,4,null,null);
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(408,'es_ES','9');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(796,'10055','9',408,7,null,'795');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(409,'es_ES','8');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(797,'10055','8',409,7,null,'795');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(410,'es_ES','7');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(798,'10055','7',410,7,null,'795');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(411,'es_ES','6');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(799,'10055','6',411,7,null,'795');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(412,'es_ES','5');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(800,'10055','5',412,7,null,'795');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(413,'es_ES','4');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(801,'10055','4',413,7,null,'795');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(414,'es_ES','3');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(802,'10055','3',414,7,null,'795');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(415,'es_ES','2');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(803,'10055','2',415,7,null,'795');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(416,'es_ES','1');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(804,'10055','1',416,7,null,'795');
delete from dictionary where id_vocablo='407';
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values('407','es_ES','Categor�a de construcci�n');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values('407','ga_ES','[gl]Categor�a de construcci�n');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values('407','va_ES','[va]Categor�a de construcci�n');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values('407','eu_ES','[eu]Categor�a de construcci�n');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values('407','ca_ES','[cat]Categor�a de construcci�n');
update domainnodes set pattern='?', id_description='407' where id='795';
delete from dictionary where id_vocablo='402';
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values('402','es_ES','C�digo de valor base');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values('402','ga_ES','[gl]C�digo de valor base');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values('402','va_ES','[va]C�digo de valor base');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values('402','eu_ES','[eu]C�digo de valor base');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values('402','ca_ES','[cat]C�digo de valor base');
update domainnodes set pattern='?', id_description='402' where id='790';
insert into Domains (ID, NAME,ID_CATEGORY)values(10056,'Tipo de subparcela','3');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(417,'es_ES','Tipo de subparcela');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(417,'ga_ES','[gl]Tipo de subparcela');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(417,'va_ES','[va]Tipo de subparcela');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(417,'eu_ES','[eu]Tipo de subparcela');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(417,'ca_ES','[cat]Tipo de subparcela');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(805,'10056','?',417,4,null,null);
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(418,'es_ES','A');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(806,'10056','A',418,7,null,'805');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(419,'es_ES','T');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(807,'10056','T',419,7,null,'805');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(432,'es_ES','D');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(808,'10056','D',432,7,null,'805');
insert into Domains (ID, NAME,ID_CATEGORY)values(10057,'Naturaleza del suelo','3');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(433,'es_ES','Naturaleza del suelo');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(433,'ga_ES','[gl]Naturaleza del suelo');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(433,'va_ES','[va]Naturaleza del suelo');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(433,'eu_ES','[eu]Naturaleza del suelo');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(433,'ca_ES','[cat]Naturaleza del suelo');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(809,'10057','',433,4,null,null);
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(434,'es_ES','Urbano');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(434,'ga_ES','[gl]Urbano');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(434,'va_ES','[va]Urbano');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(434,'eu_ES','[eu]Urbano');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(434,'ca_ES','[cat]Urbano');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(810,'10057','UR',434,7,null,'809');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(435,'es_ES','Bien Inmueble de Caracter�sticas Especiales');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(811,'10057','BI',435,7,null,'809');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(436,'es_ES','R�stico');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(436,'ga_ES','[gl]R�stico');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(436,'va_ES','[va]R�stico');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(436,'eu_ES','[eu]R�stico');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(436,'ca_ES','[cat]R�stico');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(812,'10057','RU',436,7,null,'809');
insert into Domains (ID, NAME,ID_CATEGORY)values(10058,'C�digo de bonificaci�n','3');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(437,'es_ES','C�digo de bonificaci�n');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(437,'ga_ES','[gl]C�digo de bonificaci�n');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(437,'va_ES','[va]C�digo de bonificaci�n');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(437,'eu_ES','[eu]C�digo de bonificaci�n');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(437,'ca_ES','[cat]C�digo de bonificaci�n');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(813,'10058','',437,4,null,null);
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(438,'es_ES','A');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(814,'10058','A',438,7,null,'813');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(439,'es_ES','L');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(815,'10058','L',439,7,null,'813');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(440,'es_ES','J');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(816,'10058','J',440,7,null,'813');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(441,'es_ES','R');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(817,'10058','R',441,7,null,'813');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(442,'es_ES','C');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(818,'10058','C',442,7,null,'813');
insert into Domains (ID, NAME,ID_CATEGORY)values(10059,'Tipo de derecho de titularidad','3');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(443,'es_ES','Tipo de derecho de titularidad');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(443,'ga_ES','[gl]Tipo de derecho de titularidad');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(443,'va_ES','[va]Tipo de derecho de titularidad');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(443,'eu_ES','[eu]Tipo de derecho de titularidad');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(443,'ca_ES','[cat]Tipo de derecho de titularidad');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(819,'10059','',443,4,null,null);
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(444,'es_ES','Concesi�n Administrativa');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(444,'ga_ES','[gl]Concesi�n Administrativa');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(444,'va_ES','[va]Concesi�n Administrativa');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(444,'eu_ES','[eu]Concesi�n Administrativa');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(444,'ca_ES','[cat]Concesi�n Administrativa');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(820,'10059','CA',444,7,null,'819');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(445,'es_ES','Derecho de Superficie');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(445,'ga_ES','[gl]Derecho de Superficie');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(445,'va_ES','[va]Derecho de Superficie');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(445,'eu_ES','[eu]Derecho de Superficie');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(445,'ca_ES','[cat]Derecho de Superficie');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(821,'10059','DS',445,7,null,'819');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(446,'es_ES','Propiedad');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(446,'ga_ES','[gl]Propiedad');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(446,'va_ES','[va]Propiedad');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(446,'eu_ES','[eu]Propiedad');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(446,'ca_ES','[cat]Propiedad');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(822,'10059','PR',446,7,null,'819');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(447,'es_ES','Disfrutador');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(447,'ga_ES','[gl]Disfrutador');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(447,'va_ES','[va]Disfrutador');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(447,'eu_ES','[eu]Disfrutador');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(447,'ca_ES','[cat]Disfrutador');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(823,'10059','DF',447,7,null,'819');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(448,'es_ES','Nuda Propiedad');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(448,'ga_ES','[gl]Nuda Propiedad');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(448,'va_ES','[va]Nuda Propiedad');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(448,'eu_ES','[eu]Nuda Propiedad');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(448,'ca_ES','[cat]Nuda Propiedad');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(824,'10059','NP',448,7,null,'819');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(449,'es_ES','Usufructo');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(449,'ga_ES','[gl]Usufructo');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(449,'va_ES','[va]Usufructo');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(449,'eu_ES','[eu]Usufructo');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(449,'ca_ES','[cat]Usufructo');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(825,'10059','US',449,7,null,'819');
  
update domainnodes set pattern='?', id_description='433' where id='809';
update domainnodes set pattern='?', id_description='437' where id='813';
update domainnodes set pattern='?', id_description='443' where id='819';


insert into Domains (ID, NAME,ID_CATEGORY)values(10060,'Forma de reparto','3');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(450,'es_ES','Forma de reparto');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(450,'ga_ES','[gl]Forma de reparto');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(450,'va_ES','[va]Forma de reparto');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(450,'eu_ES','[eu]Forma de reparto');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(450,'ca_ES','[cat]Forma de reparto');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(826,'10060','?',450,4,null,null);
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(451,'es_ES','A todos,  a locales');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(451,'ga_ES','[gl]A todos,  a locales');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(451,'va_ES','[va]A todos,  a locales');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(451,'eu_ES','[eu]A todos,  a locales');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(451,'ca_ES','[cat]A todos,  a locales');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(827,'10060','TL',451,7,null,'826');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(452,'es_ES','A alguno,  a cargos');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(452,'ga_ES','[gl]A alguno,  a cargos');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(452,'va_ES','[va]A alguno,  a cargos');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(452,'eu_ES','[eu]A alguno,  a cargos');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(452,'ca_ES','[cat]A alguno,  a cargos');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(828,'10060','AC',452,7,null,'826');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(453,'es_ES','A alguno,  a locales');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(453,'ga_ES','[gl]A alguno,  a locales');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(453,'va_ES','[va]A alguno,  a locales');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(453,'eu_ES','[eu]A alguno,  a locales');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(453,'ca_ES','[cat]A alguno,  a locales');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(829,'10060','AL',453,7,null,'826');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(454,'es_ES','A todos,  a cargos');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(454,'ga_ES','[gl]A todos,  a cargos');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(454,'va_ES','[va]A todos,  a cargos');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(454,'eu_ES','[eu]A todos,  a cargos');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(454,'ca_ES','[cat]A todos,  a cargos');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(830,'10060','TC',454,7,null,'826');
insert into Domains (ID, NAME,ID_CATEGORY)values(10061,'Proporci�n de reparto','3');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(455,'es_ES','Proporci�n de reparto');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(455,'ga_ES','[gl]Proporci�n de reparto');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(455,'va_ES','[va]Proporci�n de reparto');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(455,'eu_ES','[eu]Proporci�n de reparto');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(455,'ca_ES','[cat]Proporci�n de reparto');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(831,'10061','?',455,4,null,null);
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(456,'es_ES','Por coeficientes de propiedad');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(456,'ga_ES','[gl]Por coeficientes de propiedad');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(456,'va_ES','[va]Por coeficientes de propiedad');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(456,'eu_ES','[eu]Por coeficientes de propiedad');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(456,'ca_ES','[cat]Por coeficientes de propiedad');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(832,'10061','3',456,7,null,'831');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(457,'es_ES','Por coeficientes espec�ficamente determinados');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(457,'ga_ES','[gl]Por coeficientes espec�ficamente determinados');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(457,'va_ES','[va]Por coeficientes espec�ficamente determinados');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(457,'eu_ES','[eu]Por coeficientes espec�ficamente determinados');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(457,'ca_ES','[cat]Por coeficientes espec�ficamente determinados');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(833,'10061','4',457,7,null,'831');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(458,'es_ES','Por superficie de los locales');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(458,'ga_ES','[gl]Por superficie de los locales');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(458,'va_ES','[va]Por superficie de los locales');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(458,'eu_ES','[eu]Por superficie de los locales');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(458,'ca_ES','[cat]Por superficie de los locales');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(834,'10061','2',458,7,null,'831');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(459,'es_ES','Por partes iguales');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(459,'ga_ES','[gl]Por partes iguales');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(459,'va_ES','[va]Por partes iguales');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(459,'eu_ES','[eu]Por partes iguales');
insert into DICTIONARY (ID_VOCABLO,LOCALE,TRADUCCION)values(459,'ca_ES','[cat]Por partes iguales');
insert into domainnodes (id,id_domain, pattern,  ID_DESCRIPTION, "type",id_municipio, parentdomain)
  values(835,'10061','1',459,7,null,'831');

 
 
 