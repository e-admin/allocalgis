--Modificaciones del modelo de datos

drop table catastro_temporal cascade;
CREATE TABLE "public"."catastro_temporal" (
  "id_expediente" NUMERIC(10,0) NOT NULL, 
  "referencia" VARCHAR(20) NOT NULL, 
  "id_dialogo" VARCHAR(50), 
  "xml" TEXT NOT NULL, 
  "fxcc" TEXT, 
  CONSTRAINT "pk_catastro_temporal" PRIMARY KEY("id_expediente", "referencia")
)

drop table suelo cascade;
CREATE TABLE "public"."suelo" (
  "identificador" VARCHAR(18) NOT NULL, 
  "anno_expediente" NUMERIC(4,0), 
  "referencia_expediente" VARCHAR(13), 
  "codigo_entidad_colaboradora" NUMERIC(3,0), 
  "tipo_movimiento" VARCHAR(1), 
  "parcela_catastral" VARCHAR(14), 
  "numero_orden" VARCHAR(4), 
  "longitud_fachada" NUMERIC(5,0), 
  "tipo_fachada" VARCHAR(2), 
  "superficie_elemento_suelo" NUMERIC(7,0), 
  "fondo_elemento_suelo" NUMERIC(3,0), 
  "codigo_via_ponencia" VARCHAR(5), 
  "codigo_tramo_ponencia" VARCHAR(3), 
  "zona_valor" VARCHAR(5), 
  "zona_urbanistica" VARCHAR(10), 
  "codigo_tipo_valor" VARCHAR(1), 
  "numero_fachadas" VARCHAR(1), 
  "corrector_longitud_fachada" BOOLEAN, 
  "corrector_forma_irregular" BOOLEAN, 
  "corrector_desmonte_excesivo" BOOLEAN, 
  "corrector_superficie_distinta" BOOLEAN, 
  "corrector_inedificabilidad" BOOLEAN, 
  "corrector_vpo" BOOLEAN, 
  "corrector_depreciacion_funcional" BOOLEAN, 
  "corrector_situaciones_especiales" BOOLEAN, 
  "corrector_uso_no_lucrativo" BOOLEAN, 
  "corrector_apreciacion_depreciacion" NUMERIC(3,2), 
  "corrector_cargas_singulares" NUMERIC(3,2), 
  CONSTRAINT "suelo_pkey" PRIMARY KEY("identificador")
);

drop table unidad_constructiva cascade;
CREATE TABLE "public"."unidad_constructiva" (
  "identificador" VARCHAR(18) NOT NULL, 
  "anno_expediente" NUMERIC(4,0), 
  "referencia_expediente" VARCHAR(13), 
  "codigo_entidad_colaboradora" NUMERIC(3,0), 
  "tipomovimiento" VARCHAR(1), 
  "parcela_catastral" VARCHAR(14), 
  "codigo_unidad_constructiva" VARCHAR(4), 
  "clase_unidad" VARCHAR(2), 
  "codigo_municipio_ine" VARCHAR(3), 
  "codigo_municipio_dgc" VARCHAR(3), 
  "nombre_entidad_menor" VARCHAR(30), 
  "primer_numero" NUMERIC(4,0), 
  "primera_letra" VARCHAR(1), 
  "segundo_numero" NUMERIC(4,0), 
  "segunda_letra" VARCHAR(1), 
  "kilometro" NUMERIC(5,2), 
  "bloque" VARCHAR(4), 
  "direccion_no_estructurada" VARCHAR(25), 
  "anio_construccion" NUMERIC(4,0), 
  "indicador_exactitud" VARCHAR(1), 
  "superficie_ocupada" NUMERIC(7,0), 
  "longitud_fachada" NUMERIC(5,0), 
  "codigo_via_ponencia" VARCHAR(5), 
  "codigo_tramo_ponencia" VARCHAR(3), 
  "zona_valor" VARCHAR(5), 
  "numero_fachadas" VARCHAR(1), 
  "corrector_longitud_fachada" BOOLEAN, 
  "corrector_estado_conservacion" VARCHAR(1), 
  "corrector_depreciacion_funcional" BOOLEAN, 
  "corrector_situaciones_especiales" BOOLEAN, 
  "corrector_uso_no_lucrativo" BOOLEAN, 
  "corrector_cargas_singulares" NUMERIC(3,2), 
  CONSTRAINT "pk_unidad_constructiva" PRIMARY KEY("identificador")
) ;


ALTER TABLE "public"."ficheros"
  DROP CONSTRAINT "fk_ficheros_entidad_generadora" RESTRICT;
  


-- Modificaciones de gesti�n de expedientes


INSERT INTO query_catalog (id, query)
VALUES 
  ('MCinsertarCatastroTemporal','insert into catastro_temporal(id_dialogo, xml,id_expediente, referencia) values (?,?,?,?)');

INSERT INTO query_catalog (id, query)
VALUES 
  ('MCactualizarCatastroTemporal','update catastro_temporal set fxcc=? where id_expediente=? and referencia=?');

INSERT INTO query_catalog (id, query)
VALUES 
  ('MCexisteCatastroTemporal','select id_dialogo from catastro_temporal where id_expediente=? and referencia=?');


DELETE FROM QUERY_CATALOG WHERE ID='MCobtenerParcelasTemporal';

INSERT INTO query_catalog (id, query)
VALUES 
  ('MCobtenerParcelasTemporal','select expediente.*, entidad_generadora.*, referencia, parcelas.id as id_parcela from catastro_temporal, parcelas, expediente\r\nleft join entidad_generadora on (expediente.id_entidad_generadora=entidad_generadora.id_entidad_generadora)\r\nwhere parcelas.referencia_catastral=catastro_temporal.referencia\r\nand parcelas.fecha_baja is null\r\nand expediente.id_expediente = catastro_temporal.id_expediente');


INSERT INTO query_catalog (id, query)
VALUES 
  ('MCSelectDXFBase64','select FXCC from Catastro_Temporal where Id_Expediente=? and Referencia=?');

INSERT INTO query_catalog (id, query)
VALUES
  ('MCobtenerElemfTemporal','select xml from catastro_temporal where referencia=? and id_expediente=?');



-- Modificaci�n de script adaptacion

update queries set selectquery = 'SELECT Parcelas.*, Municipios.NombreOficial FROM Municipios INNER JOIN Parcelas ON (Municipios.ID=Parcelas.ID_Municipio) WHERE Municipios.ID=?M AND Fecha_baja IS NULL', updatequery = 'UPDATE parcelas SET "GEOMETRY"=GeometryFromText(?1,?S),id=?2,referencia_catastral=?3,id_municipio=?M,id_distrito=?5,codigoparcela=?6,codigopoligono=?7,id_via=?8,primer_numero=?9,primera_letra=?10,segundo_numero=?11,segunda_letra=?12,kilometro=?13,bloque=?14,direccion_no_estructurada=?15,codigo_postal=?16,codigodelegacionmeh=?17,length=perimeter(GeometryFromText(?1,?S)),area=area2d(GeometryFromText(?1,?S)),fecha_alta=?20,fecha_baja=?21 WHERE ID=?2', insertquery = 'INSERT INTO parcelas ("GEOMETRY",id,referencia_catastral,id_municipio,id_distrito,codigoparcela,codigopoligono,id_via,primer_numero,primera_letra,segundo_numero,segunda_letra,kilometro,bloque,direccion_no_estructurada,codigo_postal,codigodelegacionmeh,length,area,fecha_alta,fecha_baja) VALUES(GeometryFromText(?1,?S),?PK,?3,?M,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17,perimeter(GeometryFromText(?1,?S)),area2d(GeometryFromText(?1,?S)),?20,?21)', deletequery = 'DELETE FROM parcelas WHERE ID=?2' where id_layer = '101';



