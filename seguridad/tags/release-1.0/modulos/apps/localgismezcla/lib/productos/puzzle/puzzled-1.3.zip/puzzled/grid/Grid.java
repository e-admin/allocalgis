package puzzled.grid;

import java.awt.*;
import java.io.*;
import java.util.Vector;
import javax.swing.*;
import puzzled.*;

/**
 * The grid class represent the data structure of the problem to 
 * be solved.  It is not a drawable component itself, but owns a 
 * reference to a GridCanvas object, which is the graphical 
 * representation of the relationships between the
 * various items.  This class also contains an array of category
 * names, as well as a two-dimensional array containing each of 
 * the item names.
 *
 * @author Fr�d�ric Demers
 * @version 1.1 25 Aug 2001
 */
public class Grid implements Constants{

	private boolean dirty = false;
	
	/** The number of categories of items contained in the problem.*/
	private int catNumber = 0;
	
	/** The number of items per category.*/
	private int itemNumber = 0;
	
	private File currentFile;
		
	/** The array of category names.*/
	private String[] categories;

	/** The array of item names.*/
	private String[][] items;
		
	/** A canvas to draw the relationship beween the items.*/
	public GridCanvas gridCanvas;
	

	public AnswerCanvas answerCanvas;
	
	/**
	 * The array of relationships.  See Constants interface for the
	 * possible values.  It is a square array but not all of it
	 * is being used: only the upper right triangle limited and including
	 * by the diagonal, such that each relationship is represented 
	 * only once in the matrix, and always at the same place.
	 */
	private int[][] squares;
	
	/**
	 * The number of squares across in the squares matrix.
	 * The problem requires a square matrix of itemNumber*catNumber square
	 * but is limited to the upper triangular matrix limited by and excluding 
	 * the diagonal.  The matrix size can therefore be reduced to
	 * itemNumber * (catNumber-1), still using the upper triangular matrix, limited
	 * and now including the diagonal elements.
	 */
	private int matrixSize;

	/**
	 * Vector containing all the relationships having a value
	 * of VALUE_YES.  This is done to improve the efficiency
	 * by avoiding to search for these relationships everytime.
	 * It is primarily used by the processor.
	 */
	private Vector answersVector = new Vector();		
	
	/**
	 * Vector containing all the clues entered.  The object in this vector
	 * are of the type Clue.
	 */
	private Vector cluesVector = new Vector();
	
	private ProblemSolver parent;	 

	/** Constructor
	 */
	public Grid(ProblemSolver parent_arg) {
		parent= parent_arg;
		currentFile = new File(parent.getStatus().directory, ProblemSolver.noNameString);
		gridCanvas=null;
		answerCanvas=null;
		setDirty(false);
	}

  /**
   * Class constructor with filename.
   *
   * @parma file_arg   the name of the file for this grid.
   * @param parent_arg a reference to the parent which contains this Worksheet.
   */
	public Grid(ProblemSolver parent_arg,File file_arg) {
		parent= parent_arg;
		currentFile = file_arg;
		try {
			loadGrid(currentFile);
			generateCanvases();
			setDirty(false);
		} catch (Exception e) {
			System.out.println("Could not open the file");
			parent.setStatusMessage("Creating new file...");
			File theFile = new File(parent.getStatus().directory, ProblemSolver.noNameString);
			parent.actionManager.triggerNew(theFile);
		}		
	}

	
	/** 
	 * Method called to set the number of categories in the problem.
	 * Has to be called before setItemNumber.
	 * @param number the number of categories.
	 */
	public void setCatNumber(int number){
		catNumber = number;
		categories = new String[catNumber];
	}
	
	/** 
	 * Method called to set the number of items per category.
	 * Has to be called after setCatNumber.  It also creates the
	 * names array and the squares array.
	 * @param number the number of items per category.
	 */
	public void setItemNumber(int number){
		if (catNumber >1) 
		{
			itemNumber = number;
			items = new String[catNumber][itemNumber];
			matrixSize = (catNumber-1)*itemNumber;
			squares = new int[matrixSize][matrixSize];
			
			/* initializing the relationship table
			 */
			for (int i=0; i<matrixSize; i++)
				for (int j=0; j<matrixSize; j++)
					squares[i][j] = VALUE_UNKNOWN;
		}	
	}
	
	public void generateCanvases() {
			gridCanvas = new GridCanvas(parent, this);
			answerCanvas = new AnswerCanvas(this);
	}

	/** 
	 * Method used to set the name of a category given its 
	 * index.
	 *
	 * @param index the index of this category.
	 * @param name the name of the category.
	 */
	public void setCategory(int index, String name){
		categories[index]=name;
	}

	/** 
	 * Method used to get the name of a category of items, given its 
	 * index.
	 *
	 * @param index the index of this category.
	 */
	public String getCategory(int index){
		return categories[index];
	}

	public String[] getCategories() {
		return categories;
	}	
	/** 
	 * Method used to set the name of an item, given its category
	 * number and index.
	 *
	 * @param category the category number between 0 and catNumber-1
	 * @param index the index of this item
	 * @param name the name of the item
	 */
	public void setItem(int category, int index, String name){
		items[category][index]=name;
	}

	/** 
	 * Method returning the name of an item given its category
	 * number and index.
	 *
	 * @param category the category number between 0 and catNumber-1
	 * @param index the index of this item
	 */
	public String getItem(int category, int index){
		return items[category][index];
	}
	
	public String[][] getItems() {
		return items;
	}
	/**
	 * Method used to obtain the category index of a given item or category name.
	 * Used when parsing a hint to compare the categories of two
	 * or more items.  Also needed when obtaining the coordinates
	 * of a relationship or of its graphical representation.
	 * @param item the item name.
	 * @return the category index of the item
	 */
	public int getCatIndex(String item){
		//checking for item names
		boolean caseSensitive=parent.getStatus().caseSensitive;
		for (int i = 0; i < catNumber; i++)
			for (int j = 0;j < itemNumber ; j++)
				if ((item.equals(items[i][j])) ||
					((item.toLowerCase()).equals(items[i][j].toLowerCase())&&!caseSensitive)) return i;
		//if i & j are at the end, then item does not match...
		//checking for category names
		for (int i = 0; i < catNumber; i++)
			if ((item.equals(categories[i])) ||
				((item.toLowerCase()).equals(categories[i].toLowerCase())&&!caseSensitive)) return i;
		//if i is at the end, then categories do not match		
		return NOT_VALID;
		
	}
	
	/**
	 * Method returning the item index of a given item.  This 
	 * is used in order to establish the coordinates of the
	 * relationship and of its graphical representation.
	 */
	public int getItemIndex(String item){
		boolean caseSensitive=parent.getStatus().caseSensitive;
		for (int i = 0; i < catNumber; i++)
			for (int j = 0;j < itemNumber ; j++)
				if ((item.equals(items[i][j])) ||
					((item.toLowerCase()).equals(items[i][j].toLowerCase())&&!caseSensitive)) return j;
		//if i & j are at the end, then item does not match...
		return NOT_VALID;
	}
	
	
	/**
	 * Method used to add a relationship to the squares array, and
	 * update the graphical representation by passing the call to
	 * the GridCanvas object.  It returns wether this affectation
	 * was successful (true) or if it was already done (false)
	 *
	 * @param rel the relationship to be added.
	 * @return whether the addition was successful
	 */
	public boolean addRelation(Relation rel) {
		if (rel.cat1==rel.cat2){
			//DEBUG
			//System.out.println("ERROR - RELATIONSHIP WITH SAME CATEGORY");
			return false;
		}

		//set the value in the square only if it is unknown
		if (setSquare(rel.value,rel.cat1*itemNumber+rel.item1,
				rel.cat2*itemNumber+rel.item2)) {
				gridCanvas.addRelation(rel);
				
				/* completing immediate category relationships:
				 * the cross for a definite match.
				 */
				if (rel.value==VALUE_YES) {
					answersVector.addElement(rel);
					
					for (int i=0; i< itemNumber; i++) {
						if (setSquare(VALUE_NO,rel.cat1*itemNumber+i,
													rel.cat2*itemNumber+rel.item2))
							gridCanvas.addRelation(new Relation(VALUE_NO,
														rel.cat1,i,rel.cat2,rel.item2));
						if (setSquare(VALUE_NO,rel.cat1*itemNumber+rel.item1,
													rel.cat2*itemNumber+i))
							gridCanvas.addRelation(new Relation(VALUE_NO,
													rel.cat1,rel.item1,rel.cat2,i));
					} //end for
					//when a new aye is found, update the answer canvas..
					answerCanvas.repaint();
				} // end if
			return true;
		} else return false;
	}

	/**
	 * Method used to add a relationship to the squares array, and
	 * update the graphical representation by passing the call to
	 * the GridCanvas object.  It returns wether this affectation
	 * was successful (true) or if it was already done (false).
	 * This version will create a new relation from the parameters
	 * instead of accepting an existing one.
	 *
	 * @param value
	 * @param cat1
	 * @param item1
	 * @param cat2
	 * @param item2
	 * @return whether the addition was successful
	 */
	public boolean addRelation(int value,int cat1, int item1,int cat2, int item2) {
		return addRelation(new Relation(value,cat1,item1,cat2,item2));
	}
	/**
	 * Method used to set a square in the squares matrix that
	 * will only do so (and return true) if the square was previously
	 * unknown.  Remember that the squares matrix is shorter than
	 * what it would seem reasonable due to the general left
	 * translation done to step over the diagonal elements
	 *
	 * @param value the value of the relationship as in interface
	 * 				Constants
	 * @param row the row of the squares matrix applicable
	 * @param column the columen of the squares matrix applicable
	 * @return whether the square was initially unknow or not
	 */
	private boolean setSquare(int value, int row, int column) {
		if (squares[row][column-itemNumber]==VALUE_UNKNOWN && value != VALUE_UNKNOWN) {
			squares[row][column-itemNumber]=value;
			return true;
		} else return false;
	}

	/**
	 * Method used to obtain the relationship between two items,
	 * such as set in the square matrix.  The categories can be
	 * inversed, this method will compute the proper row and column
	 * values needed, also considering the left translation done
	 * to improve memory usage.
	 *
	 * @param cat1 One category index associated with one item
	 * @param item1 One item index
	 * @param cat2 The other category index associated with the other item
	 * @param item1 The other item index
	 * @return The actual value of the relationship such as seen in 
	 * 					the Constants interface.
	 */
	public int getRelation(int cat1, int item1, int cat2, int item2) {
		int row, column;
		if (cat1 < cat2) {
			row = cat1*itemNumber+item1;
			column = cat2*itemNumber+item2;
		} else {
			row = cat2*itemNumber+item2;
			column = cat1*itemNumber+item1;
		}			
		return (squares[row][column-itemNumber]);
	}
	
	/**
	 * Method used to obtain a reference to the ayeVector.
	 * @return the ayeVector containing the relations that are
	 * 				 a definite match.
	 */
	public Vector getAnswersVector() {
		return answersVector;
	}

	/**
	 * Method used to check if there is a recorded answer
	 * between a specific item and a category.  Returns
	 * the answer (which item in the category it is linked with
	 * a VALUE_YES) or -1 if no answer has been discovered yet.
	 * @return the number of categories
	 */
	public int checkAnswer(String testItem,int specialCategory) {
	
		int	testItemIndex=getItemIndex(testItem);
		int testItemCat=getCatIndex(testItem);
		
		for (int i=0; i<itemNumber; i++)
			if (getRelation(testItemCat,testItemIndex,specialCategory,i)==VALUE_YES) return i;
	return -1;	
	}

	/**
	 * Method used to obtain the number of categories
	 * @return the number of categories
	 */
	public int getCatNumber() {
		return catNumber;
	}

	/**
	 * Method used to obtain the number of items
	 * @return the number of items
	 */
	public int getItemNumber() {
		return itemNumber;
	}

	/**
	 * Method used to obtain the vector containing the special
	 * relations.  It is used by the processor.
	 * @return the special relations vector.
	 */
	public Clue getClue(int clueNumber_arg) {
		//DEBUG
		//System.out.println((Clue)cluesVector.elementAt(clueNumber_arg)+" retrieved");
		return (Clue)cluesVector.elementAt(clueNumber_arg);

	}
	
	public Vector getCluesVector()  {
		return cluesVector;
	}
	
	/**
	 * Method used to add a clue in the cluesVector.  Mainly used
	 * by the parser.
	 * @param clue the clue to be added in the cluesVector.
	 */
	public void addClue(Clue newClue) {
		cluesVector.addElement(newClue);
		//DEBUG
		//System.out.println(newClue+" added");
	}
	
	/**
	 * Method used to reset the squares and redraw the new grid.
	 */
	public void reset() {
		/* initializing the relationship table
		 */
		for (int i=0; i<matrixSize; i++)
			for (int j=0; j<matrixSize; j++)
				squares[i][j] = VALUE_UNKNOWN;
		answersVector.removeAllElements();
		cluesVector.removeAllElements();
		generateCanvases();
		parent.refresh();	
	}
	
	public void refresh() {
		gridCanvas.repaint();
		answerCanvas.repaint();
	}
	
	/**
	 * Method used to return the canvas, which is the graphic
	 * representation of the relationships.  It is required when
	 * adding the canvas to the scrollpane.
	 *
	 * @return the graphical representation of the relationships
	 */
	public GridCanvas getGridCanvas() {
		return gridCanvas;
	}
	
	public AnswerCanvas getAnswerCanvas() {
		return answerCanvas;
	}
	
	public ProblemSolver getParent()  {
		return parent;
	}

	public boolean isDirty() {
		return dirty;
	}
	
	public void setDirty(boolean dirty_arg) {
		dirty = dirty_arg;
	}
	
	  /**
   * Loads a worksheet with the specified file name.
   *
   * @param filename the name of the file
   *
   * @return a reference to the saved Worksheet
   */
 	public void loadGrid(File filename) throws
 		IOException, InvalidGridException {
  	try {
  		FileWrapper fileWrapper = (FileWrapper)(new ObjectInputStream(
        	new FileInputStream(filename)).readObject());
			
			setCurrentFile(filename);
			setCatNumber(fileWrapper.catNumber);
			setItemNumber(fileWrapper.itemNumber);
			categories = fileWrapper.categories;
			items = fileWrapper.items;
			//for any exception, we assume bad file conversion.
    } catch (IOException e) {
    	  throw e;
    } catch (Exception exc) {
    		throw new InvalidGridException();
    }

	}

  /**
   * Saves the current Worksheet.
   */
	public void saveGrid() throws IOException{
		try {
			new ObjectOutputStream(
    		new FileOutputStream(currentFile)).
    				writeObject(new FileWrapper(catNumber,itemNumber,categories,items));
		} catch (IOException e) {
			throw e;
		}
	}

  /**
   * Saves the current Grid information in the specified File.
   *
   * @param theFile a File reference obtained through file chooser
   */
	public void saveGrid(File theFile) throws IOException {
  	File tempo = getCurrentFile();
		setCurrentFile(theFile);

		try {
			saveGrid();
		}catch (IOException e) {
			setCurrentFile(tempo);
			throw e;
		}
	}

  /**
   * Assigns the specified File to this grid.
   *
   *@param f the File
   */
	public void setCurrentFile(File f) {
    currentFile = f;
  }

  /**
   * Returns a reference to the current File for this Worksheet.
   *
   * @return the current File
   */
	public File getCurrentFile() {
    return currentFile;
  }
  
	public void regenerateVector() {
		for (int c1= 0 ; c1<(catNumber-1); c1++) 
			for (int c2= c1+1; c2<catNumber; c2++) 
				for (int i1 = 0; i1< itemNumber; i1++) 
					for (int i2 = 0; i2< itemNumber; i2++) {
						int value = getRelation(c1,i1,c2,i2);
						if (value !=VALUE_UNKNOWN) {
							System.out.println("found ("+c1+","+i1+")-("+c2+","+i2+")");
							gridCanvas.addRelation(new Relation(value,c1,i1,c2,i2));
						}
					}
	}
  
}


/**
 * This class is used for saving the file information.
 * The FileWrapper class wraps only the information relevant
 * to the problem without any clues, i.e. the number of categories
 * and the number of items, as well as the two arrays containing
 * the category and item names.  The decision to separate the 
 * problem definition from the clues is done to enable one to load only
 * the problem definition.  This file may be loaded by itself (.lpf) or
 * in conjunction with the clues and squares matrix (.lpc)  
 */
class FileWrapper implements java.io.Serializable {
	public int catNumber;
	public int itemNumber;
  
	public String[] categories;
	public String[][] items;
  
	FileWrapper(int cn, int in, String[] cat, String[][] it) {

		catNumber = cn;
		itemNumber = in;
  
	  	categories = cat;
	  	items = it;
  
	}
} //FileWrapper

/**
 * This class is used for saving the file information.
 * The CluesWrapper class wraps only the information relevant
 * to the problem solving, i.e. the current squares matrix
 * and the special relationships.The decision to separate the 
 * problem definition from the clues is done to enable one to load only
 * the problem definition.  This file will not be loaded by itself, but
 * can be optionally loaded if both files (.lpf and .lpc) are present.
 */
class CluesWrapper implements java.io.Serializable {
  
	public int[][] squares;
	public Vector cluesVector;
	public Vector ayeVector;

	CluesWrapper(int[][] sq, Vector cv, Vector av) {

	  	squares = sq;
	  	cluesVector = cv;
	  	ayeVector = av;

	}
} //CluesWrapper