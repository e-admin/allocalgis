package puzzled.actions;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import puzzled.ProblemSolver;
import puzzled.StatusPanel;
import puzzled.dialogs.*;

/**
 * The SaveAsAction class is composed of a string and an icon, and is
 * added to the menu bar.  It has the action
 * performed method that is called when the menu item is clicked.
 *
 * @author Fr�d�ric Demers
 * @version 1.54
 */
public class SaveAsAction extends AbstractAction {
	ProblemSolver parent;
	
	public SaveAsAction(ProblemSolver parent_arg) {
		super("Save As...",new ImageIcon("resources/saveas.gif"));
		parent = parent_arg;
	}
	
	public void actionPerformed(ActionEvent e) {
    JFileChooser chooser;
		
		chooser = new PSChooser(parent,PSChooser.SAVE);
		boolean valid = false;
		while (!valid){
			int retval = chooser.showDialog(parent, null);
			
			if(retval == JFileChooser.APPROVE_OPTION) {
		    File theFile = chooser.getSelectedFile();
				String name = theFile.getName();
				parent.getStatus().directory = theFile.getParent();
				if (!name.endsWith(".lpf")) {
					theFile = new File(theFile.getPath() + ".lpf"); //appends .pfm if not there
					name = theFile.getName();
				}
				
				if (theFile.exists()){
					if (DialogMaster.showDialog(DialogMaster.OVERWRITE,theFile)
							== JOptionPane.YES_OPTION){
						valid = true;
							try {
									parent.setStatusMessage("Saving file "+ name);
									parent.getGrid().saveGrid(theFile);
							    parent.setStatusMessage("File "+ name +" saved");
									parent.setGridDirty(false);
							} catch (IOException fe) {
								parent.setStatusMessage("File "+ name+" could not be saved");
								DialogMaster.showDialog(DialogMaster.SAVING_ERROR, theFile);
								valid = false;
							}
					}
				}	else {
					try {
						parent.setStatusMessage("Saving file "+ name);
						parent.getGrid().saveGrid(theFile);
				    parent.setStatusMessage("File "+ name +" saved");
						parent.setGridDirty(false);
						valid = true;
					} catch (IOException ex) {
						valid = false;
						DialogMaster.showDialog(DialogMaster.WARN_IO_CREATE, theFile);
					}
				}
			} else valid = true; //cancel option selected
		}
  }
}