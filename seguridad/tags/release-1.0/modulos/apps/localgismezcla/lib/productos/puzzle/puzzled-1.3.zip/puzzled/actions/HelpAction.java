package puzzled.actions;

import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.io.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.html.*;
import puzzled.ProblemSolver;
import puzzled.dialogs.DialogMaster;

/**
 * The HelpAction class is composed of a string and an icon, and is
 * added to the toolbar and menu bar.  It has the action performed method
 * that is called when the menu item or button is clicked.
 *
 * @author Fr�d�ric Demers
 * @version 1.54
 */

public class HelpAction extends AbstractAction {
	ProblemSolver parent;
	
	public HelpAction(ProblemSolver parent_arg) {
		super("Content",new ImageIcon("resources/help.gif"));
		parent = parent_arg;
	}
	
	/** 
	 * This action performed method will display an HTML help page
	 * found in the resources directory.  It also registers an event
	 * handler for the hyperlinks in the page.  This method could be
	 * modified very easily to provide online help rather than local
	 * help.
	 */
  public void actionPerformed(ActionEvent e) {
     JFrame helpFrame = new JFrame("Problem Solver Help System");
     helpFrame.setIconImage(new ImageIcon("resources/icon.gif").getImage());
     
     JEditorPane editorPane = new JEditorPane();
     editorPane.setEditable(false);
     editorPane.addHyperlinkListener(new Hyperactive());
     JScrollPane editorScrollPane = new JScrollPane(editorPane);
     editorScrollPane.setVerticalScrollBarPolicy(
                     JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
     editorScrollPane.setPreferredSize(new Dimension(500, 300));
     
     String s = null;
     URL helpURL=null;
     
     // generating local help URL
     try {
         s = "file:"
             + System.getProperty("user.dir")
             + System.getProperty("file.separator")
             + "resources/main_help.html";
         helpURL = new URL(s);
     } catch (Exception se) {
         DialogMaster.showDialog(DialogMaster.BAD_HELP_FILE_URL, helpURL.toString());
         return;
     }
     if (helpURL!=null){
     	
     	//setting help URL in editor pane
     	try {
     	   editorPane.setPage(helpURL);
		     helpFrame.getContentPane().add(editorScrollPane);
  		   helpFrame.pack();
    		 helpFrame.setVisible(true);
			} catch (IOException ioe) {
         DialogMaster.showDialog(DialogMaster.BAD_HELP_FILE_URL, helpURL.toString());
         return;
     	}
     }
	}

	/** 
	 * This class provide hyperlink sensibility, and is a very
	 * straight foward adaptation from Sun's Java Tutorial.  It
	 * will simply load a new HTML file in the Editor Pane
	 */
	class Hyperactive implements HyperlinkListener {

		public void hyperlinkUpdate(HyperlinkEvent e) {
			if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
				JEditorPane pane = (JEditorPane) e.getSource();
				if (e instanceof HTMLFrameHyperlinkEvent) {
					HTMLFrameHyperlinkEvent  evt = (HTMLFrameHyperlinkEvent)e;
					HTMLDocument doc = (HTMLDocument)pane.getDocument();
					doc.processHTMLFrameHyperlinkEvent(evt);
				} else {
					try {
						pane.setPage(e.getURL());
					} catch (Throwable t) {
         		DialogMaster.showDialog(DialogMaster.BAD_HELP_FILE_URL, e.getURL().toString());
					}
				}
			}
		}
	}
}