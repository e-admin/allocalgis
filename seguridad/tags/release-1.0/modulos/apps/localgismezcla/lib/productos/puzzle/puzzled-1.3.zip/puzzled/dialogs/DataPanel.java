package puzzled.dialogs;

import java.awt.*;
import java.util.StringTokenizer;
import javax.swing.*;
import puzzled.grid.Grid;

public class DataPanel extends JPanel {
	private JTextField[] rowTextField;
	private Grid grid;
	private int catIndex;
	public static final int CATEGORY_NAMES = -1;
	
	//if catIndex=-1, we want to change the catNames
	public DataPanel (Grid grid_arg, int catIndex_arg) {
		grid = grid_arg;
		catIndex = catIndex_arg;
		if (catIndex==CATEGORY_NAMES) setBorder (BorderFactory.createTitledBorder("Please indicate the followings category names:"));
		else setBorder (BorderFactory.createTitledBorder("Please indicate the items in "+grid.getCategory(catIndex)));
		
		setLayout (new BoxLayout(this,BoxLayout.Y_AXIS));

		int number = (catIndex==CATEGORY_NAMES)?grid.getCatNumber():grid.getItemNumber();
		rowTextField = new JTextField[number];

		JLabel label;
		
		for (int i= 0; i< number; i++) {
			JPanel rowPanel = new JPanel();
			label= new JLabel(((catIndex==CATEGORY_NAMES)?"Category ":"Item ")+(i+1));
			rowPanel.add(label);
			rowTextField[i]=new JTextField((catIndex==CATEGORY_NAMES)?grid.getCategory(i):grid.getItem(catIndex,i),30);

			rowPanel.add(rowTextField[i]);
			add(rowPanel);
		}
	}
	
	public String getString(int index) {
		return rowTextField[index].getText();
	}

	public boolean allFieldsFilled() {
		for (int i = 0; i< rowTextField.length; i++){
			//this method allows the normal test for an empty string
			// but also the test for a string that has nothing but spaces
			StringTokenizer tempo = new StringTokenizer(rowTextField[i].getText());
			if (!tempo.hasMoreTokens()) return false;
		}
		return true;
	}
}		
	
	
	
	