package puzzled.dialogs;

import java.awt.*;
import javax.swing.*;
import puzzled.ProblemSolver;
import puzzled.grid.Grid;
/**
 * This class displays the dialog allowing the user to view/modify
 * the problem configuration.
 *
 * @author Fr�d�ric Demers
 * @version 1.54 24 March 99
 */
public class ProblemConfig{

	private JComboBox catNumberCB, itemNumberCB;
	private JPanel numberPanel = new JPanel(new BorderLayout());
	private ProblemSolver parent;
	private Grid newGrid;

	//private ProblemSolver parent;
	
	/** 
	 * Single constructor.  It accepts a reference to the parent
	 * application as a parameter.
	 *
	 * @param a reference to the parent application.
	 */
	public ProblemConfig(ProblemSolver parent_arg, Grid newGrid_arg) {
		parent = parent_arg;
		newGrid = newGrid_arg;
		createNumberPanel();
	}
	
	public boolean showConfigDialog() {
		DataPanel dataPanel;
		boolean allFieldsFilled = false;
		
		int value = JOptionPane.showConfirmDialog(
			parent,
			numberPanel,
			"New Problem Configuration",
			JOptionPane.OK_CANCEL_OPTION,
			JOptionPane.PLAIN_MESSAGE
			);
		if (value==JOptionPane.OK_OPTION) {
			newGrid.setCatNumber(getCatNumber());
			newGrid.setItemNumber(getItemNumber());
			
			System.out.println("OK "+ getCatNumber()+", "+getItemNumber());
			
			dataPanel = new DataPanel(newGrid,DataPanel.CATEGORY_NAMES);

			while (!allFieldsFilled) {
				value = JOptionPane.showConfirmDialog(
					parent,
					dataPanel,
					"Category Names",
					JOptionPane.OK_CANCEL_OPTION,
					JOptionPane.PLAIN_MESSAGE
					);
				if (value==JOptionPane.OK_OPTION) {
					if (!dataPanel.allFieldsFilled()) 
						DialogMaster.showDialog(DialogMaster.EMPTY_FIELD);
				  else {
						allFieldsFilled = true;
						for (int i=0; i<getCatNumber() ; i++)
							newGrid.setCategory(i,dataPanel.getString(i));
				  } //end else
				} else return false; //end if OK_OPTION
			} //end while
		} else return false;						
		
		for (int j= 0; j<getCatNumber(); j++) {
			dataPanel = new DataPanel(newGrid,j);
			allFieldsFilled=false;
			while (!allFieldsFilled) {
				value = JOptionPane.showConfirmDialog(
					parent,
					dataPanel,
					"Item Names",
					JOptionPane.OK_CANCEL_OPTION,
					JOptionPane.PLAIN_MESSAGE
					);
				if (value==JOptionPane.OK_OPTION) {
					if (!dataPanel.allFieldsFilled()) 
						DialogMaster.showDialog(DialogMaster.EMPTY_FIELD);
					 else {
						allFieldsFilled = true;
						for (int i=0; i<getItemNumber() ; i++)
							newGrid.setItem(j,i,dataPanel.getString(i));
				 	} //end else
				}	else return false;
			} //end while
		} //end for
		return true;
	}
	
	private void createNumberPanel () {
		JPanel upperPanel = new JPanel ();
		JPanel lowerPanel = new JPanel ();
		String[] values = new String[] {new String("3"),
										new String("4"),
										new String("5"),
										new String("6"),
										new String("7"),
										new String("8"),
										new String("9"),
										new String("10")};
		catNumberCB = new JComboBox(values);
		itemNumberCB = new JComboBox(values);
		
		upperPanel.add(new JLabel("Number of categories:"));
		upperPanel.add(catNumberCB);

		lowerPanel.add(new JLabel("Number of items:"));
		lowerPanel.add(itemNumberCB);
		
		numberPanel.setBorder (BorderFactory.createTitledBorder("Please indicate the followings:"));
		numberPanel.setLayout (new BorderLayout());
		numberPanel.add(upperPanel,BorderLayout.NORTH);
		numberPanel.add(lowerPanel,BorderLayout.SOUTH);
	}
	
	private int getCatNumber() {
		return Integer.parseInt((String)(catNumberCB.getSelectedItem()));
	}
	
	private int getItemNumber() {
		return Integer.parseInt((String)(itemNumberCB.getSelectedItem()));
	}
}