package puzzled.actions;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import puzzled.ProblemSolver;
import puzzled.dialogs.*;
import puzzled.grid.Grid;

/**
 * The CloseAction class is composed of a string and an icon, and is
 * added to the menu bar.  It has the action performed method
 * that is called when the menu item is clicked.
 *
 * @author Fr�d�ric Demers
 */
public class CloseAction extends AbstractAction {
	ProblemSolver parent;
	private int saveAnswer=0;
	
	public CloseAction(ProblemSolver parent_arg) {
		super("Close File",new ImageIcon("resources/documentDelete.gif"));
		parent = parent_arg;
	}
	
	public void saveDirty() {
		if (parent.getGrid().isDirty()) {
			File theFile= parent.getGrid().getCurrentFile();
			saveAnswer = DialogMaster.showDialog(DialogMaster.SAVE,theFile);
			if (saveAnswer == JOptionPane.CANCEL_OPTION)  //if user selects cancel, return to app.
				return;
			
			if (saveAnswer==JOptionPane.YES_OPTION)
					parent.actionManager.triggerSave();
			
		}//if dirty
	}


  public void actionPerformed(ActionEvent e) {
    saveDirty();
	parent.removeGrid();
	parent.setStatusMessage("Closing file...");
	parent.enableCloseSave(false);
  }

}