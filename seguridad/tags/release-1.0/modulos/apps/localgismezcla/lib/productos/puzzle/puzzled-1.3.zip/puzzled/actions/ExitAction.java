package puzzled.actions;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import puzzled.ProblemSolver;

/**
 * The ExitAction class is composed of a string and an icon, and is
 * added to the menu bar.  It has the action performed method
 * that is called when the menu item is clicked.
 *
 * @author Fr�d�ric Demers
 * @version 1.54
 */
public class ExitAction extends AbstractAction {
	ProblemSolver parent;
	
	public ExitAction(ProblemSolver parent_arg) {
		super("Exit",new ImageIcon("resources/exit.gif"));
		parent = parent_arg;
	}
	
  public void actionPerformed(ActionEvent e) {
      parent.quit();
  }

}