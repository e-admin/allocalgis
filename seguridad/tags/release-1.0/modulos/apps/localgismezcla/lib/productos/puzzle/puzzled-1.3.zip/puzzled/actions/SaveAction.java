package puzzled.actions;

//import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import javax.swing.*;
import puzzled.ProblemSolver;
import puzzled.dialogs.*;


/**
 * The SaveAction class is composed of a string and an icon, and is
 * added to the menu bar and the toolbar.  It has the action
 * performed method that is called when the menu item or button is clicked.
 *
 * @author Fr�d�ric Demers
 * @version 1.0
 */
public class SaveAction extends AbstractAction {
	ProblemSolver parent;
	
	public SaveAction(ProblemSolver parent_arg) {
		super("Save",new ImageIcon("resources/save.gif"));
		parent = parent_arg;
	}
	
	public void actionPerformed(ActionEvent e) {
      JFileChooser chooser;
			boolean valid = false;
			/* if doc has no name...*/
			if (parent.getGrid().getCurrentFile().getName().equals(parent.noNameString)){
			 parent.actionManager.triggerSaveAs();
			 return;
			}// if file has no name
		
			else {// file has a name 
				File theFile = parent.getGrid().getCurrentFile();	

				try {
					String name = theFile.getName();
					parent.setStatusMessage("Saving file "+ name);

					parent.getGrid().saveGrid(theFile);
					parent.setStatusMessage("File "+ name +" saved");
					parent.setGridDirty(false);									
				}	catch (IOException ex) {
					DialogMaster.showDialog(DialogMaster.SAVING_ERROR,
						theFile);
					parent.actionManager.triggerSaveAs();
					return;
				} //catch
			} //else
		
	}//actionPerformed()

}//class SaveAction