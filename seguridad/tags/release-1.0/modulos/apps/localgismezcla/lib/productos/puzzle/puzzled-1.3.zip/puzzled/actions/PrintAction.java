package puzzled.actions;

import javax.swing.*;
import java.awt.*;
import java.awt.print.*;
import java.awt.event.*;
import puzzled.ProblemSolver;
import puzzled.dialogs.*;

/**
 * The PrintAction class is composed of a string and an icon, and is
 * added to the menu bar and the toolbar.  It has the action
 * performed method that is called when the menu item or button is clicked.
 *
 * @author Fr�d�ric Demers
 * @version 1.54
 */
public class PrintAction extends AbstractAction {
	ProblemSolver parent;
	
	public PrintAction(ProblemSolver parent_arg) {
		super("Print",new ImageIcon("resources/print.gif"));
		parent = parent_arg;
	}
	
	public void actionPerformed(ActionEvent e) {
    if (parent.getGrid()==null){
    	DialogMaster.showDialog(DialogMaster.NOTHING_TO_PRINT);
    	return;
    }
   
    PrinterJob printJob = PrinterJob.getPrinterJob();
		if (parent.getTabbedPane().getSelectedIndex()==0)
			printJob.setPrintable(parent.getGrid().getGridCanvas());
		else printJob.setPrintable(parent.getGrid().getAnswerCanvas());			
 		
    parent.setStatusMessage("Printing... Please be patient");
		
    try {
    	printJob.print();
    } catch (Exception PrintException) {
    	DialogMaster.showDialog(DialogMaster.PRINTER_ERROR);
	    parent.setStatusMessage("File could not be printed");
    	return;
    }
    parent.setStatusMessage("File printed");
  }
}