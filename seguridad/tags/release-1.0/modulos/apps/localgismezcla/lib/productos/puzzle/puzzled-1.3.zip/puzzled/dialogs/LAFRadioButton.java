package puzzled.dialogs;

import javax.swing.*;

/**
 * This class represent an extension of the standard Radio Button 
 * customized for the Powerflow project.  This extension has
 * a Look and feel string that is passed as a parameter when
 * instantiating an object of this class, and that can be retreived
 * using standard accessor methods.  The LAF string correspond
 * to the location of the LAF gui class package, and hence is different
 * for the Java LAF, Window LAF, or Motif LAF.
 *
 * @author Fr�d�ric Demers
 * @author Guillaume Gilbert
 * @version 1.54 24 March 99
 */
public class LAFRadioButton extends JRadioButton {
	/** 
	 * String holding the GUI class package for the 
	 * corresponding LAF.
	 */
	private String LookAndFeel;

	/**
	 * Constructor accepting only a Look and Feel string.
	 * @param LAF_arg Look and Feel string.
	 */	
	LAFRadioButton(String LAF_arg) {
		super();
		LookAndFeel = LAF_arg;
	}
  
	/**
	 * Constructor accepting a Look and Feel string, and
	 * an icon.  Calls the JRadioButton constructor corresponding to 
	 * an icon only.
	 * @param icon Icon displayed with the radio button.
	 * @param LAF_arg Look and Feel string.
	 */	
	LAFRadioButton(Icon icon, String LAF_arg) {
  	super(icon);
  	LookAndFeel = LAF_arg;
  }
  
	/**
	 * Constructor accepting a Look and Feel string,
	 * an icon, and a boolean value for the state.
	 * Calls the JRadioButton constructor corresponding to 
	 * an icon,and a boolean state value.
	 * @param icon Icon displayed with the radio button.
	 * @param selected State of the radio button.
	 * @param LAF_arg Look and Feel string.
	 */	
	LAFRadioButton(Icon icon, boolean selected, String LAF_arg) {
  	super(icon, selected);
  	LookAndFeel = LAF_arg;
  }
 	
	/**
	 * Constructor accepting a Look and Feel string,
	 * and a text string.
	 * Calls the JRadioButton constructor corresponding to 
	 * a text string only.
	 * @param text Text string displayed with the radio button.
	 * @param LAF_arg Look and Feel string.
	 */	
	LAFRadioButton(String text, String LAF_arg) {
 		super(text);
 		LookAndFeel = LAF_arg;
 	}
  
	/**
	 * Constructor accepting a Look and Feel string,
	 * a text string, and a boolean state value.
	 * Calls the JRadioButton constructor corresponding to 
	 * a text string and the boolean state value.
	 * @param text Text string displayed with the radio button.
	 * @param selected State of the radio button.
	 * @param LAF_arg Look and Feel string.
	 */	
	LAFRadioButton(String text, boolean selected, String LAF_arg){
  	super(text,selected);
  	LookAndFeel = LAF_arg;
  }

	/**
	 * Constructor accepting a Look and Feel string,
	 * a text string, and an icon.
	 * Calls the JRadioButton constructor corresponding to 
	 * a text string and the icon.
	 * @param text Text string displayed with the radio button.
	 * @param icon Icon displayed with the radio button.
	 * @param LAF_arg Look and Feel string.
	 */	
	LAFRadioButton(String text, Icon icon, String LAF_arg) {
  	super(text,icon);
  	LookAndFeel = LAF_arg;
  }

	/**
	 * Constructor accepting a Look and Feel string,
	 * a text string, an icon and a boolean state value.
	 * Calls the JRadioButton constructor corresponding to 
	 * a text string, the icon and the boolean state value.
	 * @param text Text string displayed with the radio button.
	 * @param icon Icon displayed with the radio button.
	 * @param selected State of the radio button.
	 * @param LAF_arg Look and Feel string.
	 */	
  LAFRadioButton(String text, Icon icon, boolean selected, String LAF_arg) {
  	super(text,icon,selected);
  	LookAndFeel = LAF_arg;
  }
	
	/**
	 * Used to retreive the look and feel attached to this particular 
	 * LAFRadioButton.
	 * @return The Look and Feel string attached to this LAFRadioButton.
	 */
	public String getLookAndFeel() {
		return LookAndFeel;
	}

	/**
	 * Used to set the look and feel attached to this particular 
	 * LAFRadioButton.
	 * @param LAF_arg The new Look and Feel string attached to this LAFRadioButton.
	 */
	public void setLookAndFeel(String LAF_arg) {
		LookAndFeel = LAF_arg;
	}
}