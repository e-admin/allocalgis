package puzzled;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import java.util.StringTokenizer;
import javax.swing.*;
import javax.swing.border.*;
import puzzled.grid.Grid;
import puzzled.grid.Clue;
import puzzled.processor.Processor;
import puzzled.processor.Parser;

/**
 * The status panel is a panel that is used to enter the hint
 * informations, as well as a validation button, that will
 * start the processing of the hint received.  
 *
 * @author Fr�d�ric Demers
 * @version 1.1 26 Aug 2001
 */
public class InputPanel extends JPanel{
	
	private ProblemSolver parent;
	/** A label containing user pertinent information.*/
	private JLabel hintMessage;
	
	/**
	 * The text field to be used to enter the hint.  Future
	 * enhancements include having a ComboBox instead allowing
	 * the edition, revision of previously given hints.
	 */
	private JTextField inputString;
	/**
	 * The button used to validate the hint entered and start
	 * the processing.
	 */
	private JButton validateButton;
	
	
	/** processor */
	private Processor appBrain;
	
	/** parser */
	private Parser appParser;
	
	/**
	 * Default constructor.
	 */
  public InputPanel(ProblemSolver parent_arg)
  {
     parent=parent_arg;
     
     this.setLayout(new BorderLayout(2,2));
     this.setBorder(new SoftBevelBorder(BevelBorder.RAISED));
     hintMessage = new JLabel("Clue:");
   	 hintMessage.setBorder(new EmptyBorder(4,0,6,0));
     this.add("West", hintMessage);
     
     inputString = new JTextField();
     inputString.setBorder(new EtchedBorder(EtchedBorder.LOWERED));
   	 
   	 ButtonListener buttonListener = new ButtonListener();
   	 
   	 /* We want reaction on the user typing the enter key in the
   	  * textField area.
   	  */
   	 inputString.addActionListener(buttonListener);
   	 
   	 
   	 this.add("Center",inputString);
   	 
	   validateButton = new JButton("Process");
	   validateButton.addActionListener(buttonListener);
     this.add("East", validateButton);
     relink();
   }

  public void relink() {
     appBrain = new Processor(parent.getGrid());
     appParser= new Parser(parent);
  }
  
  public Parser getParser()  {
  	return appParser;
  }
  
  /**
   * Method used to clear the textfield
   */
  private void clearText(){
  	inputString.setText("");
  	/* This following line is needed to ensure the InputPanel is 
  	 * properly updated
  	 */
   	paintImmediately(0,0,getWidth(),getHeight());
  }

	/**
	 * Method returning the current input string.
	 * @return current input string
	 */
  public String getText(){
  	return inputString.getText();
  }
  
  /**
   * This ButtonListener inner class respond to the validation of the
   * hint by clicking on the button, or pressing the enter key 
   * while in the textfield.  It simply adds the new hint to the
   * hint vector, and sends off the string to be analysed by the
   * parser.
   */
  class ButtonListener implements ActionListener {
			/** Method called when button clicked or enter key pressed */
			public void actionPerformed(ActionEvent ae) {
				StringTokenizer tokenizer;
				int clueNumber;
				Clue currentClue;

				if (inputString.getText().startsWith(Constants.RESET_TOKEN))
				{
					parent.getGrid().reset();
	
				}
				
				//using [P] n will let you process clue number n
				else if (inputString.getText().startsWith(Constants.PREVIOUS_CLUE_TOKEN)) 
				{
					tokenizer = new StringTokenizer(inputString.getText());
					//this will be [P]
					tokenizer.nextToken();
					//this will return the value n
					clueNumber = new Integer(tokenizer.nextToken()).intValue();
					//inputString.setText(parent.getGrid().getClue(clueNumber).clueText);
					boolean dummyreturn = appParser.parse(parent.getGrid().getClue(clueNumber));
					appBrain.analyse();
				} else {
					currentClue = new Clue (inputString.getText(), 0, false);
					System.out.println(currentClue +" created");
					parent.getGrid().addClue(currentClue);

					//since Parse.parse returns a boolean, a variable is required
					//to receive the returned value, else an exception is caused when
					//ran after the first clue...
					boolean dummyreturn = appParser.parse(currentClue);

					//DEBUG
					System.out.println("calling the analyse method");
					appBrain.analyse();
				}
			clearText();				
			}
	} //class ButtonListener
}//class InputPanel