package puzzled;

import java.io.*;
import java.awt.*;

/**
 * Class containing important information regarding the status of the application.
 * Typical information are window position and size.
 *
 * @author Fr�d�ric Demers
 * @version 1 27 Aug 99
 */
public class Status{
	
	/* window parameters */
	/** contains the position of the window on the x axis */
	public int windowPosx;
	/** contains the position of the window on the y axis */
	public int windowPosy;
	/** contains the width of the window */
	public int windowWidth;
	/** contains the height of the window */
	public int windowHeight;
	
	/** this variable keeps the user's preference as to whether the 
	 *  software will be case sensitive.
	 */
	public boolean caseSensitive;

	/** this variables will allow or not the displaying of the relationships
	*/
	public boolean displayRelations;
	
	/** this variable, once set will force a reload of the previous problem */
	public boolean loadPrevious;
	
	/* look and feel */
	public String lookAndFeel;
	
	/* toolbar information */
	public String toolBarPos;
	public boolean toolBarVisible;
	
	/* working directory */
	public String directory;
	public String fileName;

	private ProblemSolver parent;
	
	/** File containing the persistent information */
	private IniFile myIniFile;
	
	/**
	 * Variable used to remember if the reading of the file was correct.
	 * If this is set to false when saving, the saveStatus method will attempt to save
	 * the information
	 */
	private boolean fileException=false;

	/**
	 * Creates a PowerflowStatus object, and loads information regarding the last session.
	 * The information that is saved between session is the following:
	 * <UL>
	 * <LI>window position
	 * <LI>window size
	 * <LI>working directory
	 * <LI>toolbar position & visibility
	 * <LI>look & feel
	 * <LI>display options
	 * </UL>
	 * If the file cannot be read, it will be using hard coded default values to initialize its 
	 * variables.
	 */
	public Status(ProblemSolver parent_arg) {
		parent = parent_arg;
			
		try {
			myIniFile = new IniFile("Solver.ini",false);//false: will not save on change
	    loadStatus();
			fileException = false;
		} catch (Exception e) {
			System.out.println("INI file cannot be read, default values are used.");
	
			/* file cannot be read, using default values */
			Toolkit toolkit = Toolkit.getDefaultToolkit();
			Dimension   scrnSize  = toolkit.getScreenSize();
			windowPosx = 0; 
			windowPosy = 0;
			windowWidth = scrnSize.width;
			windowHeight = scrnSize.height-30;
			
		  caseSensitive=false;
			displayRelations=true;
			loadPrevious=false;			
			lookAndFeel = "javax.swing.plaf.metal.MetalLookAndFeel";
			
			toolBarPos = BorderLayout.NORTH;
			toolBarVisible = true;
			
			//has to be a front slash so it is not a control char
			directory = "C:/";
			fileName = parent.noNameString;

			fileException = true;
		}
	}
	
	/**
	 * Method used to set the window parameters in this class.  Only the
	 * affectation of the variables are concerned, not the modification
	 * of the window parameters.  Typically used to ensure correspondance
	 * of the state variables maintained by this class and the actual 
	 * representation of the window.
	 */
	public void setWindowParam(Point p, Dimension d){
		windowPosx = p.x;
		windowPosy = p.y;
		windowWidth = d.width;
		windowHeight = d.height;
	}
	
	/**
	 * Saves the information regarding the session on the disk.  It is 
	 * used to save session settings when opening a new session.  If the file
	 * could not be read, this method will still attempt to save it with the
	 * new state values.
	 */
	public void saveStatus() {
			parent.findToolbarPos();
			setWindowParam(parent.getLocation(),parent.getSize());
			fileName = parent.getGrid().getCurrentFile().getName();
			// if file could not be read, we will attempt to write a new one here.
			if (fileException) try {
				myIniFile = new IniFile("Solver.ini",false);
				fileException = false;
			} catch (IOException e) {
				fileException = true; // Improvement : User Warning
				System.out.println("Attempt to write settings failed.");
			}
		  
		// only saving when the file could be read or written
		if (!fileException) {	
			try {
			//if the window is minimized, we will not save its location nor size
					
			if (windowPosx >=0) {
					myIniFile.setValue("window","posx",String.valueOf(windowPosx));
					myIniFile.setValue("window","posy",String.valueOf(windowPosy));
					myIniFile.setValue("window","width",String.valueOf(windowWidth));
					myIniFile.setValue("window","height",String.valueOf(windowHeight));
			} else {
					Dimension scrnSize = Toolkit.getDefaultToolkit().getScreenSize();
					myIniFile.setValue("window","posx","0");
					myIniFile.setValue("window","posy","0");
					myIniFile.setValue("window","width",String.valueOf(scrnSize.width));
					myIniFile.setValue("window","height",String.valueOf(scrnSize.height-30));
			}			
			
			myIniFile.setValue("options","caseSensitivity",caseSensitive?"true":"false");
			myIniFile.setValue("options","displayRelations",displayRelations?"true":"false");
			myIniFile.setValue("options","loadPrevious",loadPrevious?"true":"false");
			
			myIniFile.setValue("window","LAF",lookAndFeel);
			
			myIniFile.setValue("file","fileName",fileName);
			myIniFile.setValue("file","directory",directory);
			
			myIniFile.setValue("toolbar","visible",toolBarVisible?"true":"false");
			myIniFile.setValue("toolbar","position",toolBarPos);
		  
		  myIniFile.saveFile();
			} catch (IOException e) {
				/*parent.setStatusMessage("File loaded correctly but it is impossible to save settings now");*/
				System.out.println("File loaded correctly but it is impossible to save settings now");
			}// no inifile could be saved. Improvement: User warning.
			
		}
	}

	/**
	 * This method retreives the values from the the powerflow.ini file.
	 * It also perform conversion on the window size if needed, so that
	 * the window's bounds stay within the screen.  It throws an
	 * IOException if the file cannot be read.
	 */
	public void loadStatus() throws IOException{
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		Dimension   scrnSize  = toolkit.getScreenSize();
						
		windowPosx = Integer.parseInt(myIniFile.getValue("window","posx"));
		windowPosy = Integer.parseInt(myIniFile.getValue("window","posy"));
		
		/* The size will be the largest possible within the limits of the
		 * screen, therefore also depends on the window location
		 */
		windowWidth = Integer.parseInt(myIniFile.getValue("window","width"));
		windowWidth = Math.min(windowWidth,scrnSize.width-windowPosx);
		windowHeight = Integer.parseInt(myIniFile.getValue("window","height"));
		windowHeight = Math.min(windowHeight,scrnSize.height-30-windowPosy);

		String buffer = myIniFile.getValue("options","caseSensitivity");
		caseSensitive = buffer.equals("true");
		
		buffer = myIniFile.getValue("options","displayRelations");
		displayRelations = buffer.equals("true");

		buffer = myIniFile.getValue("options","loadPrevious");
		loadPrevious = buffer.equals("true");
	
		lookAndFeel = myIniFile.getValue("window","LAF");
		directory = myIniFile.getValue("file","directory");
		fileName = myIniFile.getValue("file","fileName");
		
		File dirFile = new File(directory);
		//directory existance check
		if (!dirFile.exists())
		//has to be a front slash so it is not a control char
			directory = "C:/";
		
		if (!fileName.equals(parent.noNameString)) {
			File file = new File(directory,fileName);
			if (!file.exists()) 
				fileName = parent.noNameString;
			else System.out.println("existant");
		}
		
		toolBarPos = myIniFile.getValue("toolbar","position");
		buffer = myIniFile.getValue("toolbar","visible");
		toolBarVisible = buffer.equals("true");
	}
}