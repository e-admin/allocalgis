package puzzled.grid;

import java.awt.*;
import java.awt.event.*;
import java.awt.print.*;
import java.io.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.border.*;

/**
 * The canvas class represent the graphical display of 
 * the grid, and the relationships between the various items.
 * A reference to an object of this class is kept by the Grid
 * object.
 *
 * @author Fr�d�ric Demers
 * @version 1.0 26 Aug 99
 */
public class AnswerCanvas extends JPanel
			implements puzzled.Constants, Printable{
	
	private Grid myGrid;
	
	/** see Grid class for an explanation of this variable.*/
	int catNumber,itemNumber;

	private Vector answersVector;

	/** see Grid class for an explanation of this variable.*/
	String categories[],items[][];
	
	private final int CELL_WIDTH = 140;
	
	private final int CELL_HEIGHT = 40;
	
	/** Values used for the determination of the screen coordinates.*/
  private int XCatPos=0, YCatPos=0, XItemPos=0, YItemPos=0;
			
	/**
	 * The size of the border that surrounds the grid.
	 * A translation is used at the end in order to obtain this 
	 * border.
	 */
	private final int BORDER = 20;
	
	/**
	 * Class constant representing the thick lines separating the 
	 * categories.
	 */
	private static final BasicStroke thickStroke = new BasicStroke(1.3f);

	/**
	 * Class constant representing the thick lines separating the 
	 * categories.
	 */
	private static final BasicStroke thinStroke = new BasicStroke(1f);
	
	/**
	 * Constructor.  Receive the required information as parameter,
	 * and creates the GridCanvas with the proper dimensions, which
	 * depend on the size of the problem.  The painting is automatical-
	 * ly called when added to the scrollpane, where the paintCompo-
	 * nent method is called.
	 * @param catNumber_arg The number of categories.
	 * @param itemNumber_arg The number of items per category.
	 * @param categories Array representing the names of the categories.
	 * @param items 2D array representing the names of the items.
	 */
	public AnswerCanvas(Grid myGrid_arg) {
		/* setting the object variables from the constructor's parameters.*/
		myGrid = myGrid_arg;
		catNumber=myGrid.getCatNumber();
		itemNumber=myGrid.getItemNumber();
		categories=myGrid.getCategories();
		items=myGrid.getItems();
		answersVector= myGrid.getAnswersVector();
		
		setLayout(null);
		
		/* The size depends on the number of items, categories, the
		 * OFFSETs and the BORDERs.
		 */
		setPreferredSize(new Dimension(catNumber*CELL_WIDTH+2*BORDER,
																		itemNumber*CELL_HEIGHT+2*BORDER));
		setBackground(Color.white);
	}
	
  /**
   * Draws the grid.  A series of for loops is being used after the
   * top and side headers are drawn.  Consideration is given for
   * the category separators with respect to thickness and color.
   * This method is called from the paintComponent method, which
   * passes its graphics (Graphics2D) context as a parameter.
   * It also paints the string representing the names of the
   * categories and the items.
   *
   * @param g2 The graphic contexts used to draw the grid.
   */
	public void drawGrid(Graphics2D g2) {
		/* We want a white empty border around the grid so the lines
		 * are all visible.
		 */
		g2.translate(BORDER,BORDER);
		
		g2.setStroke(thickStroke);
	
		//top headers
    g2.setPaint(Color.blue.darker());
    g2.drawLine(0,0,catNumber*CELL_WIDTH,0);
    g2.drawLine(0,CELL_HEIGHT,catNumber*CELL_WIDTH,CELL_HEIGHT);
    
    //long vertical - first full vertical line
    g2.drawLine(0,0,0,(itemNumber+1)*CELL_HEIGHT);
    
    //main grid
    for (int i= 1; i<=catNumber; i++) {
  			//separator: thicker blue line
  			g2.setPaint(Color.blue.darker());
  			g2.setStroke(thickStroke);
				
				//verticals
				//separators start at 0, others at CELL_HEIGHT
				g2.drawLine(i*CELL_WIDTH,
					0,
					i*CELL_WIDTH,
					(itemNumber+1)*CELL_HEIGHT);
    	}

    for (int i= 0; i<=itemNumber; i++) {
  			//separator: thicker blue line
  			if (i==itemNumber) {
	  			g2.setPaint(Color.blue.darker());
  				g2.setStroke(thickStroke);
  			} else {
  				g2.setPaint(Color.black);
  				g2.setStroke(thinStroke);
  			}
    		//horizontals
    		//separators start at 0, others at CELL_WIDTH
    		g2.drawLine(0,
    			(i+1)*CELL_HEIGHT,
    			catNumber*CELL_WIDTH,
    			(i+1)*CELL_HEIGHT);
    }


		/* writing the categories and items*/
		g2.setFont(new Font("Helvetica",Font.PLAIN,13));
		g2.setPaint(Color.black);
		
		//top headers - category names
		for (int i=0; i<catNumber; i++)
			g2.drawString(categories[i],centerOffset(categories[i],CELL_WIDTH)+i*CELL_WIDTH,CELL_HEIGHT-10);
    
    //side items - item names for the first cat
  	for (int j=1; j<=itemNumber; j++)
  			g2.drawString(items[0][j-1],5,(j+1)*CELL_HEIGHT-10);

  }
	
	/**
	 * Method used to determine the position of a string of text
	 * that needs to be centered, such as the category names.
	 *
	 * @param text The text string needing to be centered.
	 * @param space The total number of pixels available for this
	 *				text string.
	 */
	private int centerOffset(String text, int space) {
		//7.5 is an acceptable value for Helvetica 10
		return (int)((space-7.5*text.length())/2);
	}
	
	/**
	 * Overriden method which is invoked when the component needs
	 * to be repainted.  It involves a grid painting (drawGrid)
	 * following drawing of all the know relationships (contained
	 * in a vector.  (The other way would not work because of the
	 * multiple translations/rotations done in the drawGrid method.
	 *
	 * @param g The graphic context used to draw the grid.
	 */
	public void paintComponent(Graphics g) {
    super.paintComponent(g);
		Dimension d = getSize();
		
  	/* here is the little workaround to have the white background.
  	 * g.clearRect does not use the proper background color.
  	 */
  	Graphics2D g2 = (Graphics2D)g;
    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
    	 RenderingHints.VALUE_ANTIALIAS_ON);

  	g2.setBackground(Color.white);
  	g2.clearRect(0,0,d.width,d.height);
		g2.setFont(new Font("Helvetica",Font.PLAIN,13));

  	//drawing the known ayes
  	for (int i=0; i<answersVector.size(); i++) {
  		Relation currentRel = (Relation)answersVector.elementAt(i);
  		if (currentRel.cat1==0)
				g2.drawString(items[currentRel.cat2][currentRel.item2],
				5+BORDER+(currentRel.cat2)*CELL_WIDTH,
				(currentRel.item1+2)*CELL_HEIGHT-10+BORDER);
  			
  	}//end for
  	
  	//drawing the grid
  	drawGrid(g2);
  }

	/**
   * Prints the current GridCanvas on the printer. In order to do so, we must
   * first find the upper left and lower right corners of the single line
   * diagram printed on this Woksheet. Then we scale the single line diagram
   * in both width and height, using the maximum scaling value for both, in
   * in order to keep the same aspect ratio. Once this is done, the single line
   * diagram is rotated 90 degress in order to be printed in landscape format.
   * we also have to move the diagram to the right by the same value as the
   * height.
   *
   * @param g    the graphics context
   * @param pf   the page format
   * @param pi   page index
   */
  public int print(Graphics g, PageFormat pf, int pi)
                                      throws PrinterException {
      // There is only one page so this check is ok
      if (pi >= 1) {
         return Printable.NO_SUCH_PAGE;
      }
			
			int drawingWidth = getSize().width;
			int drawingHeight = getSize().height;
      double scaleX=1d;
      double scaleY=1d;
  		double minScale=1d;
  		    
      if (drawingWidth > pf.getImageableHeight()) 
      	scaleX = pf.getImageableHeight()/drawingWidth;
      if (drawingHeight > pf.getImageableWidth()) 
      	scaleY = pf.getImageableWidth()/drawingHeight;
      
      minScale = Math.min(scaleX,scaleY);
      	
      Graphics2D g2 = (Graphics2D) g;
      
      g2.translate(pf.getImageableX(), pf.getImageableY());
      g2.translate(pf.getImageableWidth(),0);
      if (minScale < 1d) g2.scale(minScale,minScale);
      g2.rotate(Math.toRadians(90));
      
      Font f = new Font("Courier", Font.PLAIN, 12);
      g2.setFont (f);
			g2.setPaint(Color.black);
			g2.drawString(myGrid.getCurrentFile().getName(),
					(int)(pf.getImageableHeight()-
						20*(myGrid.getCurrentFile().getName().length())),10);

  	//drawing the known ayes
  	for (int i=0; i<answersVector.size(); i++) {
  		Relation currentRel = (Relation)answersVector.elementAt(i);
  		if (currentRel.cat1==0)
				g2.drawString(items[currentRel.cat2][currentRel.item2],
				5+BORDER+(currentRel.cat2)*CELL_WIDTH,
				(currentRel.item1+2)*CELL_HEIGHT-10+BORDER);
  			
  	}//end for
  	
  	//drawing the grid
  	drawGrid(g2);


	return Printable.PAGE_EXISTS;
  }
}