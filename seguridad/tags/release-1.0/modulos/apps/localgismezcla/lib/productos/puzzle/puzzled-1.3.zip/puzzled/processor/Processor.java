package puzzled.processor;

import java.util.Vector;
import puzzled.Constants;
import puzzled.grid.*;

/**
 * This class is the brain of the application.  Its role
 * is to find relationships derived from the known ones.
 * It comes in two fold, the first is to replicate the known
 * information from a VALUE_YES relationship, the other is
 * to find common caracteristics out of multiple items that
 * can only be associated with another item.
 *
 * @author Fr�d�ric Demers
 * @version 1.1 26 Aug 2001
 */
public class Processor implements Constants {
	
	/* local reference to the Grid object */
	private Grid myGrid;
	
	/**
	 * Constructor.  Accepts a reference to the data structure,
	 * in order to be able to add relationship, or retreive relationship
	 * information.
	 *
	 * @param myGrid_arg the reference to the data structure grid
	 */
	public Processor (Grid myGrid_arg) {
		myGrid = myGrid_arg;
	}
	
	/**
	 * This method loops through the various methods that perfom
	 * the analysis.  The loop is designed to cycle throught the 
	 * methods until no more change is applied to the data structure
	 * by any of the method.
	 */
	public void analyse() {
		boolean newChange=true;

		while (newChange) {
			//DEBUG
			System.out.println("Processing");
			
			newChange=false;

			if (transpose()) newChange=true;//System.out.println("this time, transpose");

			if (extend()) newChange=true;//System.out.println("this time, extend");

			if (specialCheck()) System.out.println("this time, specialCheck");
			
		}
	}

	/**
	 * This first method transposes the known information of an item
	 * to another item which has a definite match with the first one,
	 * and vice-versa.  This simply copies the known information of
	 * each of the matching items to the other ones.
	 */
	private boolean transpose() {
		System.out.println("Transpose");
		int lastValue;
		Vector answersVector = myGrid.getAnswersVector();	
		int catNumber = myGrid.getCatNumber();
		int itemNumber = myGrid.getItemNumber();
		boolean newChange = false;
		
		for (int r=0; r<answersVector.size(); r++){
			Relation currentRel	= (Relation)answersVector.elementAt(r);
			
			for (int j=0;j<catNumber;j++) {
				
				if ((j!=currentRel.cat1) && (j!=currentRel.cat2)){
					for (int i=0; i<itemNumber; i++){
						lastValue = myGrid.getRelation(currentRel.cat1,
															currentRel.item1,
															j,i);
						//checking in one direction
						if (lastValue != VALUE_UNKNOWN) {
							   if (myGrid.addRelation(lastValue,currentRel.cat2,
															currentRel.item2,
															j,i)) newChange=true;
						} //end if
						else { //checking in the other direction
							lastValue = myGrid.getRelation(currentRel.cat2,
															currentRel.item2,
															j,i);
							if (lastValue != VALUE_UNKNOWN) {
							   if (myGrid.addRelation(lastValue,currentRel.cat1,
															currentRel.item1,
															j,i))  newChange=true;
							} //end if
						} //end else
					}//end for i
				} //end if
			} //end for j
			
		} //end for r
		return newChange;
	} //end method
		
	/**
	 * This method goes through the grid to try to find quadruplets,
	 * triplets, maybe even duos and singlets.  A quadruplet is for
	 * instance a row or column within a category that has itemNumber-1
	 * negative matches.
	 */ 	
	private boolean extend() {
		System.out.println("Extend");
		Vector dummyVector = new Vector();	
		int catNumber = myGrid.getCatNumber();
		int itemNumber = myGrid.getItemNumber();
		boolean newChange = false;
		boolean yesFound = false;

		//going horizontal first to find quadruplet, triplets, maybe duos
		// THE ORIENTATION OF THE VECTOR IS WITH RESPECT TO
		// THE REVERSE GRID MODEL
		for (int c1=0; c1<catNumber; c1++)
			for (int c2=c1+1; c2<catNumber; c2++)
				for (int i1=0; i1<itemNumber; i1++){
					dummyVector.removeAllElements();
					yesFound=false;
					for (int i2=0; (i2<itemNumber && !yesFound); i2++){
						if (myGrid.getRelation(c1,i1,c2,i2)==VALUE_YES)
							yesFound=true; //in this case, change column immediately
						else if (myGrid.getRelation(c1,i1,c2,i2)==VALUE_NO)
							dummyVector.addElement(new Relation(VALUE_NO,c1,i1,c2,i2));
					} //end for
					
					if ((dummyVector.size()==itemNumber-1) && !yesFound) {
						quadruplet(dummyVector);
						newChange=true;
					} else if ((dummyVector.size()>1) && !yesFound) //unos not possible 
							if (!newChange) newChange=triplet(dummyVector);
				}// for

		//now going vertical to find quadruplet, triplet, maybe duos
		for (int c1=0; c1<catNumber; c1++)
			for (int c2=c1+1; c2<catNumber; c2++)
				for (int i2=0; i2<itemNumber; i2++){
					dummyVector.removeAllElements();
					yesFound=false;
					for (int i1=0; (i1<itemNumber && !yesFound); i1++){
						if (myGrid.getRelation(c1,i1,c2,i2)==VALUE_YES)
							yesFound=true;  // in this case, change row immediately
						else if (myGrid.getRelation(c1,i1,c2,i2)==VALUE_NO)
							dummyVector.addElement(new Relation(VALUE_NO,c1,i1,c2,i2));
					} //end for

					if ((dummyVector.size()==itemNumber-1) && !yesFound) {
						quadruplet(dummyVector);
						newChange=true;
					} else if ((dummyVector.size()>1) && !yesFound) //unos not possible 
							if (!newChange) newChange=triplet(dummyVector);
				}// end for

	return newChange;
	}// end method
		
	/**
	 * Name given for a row or column in a given category that has
	 * itemNumber-1 negative matches, which implies that a
	 * new definitive match can be added.  The aim of this 
	 * method is to find which is the relation to be added, and
	 * to add it.  The idea is to first find the orientation
	 * by examining the first two items in the vector, then
	 * looking for the element with a VALUE_UNKNOWN.
	 *
	 * @param myVector the vector of the quadruplet relation	
	 */
	private void quadruplet(Vector myVector) {
		int itemNumber = myGrid.getItemNumber();
		System.out.println("Quadruplet found itemNumber="+itemNumber);
		boolean isHorizontal;
		
		//finding orientation
		// THE ORIENTATION OF THE VECTOR IS WITH RESPECT TO
		// THE REVERSE GRID MODEL
		Relation rel1 = (Relation)myVector.elementAt(0);
		Relation rel2 = (Relation)myVector.elementAt(1);
		if ((rel1.item1==rel2.item1) && (rel1.cat1==rel2.cat1))
			isHorizontal=true;
		else isHorizontal=false;
		
		//finding empty spot
		for (int i=0; i<itemNumber;i++){
			if ((isHorizontal) && 
				(myGrid.getRelation(rel1.cat1,rel1.item1,rel1.cat2,i)==
					VALUE_UNKNOWN)) {
						myGrid.addRelation(VALUE_YES,rel1.cat1,rel1.item1,rel1.cat2,i);
					}
			else if ((!isHorizontal) &&
				(myGrid.getRelation(rel1.cat1,i,rel1.cat2,rel1.item2)==
					VALUE_UNKNOWN)) {
						myGrid.addRelation(VALUE_YES,rel1.cat1,i,rel1.cat2,rel1.item2);
					}				
		}//endfor		
	}
	
	/**
	 * Name given for a row or column in a given category that has
	 * between 1 and itemNumber-1 negative matches, which implies that a
	 * new definitive match may be found, if NO relationships
	 * are found common to the triplet elements, and added.  The aim of this 
	 * method is to find if there is a relation to be added, and
	 * to add it.  The idea is to first find the orientation
	 * by examining the first two items in the vector, then
	 * looking for the elements with VALUE_UNKNOWN to form a working
	 * vector, which will be used to determine common characteristics
	 * that could also therefore be added to the category where the
	 * triplet was found.
	 *
	 * @param myVector the vector of the triplet relation	
	 * @return whether a new relation was found
	 */
	private boolean triplet(Vector myVector) {
		System.out.println("Triplet");
		boolean isHorizontal;
		int catNumber = myGrid.getCatNumber();
		int itemNumber = myGrid.getItemNumber();
		int tripletItem1, lastValue;
		Vector workingVector=new Vector();
		boolean newChange = false;
		boolean isSimilar = true;
		
		//finding orientation
		//may have a problem when only one item in vector...
		Relation rel1 = (Relation)myVector.elementAt(0);
		Relation rel2 = (Relation)myVector.elementAt(1);

		// THE ORIENTATION OF THE VECTOR IS WITH RESPECT TO
		// THE REVERSE GRID MODEL
		if ((rel1.item1==rel2.item1) && (rel1.cat1==rel2.cat1))
			isHorizontal=true;
		else isHorizontal=false;

		for (int i=0; i<itemNumber;i++){
			if ((isHorizontal) && 
				(myGrid.getRelation(rel1.cat1,rel1.item1,rel1.cat2,i)==
					VALUE_UNKNOWN)) {
						workingVector.addElement(new Relation(VALUE_UNKNOWN,rel1.cat1,rel1.item1,rel1.cat2,i));
					}
			else if ((!isHorizontal) &&
				(myGrid.getRelation(rel1.cat1,i,rel1.cat2,rel1.item2)==
					VALUE_UNKNOWN)) {
						workingVector.addElement(new Relation(VALUE_UNKNOWN,rel1.cat1,i,rel1.cat2,rel1.item2));
					}				
		}//endfor		

		//now looking for common NO relations with the working vector
		//category of the triplet perpendicular to its orientation
		// also known as primary category
		int tripletCat1 = (isHorizontal?
			((Relation)workingVector.elementAt(0)).cat2:
			((Relation)workingVector.elementAt(0)).cat1);
		//category of the triplet in the direction of its orientation
		// also known as secondary category
		int tripletCat2 = (isHorizontal?
			((Relation)workingVector.elementAt(0)).cat1:
			((Relation)workingVector.elementAt(0)).cat2);
			
		// each triplet pair is counted twice, but no easy
		// solution has been found to prevent it
		for (int j=0;j<catNumber;j++) {
			if (j!=tripletCat1 && j!=tripletCat2){
				for (int i=0; i<itemNumber; i++){
					isSimilar = true;
					for (int r=0; (r<workingVector.size() && isSimilar); r++) {
						tripletItem1 = (isHorizontal?
									((Relation)workingVector.elementAt(r)).item2:
									((Relation)workingVector.elementAt(r)).item1);							
						lastValue = myGrid.getRelation(j,i,tripletCat1,tripletItem1);
						if (lastValue != VALUE_NO) isSimilar=false;
					}//end for r
					if (isSimilar){
						//opposite of tripletCat1 and tripletItem1
						int tripletItem2 = (isHorizontal?
							((Relation)workingVector.elementAt(0)).item1:
							((Relation)workingVector.elementAt(0)).item2);
						if (myGrid.addRelation(VALUE_NO,tripletCat2,tripletItem2,j,i)) newChange=true;
					} //end if
				} //end for i
			} //end if
		} //end for j
		return newChange;
	} //end method
	
	/**
	 * This method will go through the clues vector and reprocess the clues that have
	 * the specialClue flag to true.  If new information is derived from the clue
	 * the usage variable will be incremented
	 *
	 */
	private boolean specialCheck() {
		Vector cluesVector = myGrid.getCluesVector();
		Clue currentClue;
		boolean	newInfo =false;
		
		for (int i=0; i<cluesVector.size(); i++) {
			currentClue = (Clue)cluesVector.elementAt(i);
			if (currentClue.isSpecial()) 
				if (myGrid.getParent().getParser().parse(currentClue)) newInfo=true;
		}

	return newInfo;
	}
}