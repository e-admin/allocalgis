package puzzled.dialogs;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * This class provides the facilities to create a splash
 * screen.  The image will appear for a limited period of time in 
 * the center of the screen, and on top of all other windows.
 * The AWT and Swing versions are provided, but the AWT version
 * is preferred since provides a faster rendering of the image.
 * This class could be improved by implementing it as a Thread so
 * the application could continue loading while the splash screen is
 * displayed.
 *
 * @author David M. Geary
 * @author Fr�d�ric Demers
 * @author Guillaume Gilbert
 */
//AWT version
public class SplashScreen extends Frame {
	
	/** duration while the splash screen is displayed */
	static final int DURATION_TIME = 7000;
	
	Toolkit toolkit = Toolkit.getDefaultToolkit();
	Window  window;
	Image   image;

	/** 
	 * Default constructor.  Loads and display an image in the center
	 * of the screen.
	 */
	public SplashScreen() {
		ImageCanvas canvas;

		window  = new Window(this);
		image   = toolkit.getImage("resources/Puzzled.jpg");
		canvas  = new ImageCanvas(image);

		window.add(canvas, "Center");

		Dimension   scrnSize  = toolkit.getScreenSize();
		// finding dimensions of the image.
		int         imgWidth  = image.getWidth(this),
		            imgHeight = image.getHeight(this);
		
		// positioning the image at the center of the screen.
		window.setLocation(scrnSize.width/2  - (imgWidth/2),
		                   scrnSize.height/2 - (imgHeight/2));
		window.setSize(imgWidth,imgHeight);
		window.show();
	
		try {
			window.toFront(); // ensures the splash screen stay atop.
			Thread.currentThread().sleep(DURATION_TIME); 
		}
		catch(Exception e) {
			 e.printStackTrace();
		}

		window.dispose();
	}
}

//SWING Version

/** 
 * Default constructor.  Loads and display an image in the center
 * of the screen.
 */
/*	
public class SplashScreen extends JWindow {
	static final int DURATION_TIME = 7000;
	
	public SplashScreen() {
		super();
		
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		ImageIcon image   = new ImageIcon("resources/splash.gif");

		getContentPane().add(new JLabel(image), "Center");
		int         imgWidth  = image.getIconWidth(),
		            imgHeight = image.getIconHeight();
		
		Dimension   scrnSize  = toolkit.getScreenSize();
		setLocation(scrnSize.width/2  - (imgWidth/2),
		                   scrnSize.height/2 - (imgHeight/2));
		setSize(imgWidth,imgHeight);
		show(); // show in JWindow overrides show in Component, and is no
						// 	deprecated.  It makes both the JWindow and its owner visible
		
		try {
			toFront();
			Thread.currentThread().sleep(DURATION_TIME); 
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}*/