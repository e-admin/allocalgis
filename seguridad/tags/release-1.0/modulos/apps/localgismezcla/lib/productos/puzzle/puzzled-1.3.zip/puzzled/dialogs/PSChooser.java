package puzzled.dialogs;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import puzzled.ProblemSolver;
import puzzled.StatusPanel;
import java.io.*;

/**
 * This class represent a file chooser customized for the Powerflow
 * application.  It instantiates a PSFileFilter that will only
 * let the user see the .pfm files, as well as a PSFileView which
 * will attach the Powerflow Icon to the .pfm files.  It also sets
 * the current directory of the FileChooser to the application's
 * current directory.  This class is used both for opening and saving
 * since the constructor accepts a type as an public integer constant.
 *
 * @author Fr�d�ric Demers
 * @version 1.54 24 March 99
 */
public class PSChooser extends JFileChooser {
	/** Public constant for the Chooser type SAVE*/
	public static final int SAVE=0;
	/** Public constant for the Chooser type OPEN*/
	public static final int OPEN=1;
	
	/**
	 * Single constructor.  Accepts a reference to the parent, and a 
	 * dialog type, which is an integer represented by the constants
	 * SAVE or OPEN.
	 *
	 * @param parent a reference to the parent application
	 * @param type the chooser type
	 */
	public PSChooser(ProblemSolver parent,int type){
		super();
		
		PSFileFilter lpfFilter = new PSFileFilter("lpf", "Logic Problem Files");
		PSFileView fileView = new PSFileView();
		fileView.putIcon("lpf", new ImageIcon("resources/icon.gif"));
  	fileView.putTypeDescription("lpf","Logic Problem File");

		setCurrentDirectory(new File(parent.getStatus().directory));	
  	addChoosableFileFilter(lpfFilter);
  	setFileFilter(lpfFilter);
  	if (type==OPEN) {
  		setApproveButtonText("Open file");
			setApproveButtonMnemonic('O');
  		setDialogTitle("Open Logic Problem File");
  	}
		else if (type == SAVE) {
			setApproveButtonText("Save file");
			setApproveButtonMnemonic('S');
			setDialogTitle("Save Logic Problem File as...");
		}
  	
		setMultiSelectionEnabled(false);
    setFileView(fileView);
		
		// the user cannot select a directory.
		setFileSelectionMode(JFileChooser.FILES_ONLY);
  	
  	setFileHidingEnabled(true);
	}
}