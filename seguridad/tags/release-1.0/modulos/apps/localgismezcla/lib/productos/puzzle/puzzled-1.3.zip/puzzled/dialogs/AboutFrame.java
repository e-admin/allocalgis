package puzzled.dialogs;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import puzzled.ProblemSolver;

/**
 * This class contains the window displayed when aboutItem is
 * hit from the helpMenu.  It displays information about the authors
 * the version, and the date.
 *
 * @author Fr�d�ric Demers
 * @author Guillaume Gilbert
 * @version 1.54 24 March 99
 */
public class AboutFrame extends JDialog implements ActionListener{

	/** the Ok button that dismisses the dialog*/
	private JButton okButton;
     
	/** 
	 * Constructor.  Establishes the appearance of the frame.
	 */
	public AboutFrame(ProblemSolver parent) {
		
		super(parent,"About Puzzled",true);
		setBackground(Color.white);
		Container contentPane = getContentPane();
		Point p = new Point(260,200);  // location for myFrame
		setLocation(p); 
		setSize(300,350);
		contentPane.setLayout(new BorderLayout());
		
		contentPane.setBackground(Color.white);
	
		
		JPanel textPanel = new JPanel();
		textPanel.setBackground(Color.white);
		putText(textPanel);
		
	
		//contains the text and button
		
		JPanel buttonPanel = new JPanel(new FlowLayout());
		
		okButton = new JButton("OK");
		Dimension size = new Dimension(70,30);
		okButton.setMinimumSize(size);
		okButton.setMaximumSize(size);
		okButton.setPreferredSize(size);
		okButton.addActionListener(this);
		okButton.setForeground(Color.black);
		okButton.setBackground(Color.white);
		buttonPanel.add(okButton);
		buttonPanel.setBackground(Color.white);
		
		contentPane.add(textPanel, BorderLayout.CENTER);
		contentPane.add(buttonPanel, BorderLayout.SOUTH);

		
		JPanel topPanel = new JPanel();
		ImageIcon image   = new ImageIcon("resources/Puzzled.jpg");

		topPanel.add(new JLabel(image));
		topPanel.setBackground(Color.white);
		contentPane.add(topPanel,BorderLayout.NORTH);
		
  	setVisible(false);
  	enableEvents(AWTEvent.WINDOW_EVENT_MASK);
  }

	/**
	 * Method handling the writing of the text in the dialog box.
	 * The text contains important information about the software,
	 * its authors, and date realized.
	 * @param p the panel which contains the text
	 */
	public void putText (JPanel p) {
		JLabel label = null;

		Font f1 = new Font("Helvetica", Font.BOLD, 18);
		Font f2 = new Font("Helvetica", Font.PLAIN, 14);
		Font f3 = new Font("Arial", Font.BOLD,14);
		
		p.setLayout(new GridLayout(8,1));
		
		label = new JLabel("Version 1.0 alpha",SwingConstants.CENTER);
		label.setForeground(Color.blue);
		label.setFont(f3);
		p.add(new JLabel(""));
		p.add(label);
		
		
		label = new JLabel("Created by Fr�d�ric Demers",SwingConstants.CENTER);
		label.setForeground(Color.blue);
		label.setFont(f2);
		p.add(new JLabel(""));
		p.add(label);
		
		
		label = new JLabel("20 August 2001", SwingConstants.CENTER);
		label.setForeground(Color.red);
		label.setFont(f2);
		p.add(new JLabel(""));		
		p.add(label);
	}
	
	
	/**	Responds to user actions to close the frame and hides it.*/
	public void processWindowEvent(WindowEvent event) {
   	super.processWindowEvent(event); // Handle listeners
    	if (event.getID() == WindowEvent.WINDOW_CLOSING)
      	this.dispose();
  }

	/**	
	 * Responds to user actions when the Ok button is clicked
	 * and hides the frame.
	 */
	public void actionPerformed(ActionEvent evt) {
		if (evt.getSource() == okButton) this.dispose();
	}
}