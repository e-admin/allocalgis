package puzzled;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.lang.Boolean.*;
import java.lang.Integer.*;
import java.lang.String.*;
import javax.swing.*;
import puzzled.grid.Grid;
import puzzled.actions.ActionManager;
import puzzled.dialogs.*;
import puzzled.processor.Parser;

/**
 * The ProblemSolver application is GUI allowing a user to solve a logic
 * problem
 *
 * @author Fr�d�ric Demers
 * @version 1.1 26 Aug 2001
 */
public class ProblemSolver extends JFrame {

	/**
	 * Class containing important application information such as window location,
	 * window size, look and feel, current working directory.  The information is 
	 * saved in a .ini file on exit and retreived from the disk when opening.
	 * Information from this class is accessible directly without accessor method.
	 * This approach was preferred for simplicity's sake, and since this object only
	 * uses methods to save and retreive the information from the .ini file.
	 */
	private Status status = new Status(this);

	
	/**
	 * This class builds the toolbar and the menu bar using a defined set of 
	 * actions.  Actions allow one to add the same action to both a toolbar
	 * and a menu bar and allow one to disable an action in itself instead of
	 * disabling a JMenuItem and a JButton
	 */
	public ActionManager actionManager;	

	/** 
	 * The scroll pane wrapping the grid.  It allows
	 * the user to use a grid bigger than the main window's size.
	 */
	private JScrollPane gridScrollPane,answerScrollPane;

	private JTabbedPane tabbedPane;
	
	/** The application's toolbar.*/
	public JToolBar myTools = new JToolBar();
	
	/** The application's menu bar.*/
	public JMenuBar myMenuBar = new JMenuBar();
	
	/**
	 * The grid itself, containing the relationships between
	 * the items
	 */
	private Grid myGrid;
	
	/** Application information displayed at the bottom of the window*/
	private StatusPanel statusLine;
	
	/** Panel used for inputing/ reviewing hints*/
	private InputPanel inputLine;
		
	/** Title string*/
	static public final String titleString=new String("Puzzled - ");
	
	/** Default worksheet name.*/
	static public final String noNameString=new String("Untitled.lpf");

	
	/**
	 * Default constructor.  Calls the JFrame's constructor with a default
	 * string as title.  It creates the main object that interact with the
	 * application such as the worksheet, the status bar, and the actionManager.
	 * It creates the scroll pane used around the grid, and request a status
	 * status object which will load the information from the solver.ini file,
	 * or use the default settings the file cannot be read.
	 */
	public ProblemSolver() {
		super(titleString+" "+noNameString);
		
		tabbedPane = new JTabbedPane();
		
		/**
		 * The presence of an innerPanel is necessary because of the dockable
		 * property of the toolbar.  The Java 2 API suggests to have a Container
		 * using a BorderLayout with nothing in either of the four sides in order
		 * to see the correct behaviour of the toolbar. It contains the worksheet
		 * in its center, and the toolbar, in one of its borders.
		 */
		JPanel innerPanel = new JPanel(new BorderLayout());
		
	    setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		// this following methods seems to crash through Solstice PC X-ware 4.01
		setIconImage(new ImageIcon("resources/icon.gif").getImage());
		
		DialogMaster.setParent(this);
		
		myGrid = new Grid(this);

	    //initialize(myGrid); //load status or take default if fileException
		
		getContentPane().setLayout(new BorderLayout());
		inputLine = new InputPanel(this);
		statusLine = new StatusPanel();
		
		//instantiates the toolbar with the proper orientation,
		//using the ternary operator test?trueresult:falseresult
		myTools = new JToolBar(
			(status.toolBarPos.equals(BorderLayout.EAST)
				|| status.toolBarPos.equals(BorderLayout.WEST))?//test
			JToolBar.VERTICAL: //trueresult
			JToolBar.HORIZONTAL);//falseresult

		actionManager = new ActionManager(this);

		gridScrollPane = new JScrollPane(myGrid.getGridCanvas(),
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

		gridScrollPane.getVerticalScrollBar().setUnitIncrement(10);
		gridScrollPane.getHorizontalScrollBar().setUnitIncrement(10);

		answerScrollPane = new JScrollPane(myGrid.getAnswerCanvas(),
				JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

		answerScrollPane.getVerticalScrollBar().setUnitIncrement(10);
		answerScrollPane.getHorizontalScrollBar().setUnitIncrement(10);


		getContentPane().add(myTools,status.toolBarPos);
		if (!status.toolBarVisible) hideTools();

		setJMenuBar(myMenuBar);  // select myMenuBar to be the default one
		
		JPanel southPanel = new JPanel(new BorderLayout());
		southPanel.add(inputLine,BorderLayout.NORTH);
		southPanel.add(statusLine,BorderLayout.SOUTH);

		tabbedPane.add("Relations",gridScrollPane);
		tabbedPane.add("Answers",answerScrollPane);
		
		innerPanel.add(tabbedPane,BorderLayout.CENTER);
		innerPanel.add(southPanel,BorderLayout.SOUTH);

		getContentPane().add(innerPanel,BorderLayout.CENTER);
		
		if (!status.fileName.equals(noNameString) &&
					(status.loadPrevious))
						actionManager.triggerOpen(new File(status.directory,status.fileName));
		else enableCloseSave(false);	

		Point p = new Point(status.windowPosx,status.windowPosy);  // location for mainFrame
		setLocation(p); // set location for mainFrame
		
		setSize(status.windowWidth,status.windowHeight);

		/*
		 * The following code creates a splash screen and displays it, on
		 * top of all windows for +/-5 seconds before showing up
		 * the application.
		 */
		//SplashScreen mySplashScreen = new SplashScreen();

		setVisible(true);
		statusLine.setText("Application ready");
		addWindowListener(
	  	new AppWindowAdapter(this));
	  	
	}

	/**
	 * Static method called at startup.
	 * Instantiates the application, a ProblemSolver object.
	 * @param argv Command line parameters passed when starting the application.
 	 */
	public static void main (String argv[]) {
		new ProblemSolver();
	}


	/**
	 * Used only for debugging purposes.  Will initialize the tables
	 * with a reference problem so the user doesn't need to type them in
	 */
	/*public void initialize(Grid aGrid) {

		/* This sample problem comes from the book:
		 * Logic Problem ...
		 * It is problem number 47 - Booking time and
		 * was chosen at random ...
		 */
				
	/*	aGrid.setCatNumber(5);
		aGrid.setItemNumber(5);
		aGrid.setCategory(0,"Book");
		aGrid.setCategory(1,"First Name");
		aGrid.setCategory(2,"Last Name");
		aGrid.setCategory(3,"Genre");
		aGrid.setCategory(4,"Pages");
		
		aGrid.setItem(0,0,"Haley's Comet");
		aGrid.setItem(0,1,"Into the Fire");
		aGrid.setItem(0,2,"Never Again");
		aGrid.setItem(0,3,"Passion Play");
		aGrid.setItem(0,4,"Starburst");
		
		aGrid.setItem(1,0,"Bethany");
		aGrid.setItem(1,1,"Donovan");
		aGrid.setItem(1,2,"Elizabeth");
		aGrid.setItem(1,3,"Frederic");
		aGrid.setItem(1,4,"Peyton");

		aGrid.setItem(2,0,"Chapman");
		aGrid.setItem(2,1,"Holden");
		aGrid.setItem(2,2,"Koenig");
		aGrid.setItem(2,3,"Rawlins");
		aGrid.setItem(2,4,"Wright");

		aGrid.setItem(3,0,"Biography");
		aGrid.setItem(3,1,"Fantasy");
		aGrid.setItem(3,2,"Mystery");
		aGrid.setItem(3,3,"Romance");
		aGrid.setItem(3,4,"Science-Fiction");

		aGrid.setItem(4,0,"15");
		aGrid.setItem(4,1,"16");
		aGrid.setItem(4,2,"17");
		aGrid.setItem(4,3,"18");
		aGrid.setItem(4,4,"19");
		
		aGrid.generateCanvases();

	}*/

	/**
	 * Sets the text passed as parameter in the application's status
	 * bar.
	 * @param s the message to be displayed in the status bar
	 */
	public void setStatusMessage(String s) {
		statusLine.setText(s);
	}

	/**
	 * Gets the text displayed in the application's status
	 * bar.
	 * @return the string of the status bar
	 */
	public String getStatusMessage() {
		return statusLine.getText();
	}

	
  	/**
	 * Method invoked to change the application's look and feel.
	 * @param LAF_arg String representing the new look and feel to be used
	 */
	public void updateLAF(String LAF_arg) {
		try {
			UIManager.setLookAndFeel(LAF_arg);
			SwingUtilities.updateComponentTreeUI(this);
			status.lookAndFeel = LAF_arg;
			actionManager.updatePopupLAF(LAF_arg);
		//the look and feel requested is not supported by the platform
		// setting default 
		} catch (Exception exc) {
 			try {
 				UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
				SwingUtilities.updateComponentTreeUI(this);
  			DialogMaster.showDialog(DialogMaster.UNSUPPORTED_LAF, LAF_arg);
				status.lookAndFeel = "javax.swing.plaf.metal.MetalLookAndFeel";
 				actionManager.updatePopupLAF(LAF_arg);
 			//default look and feel not supported either!
 			} catch (Exception exc2) {
 				System.out.println("Default LAF not supported exiting");
 				System.exit(0);
 			}
		}
	}

	
	/** Method used to save permanent information in the INI file.*/
	public void saveStatus() {
		status.saveStatus();
	}
	
	public Status getStatus() {
		return status;
	}
	
	public void quit() {
		if (myGrid.isDirty()) { //worksheet needs to be saved, ask user
			File theFile= myGrid.getCurrentFile();
			int answer = DialogMaster.showDialog(DialogMaster.SAVE,theFile);
			if (answer==JOptionPane.YES_OPTION){
				if (theFile.getName().equals(noNameString))
					actionManager.triggerSaveAs();
				else 
					try {
						myGrid.saveGrid(theFile);
					} catch (IOException ioe) {
						DialogMaster.showDialog(DialogMaster.SAVING_ERROR);
						actionManager.triggerSaveAs();
					}
			}
			if (answer != JOptionPane.CANCEL_OPTION) { //if user selects cancel, return to app.
				status.saveStatus();
				System.exit(0);
			}
			else {return;} /* user selects cancel */
		} else { // worksheet needs not to be saved - exits right away
				status.saveStatus();
				System.exit(0);
		}
	}
	
	public void refresh() {
		if (myGrid.getGridCanvas()==null) {
			gridScrollPane.setViewportView(new JPanel());
			answerScrollPane.setViewportView(new JPanel());
		} else {
			gridScrollPane.setViewportView(myGrid.getGridCanvas());
			answerScrollPane.setViewportView(myGrid.getAnswerCanvas());
		}
		//DEBUG
		//System.out.println("repainting the tabbedPane");
		setTitle(titleString+myGrid.getCurrentFile().getName());
		
		this.validate();
		tabbedPane.repaint();
	}
	
	/**
	 * Invoked when the user selects or the saved preferences indicate
	 * indicate that the user does not wish to see the toolbar.
	 */
	public void hideTools() {
		status.toolBarVisible = false;
		myTools.setVisible(false);
		this.validate();
	}

	/**
	 * Invoked when the user selects or the saved preferences indicate
	 * indicate that the user wishes to see the toolbar.
	 */
	public void showTools() {
		status.toolBarVisible = true;
		myTools.setVisible(true);
		this.validate();
	}
	
	/** 
	 * Takes care of changing the application's title bar in order to reflect
	 * the status of the worksheet.  A dirty worksheet is one that changed
	 * since it was last saved.  It is represented by a * at the end of 
	 * the file name.
	 * @param dirty the worksheet is dirty
	 */
	public void setGridDirty(boolean dirty) {
		if (dirty) {
			setTitle(titleString+myGrid.getCurrentFile().getName()+"*");
			setStatusMessage("File "+ myGrid.getCurrentFile().getName() +" modified");	
		}
		else
				setTitle(titleString+myGrid.getCurrentFile().getName());
		myGrid.setDirty(dirty);
	}

	/**
	 * Method used to find which Border of the innerPanel contains the
	 * toolbar in order to save its current location when exiting.
	 * @return a string identifying the toolbar position
	 */
	public String findToolbarPos(){
		if (myTools.getBounds().x > 0)
			return BorderLayout.EAST;
		else if (myTools.getBounds().y > 0)
			return BorderLayout.SOUTH;
		else if (myTools.getOrientation() == SwingConstants.HORIZONTAL)
			return BorderLayout.NORTH;
		else return BorderLayout.WEST;
	}

	/**
	 * Method used to return the grid object.
	 * It is used by the parser and processor in order to be able
	 * to call method on the grid object.  The grid object is a data structure
	 * containing all relationships.
	 * @return the grid object
	 */
	public Grid getGrid() {
		return myGrid;
	}

	public void setGrid(Grid grid_arg) {
		myGrid = grid_arg;
		//need to make the parser aware of the change...
		inputLine.relink();
		refresh();
	}


	public void removeGrid() {
		setGrid(new Grid(this));
		refresh();
	}
	
	public void enableCloseSave(boolean enable_arg)  {
		actionManager.enableCloseSave(enable_arg);
	}
		
	/** returns the tabbedPane object */
	public JTabbedPane getTabbedPane() {
		return tabbedPane;
	}
	
	/**
	 * Returns a reference to the parser usually kept only by the InputPanel object
	 * Required by the processor in order to be able to have the special clues
	 * parsed at every new clue entered.
	 */
	public Parser getParser()  {
		return inputLine.getParser();
	} 

}


/**
 * WindowAdapter class which handles only the closing of the window using the
 * x in the top-right corner.
 */
class AppWindowAdapter extends WindowAdapter {
	ProblemSolver parent;
	
	/** constructor for the window adapter */
	public AppWindowAdapter (ProblemSolver parent_arg) {
		parent = parent_arg;
	}
	
	/** Handles properly the closing of the window by calling owner's quit method */
	public void windowClosing(WindowEvent e) {
		parent.quit();
 	}
}