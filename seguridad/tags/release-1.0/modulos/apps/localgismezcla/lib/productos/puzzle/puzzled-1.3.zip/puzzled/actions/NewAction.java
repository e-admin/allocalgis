package puzzled.actions;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import puzzled.ProblemSolver;
import puzzled.dialogs.*;
import puzzled.grid.*;

/**
 * The NewAction class is composed of a string and an icon, and is
 * added to the menu bar and the toolbar.  It has the action
 * performed method that is called when the menu item or button is clicked.
 *
 * @author Fr�d�ric Demers
 * @version 1.54
 */
public class NewAction extends AbstractAction {
	ProblemSolver parent;
	
	int saveAnswer;
	

	/**
	 *
	 *
	 * @param   parent_arg  
	 */
	public NewAction(ProblemSolver parent_arg) {
		super("New",new ImageIcon("resources/new.gif"));
		parent = parent_arg;
	}
	

	/**
	 *
	 *
	 */
	private void saveDirty() {

		if (parent.getGrid()!=null && parent.getGrid().isDirty()) {
			File theFile= parent.getGrid().getCurrentFile();
			saveAnswer = DialogMaster.showDialog(DialogMaster.SAVE,theFile);
			if (saveAnswer == JOptionPane.CANCEL_OPTION) { //if user selects cancel, return to app.
				return;
			}
			if (saveAnswer==JOptionPane.YES_OPTION){
					parent.actionManager.triggerSave();
			}
		}
	}

	public void actionPerformed(ActionEvent e) {
	  	saveDirty();
		
		Grid newGrid= new Grid(parent);
		ProblemConfig problemConfig = new ProblemConfig(parent, newGrid);
		if (problemConfig.showConfigDialog()) {
			parent.setGrid(newGrid);
			newGrid.generateCanvases();
			parent.setStatusMessage("New file created");
			parent.setTitle(parent.titleString + 
				parent.getGrid().getCurrentFile().getName());
			parent.refresh();
			parent.enableCloseSave(true);
		}
	}

}