package puzzled.dialogs;

import java.awt.*;
import java.awt.event.*;

/**
 * This class represent a simple image canvas that loads an
 * image before displaying it.  Modified for Powerflow by Demers
 * & Gilbert.
 *
 * @author David Geary
 *
 * @version 1.54 24 March 99
 */
class ImageCanvas extends Canvas {
    /** The actual image is kept as a local private variable.*/
    private Image image;

    public ImageCanvas(Image image) {
		MediaTracker mt = new MediaTracker(this);
		mt.addImage(image, 0);

		try                { mt.waitForID(0);     } 
		catch(Exception e) { e.printStackTrace(); }

		this.image = image;
    }
    
    /** Draws the image on the grapics context.*/
    public void paint(Graphics g) {
        g.drawImage(image, 0, 0, this);
    }

    /** Draws the image on the grapics context.*/
    public void update(Graphics g) {
        paint(g);
    }
		
		/**
		 * Method used to obtain the dimensions of the image.
		 * @return the dimensions of the image.
		 */
		public Dimension getPreferredSize() {
			return new Dimension(image.getWidth(this),
		                     image.getHeight(this));
	}
}