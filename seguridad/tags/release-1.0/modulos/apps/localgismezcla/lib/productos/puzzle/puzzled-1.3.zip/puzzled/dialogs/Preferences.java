package puzzled.dialogs;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import puzzled.ProblemSolver;

/**
 * This class displays the dialog allowing the user to view/modify
 * the program preferences.  The different preferences that can be set
 * are :
 * <UL>
 * <LI>Toolbar visibility.
 * <LI>Look and feel.
 * <LI>Name display - the names of the element can be displayed on the 
 * worksheet.
 * <LI>Values display - the values of the element can be displayed on the
 * worksheet.
 * </UL>
 *
 * @author Fr�d�ric Demers
 * @version 1.54 24 March 99
 */
public class Preferences  {

	private JCheckBox toolBarButton;
	private JCheckBox caseSensitiveCB;
	private JCheckBox displayRelationsCB;
	private JCheckBox loadPreviousCB;
	
	private ButtonGroup lookAndFeelGroup;
	private LAFRadioButton javaButton;
	private LAFRadioButton motifButton;
	private LAFRadioButton windowsButton;
	
	private ProblemSolver parent;
	
	/** 
	 * Single constructor.  It accepts a reference to the parent
	 * application as a parameter.
	 *
	 * @param a reference to the parent application.
	 */
	public Preferences(ProblemSolver parent_arg) {
		parent = parent_arg;
		
		//overall container		
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());

		JPanel topPanel = new JPanel(new GridLayout(1,0,2,2));
		
			JPanel toolBarPanel = new JPanel();
			toolBarPanel.setBorder(BorderFactory.createTitledBorder("ToolBar"));
		  toolBarButton = new JCheckBox("Show Toolbar");
	    toolBarButton.setMnemonic('T'); 
	    toolBarButton.setSelected(parent.getStatus().toolBarVisible);
			toolBarPanel.add(toolBarButton,BorderLayout.CENTER);
		
		topPanel.add(toolBarPanel);

			JPanel lookAndFeelPanel = new JPanel();
			lookAndFeelPanel.setBorder(BorderFactory.createTitledBorder("Look And Feel"));
			lookAndFeelPanel.setLayout(new GridLayout(0, 1));
			
			lookAndFeelGroup = new ButtonGroup();
			
			javaButton = new LAFRadioButton("Java","javax.swing.plaf.metal.MetalLookAndFeel");
	    javaButton.setMnemonic('J');
	    if (parent.getStatus().lookAndFeel.equals(javaButton.getLookAndFeel())) javaButton.setSelected(true);
			
			windowsButton = new LAFRadioButton("Windows","com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
	    windowsButton.setMnemonic('W');
	    if (parent.getStatus().lookAndFeel.equals(windowsButton.getLookAndFeel())) windowsButton.setSelected(true);
	    
			motifButton = new LAFRadioButton("Motif","com.sun.java.swing.plaf.motif.MotifLookAndFeel");
	    motifButton.setMnemonic('M');
	    if (parent.getStatus().lookAndFeel.equals(motifButton.getLookAndFeel())) motifButton.setSelected(true);
	    
			lookAndFeelGroup.add(javaButton);
			lookAndFeelPanel.add(javaButton);
			lookAndFeelGroup.add(windowsButton);
			lookAndFeelPanel.add(windowsButton);
			lookAndFeelGroup.add(motifButton);
			lookAndFeelPanel.add(motifButton);
		
		topPanel.add(lookAndFeelPanel);

		JPanel centerPanel = new JPanel();
		centerPanel.setBorder(BorderFactory.createTitledBorder("Display Options"));
	  
	  caseSensitiveCB = new JCheckBox("Case Sensitive");
    caseSensitiveCB.setMnemonic('C'); 
    caseSensitiveCB.setSelected(parent.getStatus().caseSensitive);
		centerPanel.add(caseSensitiveCB);
		
	  displayRelationsCB = new JCheckBox("Display Relations");
    displayRelationsCB.setMnemonic('D'); 
    displayRelationsCB.setSelected(parent.getStatus().displayRelations);
		centerPanel.add(displayRelationsCB);

		JPanel bottomPanel = new JPanel();
		bottomPanel.setBorder(BorderFactory.createTitledBorder("General Options"));
	  
	  loadPreviousCB = new JCheckBox("Load previous problem on start");
    loadPreviousCB.setMnemonic('L'); 
    loadPreviousCB.setSelected(parent.getStatus().loadPrevious);
		bottomPanel.add(loadPreviousCB);
		
		panel.add(topPanel,BorderLayout.NORTH);
		panel.add(centerPanel,BorderLayout.CENTER);
		panel.add(bottomPanel,BorderLayout.SOUTH);
		
		int value = JOptionPane.showConfirmDialog(parent,
				panel,
					"Application Preferences",
						JOptionPane.OK_CANCEL_OPTION,
						JOptionPane.PLAIN_MESSAGE
						);

		if (value == JOptionPane.OK_OPTION){
			if (parent.getStatus().toolBarVisible ^ toolBarButton.isSelected()) 
				//there is a change in the toolbar status (^= XOR)
				if (toolBarButton.isSelected()) parent.showTools();
				else 
					parent.hideTools();
			
			if (parent.getStatus().displayRelations ^ displayRelationsCB.isSelected()){
				//there is a change in the display relations option (^= XOR)
				parent.getStatus().displayRelations = displayRelationsCB.isSelected();
				parent.refresh();
			}
			
			if (parent.getStatus().caseSensitive ^ caseSensitiveCB.isSelected()){
				//there is a change in the display values option (^= XOR)
				parent.getStatus().caseSensitive = caseSensitiveCB.isSelected();
			}

			if (parent.getStatus().loadPrevious ^ loadPreviousCB.isSelected()){
				//there is a change in the display values option (^= XOR)
				parent.getStatus().loadPrevious = loadPreviousCB.isSelected();
			}


			if (!getSelectedLAFButton().getLookAndFeel().equals(parent.getStatus().lookAndFeel)) 
				parent.updateLAF(getSelectedLAFButton().getLookAndFeel());
		}

  }


  /**
   * This method returns the selected look and feel button.  The user
   * can choose between the three main look and feels in this dialog
   * box, and this method is used to retreive wich of the radio button
   * identifying a look and feel is selected.
   *
   * @return the radio button corresponding to the selected LAF
   */
	private LAFRadioButton getSelectedLAFButton(){
		if (motifButton.isSelected()) return motifButton;
		if (windowsButton.isSelected()) return windowsButton;
		return javaButton;
	}
}