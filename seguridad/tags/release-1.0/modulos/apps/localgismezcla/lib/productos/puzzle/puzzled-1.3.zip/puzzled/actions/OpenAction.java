package puzzled.actions;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import puzzled.ProblemSolver;
import puzzled.dialogs.*;
import puzzled.grid.Grid;

/**
 * The OpenAction class is composed of a string and an icon, and is
 * added to the menu bar and the toolbar.  It has the action
 * performed method that is called when the menu item or button is clicked.
 *
 * @author Fr�d�ric Demers
 * @version 1.54
 */
public class OpenAction extends AbstractAction {
	private ProblemSolver parent;
	private int saveAnswer=0;
	
	public OpenAction(ProblemSolver parent_arg) {
		super("Open",new ImageIcon("resources/open.gif"));
		parent = parent_arg;
	}
	
	public void saveDirty() {
		if (parent.getGrid().isDirty()) {
			File theFile= parent.getGrid().getCurrentFile();
			saveAnswer = DialogMaster.showDialog(DialogMaster.SAVE,theFile);
			if (saveAnswer == JOptionPane.CANCEL_OPTION)  //if user selects cancel, return to app.
				return;
			
			if (saveAnswer==JOptionPane.YES_OPTION)
					parent.actionManager.triggerSave();
		}//if dirty
	}
	
	
  public void actionPerformed(ActionEvent e) {
    PSChooser chooser;
	saveDirty();
  	
	if (saveAnswer != JOptionPane.CANCEL_OPTION) {

		chooser = new PSChooser(parent,PSChooser.OPEN);
	  	boolean valid = false;
	  	while (!valid) {
				int retval = chooser.showDialog(parent,null);
				if(retval == JFileChooser.APPROVE_OPTION) {
		    	File theFile = chooser.getSelectedFile();
					parent.getStatus().directory = theFile.getParent();
					String name = theFile.getName();

					if (!name.endsWith(".lpf")){
						theFile = new File(theFile.getPath() + ".lpf"); //appends .lpf if not there
						name = theFile.getName();
					}
					
					if (theFile.exists()) 
						valid=open(theFile);
			
					else { // file does not exist: asks the user if it should be created.
						if (DialogMaster.showDialog(DialogMaster.CREATE,theFile) 
									== JOptionPane.YES_OPTION) {
									valid = true;
									parent.removeGrid();
									parent.setStatusMessage("Creating new file...");
									//parent.actionManager.triggerNew(theFile);
						} //if we should create new file
					} //else
			
				} else valid = true; //user selects cancel
	  	}  //end while
  	} // if the user did not want to open a model anymore (after saveDirty()).
  } //end method
  	
  public boolean open(File theFile) {
		String name = theFile.getName();

		try {
			parent.setStatusMessage("Loading file "+name+"... Please be patient");
			parent.setGrid(new Grid(parent,theFile));
			if (!parent.getGrid().getCurrentFile().getName().equals(parent.noNameString)) parent.setStatusMessage("File opened");
			parent.refresh();
			
			parent.setStatusMessage("File "+ name + " loaded");
//			System.out.println("opening succeeded");
			parent.enableCloseSave(true);			
			return true;		
		} catch (Exception p) {
			DialogMaster.showDialog(DialogMaster.INVALID_FILE,theFile);
			//new file
			parent.removeGrid();
			parent.setStatusMessage("File cannot be loaded");
			parent.setGridDirty(false);
			parent.enableCloseSave(false);
			return false;
		}

  
  }
} //end class