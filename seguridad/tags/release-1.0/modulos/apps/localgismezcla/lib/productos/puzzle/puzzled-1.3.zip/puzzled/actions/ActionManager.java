package puzzled.actions;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.swing.*;
import puzzled.ProblemSolver;

/**
 * Class responsible for initializing the action required by
 * the application in order to build the menu bar, the toolbar, and
 * the popub menu.  It also has a few method for enabling or
 * disabling some widgets depending on the state of the application.
 *
 * @author Fr�d�ric Demers
 * @version 1.54 24 March 99
 */

public class ActionManager {
	/** Reference to the application.*/
	private ProblemSolver parent;
	/** Menu bar */
	private JMenuBar menu;
	/** Tool bar*/
	private JToolBar tools;  
	/** Different menus for the application*/
	private JMenu fileMenu, editMenu, helpMenu;
	
	/* All actions required for the application */
	private NewAction newAction;
  	private OpenAction openAction;
 	private SaveAction saveAction;
	private PrintAction printAction;
	private SaveAsAction saveAsAction;
	private ExitAction exitAction;
	private CloseAction	closeAction;

	private PropertiesAction propertiesAction;
	private PreferencesAction preferencesAction;
	
	private HelpAction helpAction;
	private AboutAction aboutAction;

	//used when defining the accelerator for keys without a mask
	static final private int NO_MASK=0;
	
	/**
	 * Constructor receiving the application reference as a parameter.  This
	 * constructor then saves this reference as a private instance variable
	 * so that the other methods can call the application's public methods.
	 *
	 * @param arg_parent the application reference used for callbacks
	 */
	public ActionManager(ProblemSolver parent_arg) {
        
		parent = parent_arg;
  	//Create the toolbar and menu using the application's 
  	//own menu and toolbar references.
    tools = parent.myTools;
    menu = parent.myMenuBar;
       
    fileMenu = new JMenu("File",true);
		fileMenu.setMnemonic('F');
		editMenu = new JMenu("Edit",true);
		editMenu.setMnemonic('E');
		helpMenu = new JMenu("Help",true);
		helpMenu.setMnemonic('H');
		
		menu.add(fileMenu);
		menu.add(editMenu);
		menu.add(helpMenu);
		
		defineActions();
    	createFileMenu();
		createEditMenu();
		createHelpMenu();
		createToolbar();
	}
		
		
	/**
	 * Initialize the actions
	 */
	private void defineActions() {
        
		newAction = new NewAction(parent);
		openAction = new OpenAction(parent);
		saveAction = new SaveAction(parent);
 		saveAsAction = new SaveAsAction(parent);
 		printAction = new PrintAction(parent);
		exitAction = new ExitAction(parent);
		closeAction = new CloseAction(parent);

 		preferencesAction = new PreferencesAction(parent);
 		propertiesAction = new PropertiesAction(parent);

		helpAction = new HelpAction(parent); 
		aboutAction = new AboutAction(parent);
	}
    
	/**
	 * Creates the toolbar by adding the actions onto the
	 * toolbar.  The icons are grouped and separated by a separator.
	 */
	protected void createToolbar() {
    JButton button;
		
    button = tools.add(newAction);
    button.setText(""); //an icon-only button
    button.setToolTipText("New file");

	setMySize(button);
	
    button = tools.add(openAction);
    button.setText(""); //an icon-only button
    button.setToolTipText("Open file");
	setMySize(button);

	button = tools.add(saveAction);
    button.setText(""); //an icon-only button
    button.setToolTipText("Save file");
	setMySize(button);

    button = tools.add(printAction);
    button.setText(""); //an icon-only button
    button.setToolTipText("Print file");
	setMySize(button);

    tools.addSeparator();

	button = tools.add(propertiesAction);
    button.setText(""); //an icon-only button
    button.setToolTipText("Problem configuration");
	setMySize(button);

	button = tools.add(preferencesAction);
    button.setText(""); //an icon-only button
    button.setToolTipText("Preferences");
	setMySize(button);

	tools.addSeparator();  
		
	button = tools.add(helpAction);
    button.setText(""); //an icon-only button
    button.setToolTipText("Help");
	setMySize(button);

	button = tools.add(aboutAction);
    button.setText(""); //an icon-only button
    button.setToolTipText("About Problem Solver");
	setMySize(button);

	}

	/**
	 * Method defining the File Menu, its keyboard accelerators, and
	 * shortcuts.
	 */
	protected void createFileMenu() {
    JMenuItem menuItem = null;

    menuItem = fileMenu.add(newAction);
    menuItem.setMnemonic('N');
   	menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,
				Event.CTRL_MASK));
	
    menuItem = fileMenu.add(openAction);
    menuItem.setMnemonic('O');
    menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,
				Event.CTRL_MASK));
	
    menuItem = fileMenu.add(saveAction);
    menuItem.setMnemonic('S');
	menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
				Event.CTRL_MASK));
		
	menuItem = fileMenu.add(saveAsAction);
	menuItem.setMnemonic('A');

	menuItem = fileMenu.add(closeAction);
	menuItem.setMnemonic('C');

    menuItem = fileMenu.add(printAction);
    menuItem.setMnemonic('P');
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P,
				Event.CTRL_MASK));
	
		fileMenu.addSeparator();
		menuItem = fileMenu.add(exitAction);
    menuItem.setMnemonic('X');
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,
				Event.CTRL_MASK+Event.SHIFT_MASK));
	}
    
    
	/**
	 * Method defining the Edit Menu, its keyboard accelerators, and
	 * shortcuts.
	 */
  protected void createEditMenu() {
    JMenuItem menuItem = null;

		menuItem = editMenu.add(propertiesAction);
		menuItem.setMnemonic('P');

 		editMenu.addSeparator();

		menuItem = editMenu.add(preferencesAction);
		menuItem.setMnemonic('R');

	}

	/**
	 * Method defining the Help Menu, its keyboard accelerators, and
	 * shortcuts.
	 */
   protected void createHelpMenu() {
        JMenuItem menuItem = null;

    	menuItem = helpMenu.add(helpAction);
        menuItem.setMnemonic('H');
		menuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1,
						NO_MASK));
        
    	helpMenu.addSeparator();
    	menuItem = helpMenu.add(aboutAction);
    	menuItem.setMnemonic('A');
	}
	
	/** 
	 * Since the popup is built before the LAF is loaded, an explicit
	 * call to update its LAF is necessary
	 */
	public void updatePopupLAF(String LAF_arg) {
	/* The fact that the Popup does not change its LAF seems
	 * to be a bug of the Java API
	 */
	}
	
	/** 
	 * This method creates a new event to simulate a SaveAs action.  It is
	 * used when the user request to save the worksheet that has been modified
	 * but has not provided a name other than the noNameString defined in Powerflow.
	 */
	public void triggerSaveAs() {
		saveAsAction.actionPerformed(
			new ActionEvent(saveAsAction,
				ActionEvent.ACTION_PERFORMED, null));
	}

	/** 
	 * This method creates a new event to simulate a Save action.  It is
	 * used when the user request to save the worksheet that has been modified.
	 */
	public void triggerSave() {
		saveAction.actionPerformed(
			new ActionEvent(saveAction,
				ActionEvent.ACTION_PERFORMED, null));
	}


	public void triggerOpen(File aFile) {
		openAction.open(aFile);	
	}
	
	public void triggerNew(File theFile) {
		newAction.actionPerformed(
			new ActionEvent(newAction,
				ActionEvent.ACTION_PERFORMED, null));
		parent.getGrid().setCurrentFile(theFile);
		parent.actionManager.triggerSave();
	}
	
	public void enableCloseSave(boolean enable_arg)  {
	
	if (enable_arg)  {
		closeAction.setEnabled(true);
		saveAction.setEnabled(true);
		saveAsAction.setEnabled(true);
		openAction.setEnabled(false);
		newAction.setEnabled(false);
		
	} else  {
		closeAction.setEnabled(false);
		saveAction.setEnabled(false);
		saveAsAction.setEnabled(false);
		openAction.setEnabled(true);
		newAction.setEnabled(true);
	}	
	
	
	}
	
	/**
	 * Sets the preferred, minimum and maximum size of a button on the toolbar.
	 * This method is required since changing the look and feel caused undocumented
	 * size change of the buttons on the toolbar.
	 * @param object the JComponent that has to be resized
	 */
	private void setMySize(JComponent object) {
		int size = 28;
		Dimension dimension = new Dimension(size,size);
		
		object.setMinimumSize(dimension);
		object.setMaximumSize(dimension);
		object.setPreferredSize(dimension);
		object.setAlignmentY(Component.CENTER_ALIGNMENT);
		object.setAlignmentX(Component.CENTER_ALIGNMENT);
	}

}