package puzzled.actions;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import puzzled.ProblemSolver;
import puzzled.dialogs.AboutFrame;

/**
 * The AboutAction class is composed of a string and an icon, and is
 * added to the toolbar and menu bar.  It has the action performed method
 * that is called when the menu item or button is clicked.
 *
 * @author Fr�d�ric Demers
 * @author Guillaume Gilbert
 * @version 1.54
 */
public class AboutAction extends AbstractAction {
	ProblemSolver parent;
		
	public AboutAction(ProblemSolver parent_arg) {
		super("About",new ImageIcon("resources/inform.gif"));
		parent=parent_arg;
	}
	
	public void actionPerformed(ActionEvent e){
		AboutFrame myAboutFrame = new AboutFrame(parent);
		myAboutFrame.setVisible(true);
	}
}