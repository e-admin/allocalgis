package puzzled;

/**
 * This interface provide some usefull constants to the
 * whole application.  Classes needing to refer to these
 * constants can either implement this interface or refer
 * to the constants by using a call similar to 
 * Constants.VALUE_YES.
 */
public interface Constants {
	
	/** Value representing a definite match between two items.*/
	public static final int VALUE_YES=1;
	
	/** Value representing a definite non-match between two items.*/
	public static final int VALUE_NO=-1;
	
	/**
	 * Value representing that the relationship between two items
	 * is yet to be dicovered.
	 */
	public static final int VALUE_UNKNOWN=0;
	
	/**
	 * Value returned when looking for the category index or item
	 * index of an unexisting index.
	 */
	public static final int NOT_VALID=-3;

	public static final String[] IS_TOKENS = {new String("is"),
			new String("are"),
			new String("has"),
			new String("own"),
			new String("read"),
			new String("take"),
			new String("put"),
			new String("does"),
			new String("do"),
			new String("make"),
			new String("=")};

	public static final String[] NOT_TOKENS=  {new String("not"),
			new String("!=")};
	
	public static final String[] AND_TOKENS=  {new String("and"),
			new String("&&")};

	public static final String[] OR_TOKENS=  {new String("or"),
			new String("||")};


	public static final String[] LESS_TOKENS=  {new String("less"),
			new String("<")};

	public static final String[] MORE_TOKENS=  {new String("more"),
			new String(">")};

	public static final String[] NEXT_TOKENS=  {new String("next"),
			new String("~")};
	public static final String NOTNEXT_TOKEN=new String("!~");
	
	public static final String THAN_TOKEN= new String("than");
	public static final String TO_TOKEN= new String("to");

	public static final String NOR_TOKEN= new String("nor");

	
	public static final String RESET_TOKEN = new String("reset");
	
	public static final String PREVIOUS_CLUE_TOKEN = new String("[P]");
	


	public static final String[] NUMBER_TOKENS = {new String("one"),
			new String("two"),
			new String("three"),
			new String("four"),
			new String("five"),
			new String("six"),
			new String("seven"),
			new String("eight"),
			new String("nine"),
			new String("ten")};

	//these tokens are tested for in a special manner simply value constants
	public static final String JUNCTION_TOKEN= new String("junction");
	public static final String ACTION_TOKEN= new String("action");
	public static final String IS_TOKEN= new String("is");
	public static final String NUMBER_TOKEN= new String("number");
	public static final String NOT_TOKEN= new String("not");
	public static final String AND_TOKEN=new String("and");
	public static final String OR_TOKEN=new String("or");
	public static final String LESS_TOKEN=new String("less");
	public static final String MORE_TOKEN=new String("more");
	public static final String NEXT_TOKEN=new String("next");
	
	
	
	public static final int NO_ACTION=0;
	public static final int IS_ACTION=1;
	public static final int ISNOT_ACTION=2;	
	public static final int MORE_ACTION=3;	
	public static final int LESS_ACTION=4;
	public static final int OR_ACTION=5;
	public static final int NEXT_ACTION=6;
	public static final int NOTNEXT_ACTION=7;
}