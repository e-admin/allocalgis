package puzzled.grid;

/**
 * Used to signal that the grid file is invalid, that is cannot be casted into a
 * Grid object.
 *
 * @author Frederic Demers
 * @version 1.0, 3 February 1999
 */
	public class InvalidGridException extends Exception {

  /** Calls the superclass constructor.
   *  @param s Message describing the exception.
   */
  public InvalidGridException() {
    super("Not a valid logic problem file.");
  }
}