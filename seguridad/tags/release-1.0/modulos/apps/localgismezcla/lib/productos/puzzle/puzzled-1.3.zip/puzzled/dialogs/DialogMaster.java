package puzzled.dialogs;


import java.io.File;
import java.awt.Toolkit;
import javax.swing.*;
import puzzled.ProblemSolver;

/** 
 * This class contains the facility to prompt the user for various error, 
 * warning of confirmation messages.  These dialogs are prompted when an abormal
 * condition occurs.  This class is proposed with three constructor, allowing for
 * a maximum of flexibility in the information presented to the user.
 */
public class DialogMaster {
	
	/* Different constants representing the types of dialog boxes that
	 * can be displayed.
	 */
	public static final int CREATE=0;
	public static final int OVERWRITE=1;
	
	public static final int WARN_IO_SAVE=2;
	public static final int WARN_IO_CREATE=3;
	public static final int INVALID_FILE=4;

	public static final int SAVE=5;
	public static final int SAVING_ERROR=6;
	
	public static final int NUMBER_FORMAT=7;
	
	public static final int EMPTY_FIELD=9;

	
	public static final int NOTHING_TO_PRINT=15;
	public static final int PRINTER_ERROR=16;
	
	public static final int UNSUPPORTED_LAF=17;
	
	public static final int BAD_HELP_FILE_URL=18;

	
	private static ProblemSolver parent;
	
	public static void setParent(ProblemSolver parent_arg){
		parent = parent_arg;
	}
	
	/**
	 * Method used when no other typical information is required beside
	 * the type of the dialog box.
	 * @param type The type of message to be displayed
	 */
	static public int showDialog(int type) {
		switch (type) {
			case NOTHING_TO_PRINT:
				Toolkit.getDefaultToolkit().beep();
				JOptionPane.showMessageDialog(parent,
						"There is nothing to print.","Warning",
						JOptionPane.ERROR_MESSAGE);
				break;
			case PRINTER_ERROR:
				Toolkit.getDefaultToolkit().beep();
				JOptionPane.showMessageDialog(parent,
						"Printing impossible.  Ensure that your printer is online and connected","Warning",
						JOptionPane.ERROR_MESSAGE);
				break;
			case EMPTY_FIELD:
				Toolkit.getDefaultToolkit().beep();
				JOptionPane.showMessageDialog(parent,
					"Please ensure that all the fields are filled in.","Warning",
						JOptionPane.ERROR_MESSAGE);
				break;
		}
		return 0;
	}

	/**
	 * Method used to prompt the user when an abnormal condition happens
	 * during file operations.
	 * @param type The type of message to be displayed
	 * @param theFile A file reference used to identify the file originating the
	 *  			warning or error message.  
	 */
	static public int showDialog(int type, File theFile) {
		Toolkit.getDefaultToolkit().beep();
		switch(type) {
			case CREATE :
				Toolkit.getDefaultToolkit().beep();
				return JOptionPane.showConfirmDialog(parent,
							"File "+ theFile.getName() + " does not exist - create ?",
							"Create File",
							JOptionPane.YES_NO_OPTION);

			case OVERWRITE :
				Toolkit.getDefaultToolkit().beep();
				return JOptionPane.showConfirmDialog(parent,
							"File "+ theFile.getName() + " already exists - overwrite ?",
							"Overwrite File",
							JOptionPane.YES_NO_OPTION);

			case WARN_IO_CREATE :
				Toolkit.getDefaultToolkit().beep();
				JOptionPane.showMessageDialog(parent,
						"Cannot create file "+ theFile.getName()+".","Warning",
						JOptionPane.WARNING_MESSAGE);
				break;

			case SAVING_ERROR :
				Toolkit.getDefaultToolkit().beep();
				JOptionPane.showMessageDialog(parent,
						"File "+ theFile.getName()+" could not be saved.\n"+
							"Ensure the file is not marked read-only.","Warning",
						JOptionPane.ERROR_MESSAGE);
				break;

			case INVALID_FILE :
				Toolkit.getDefaultToolkit().beep();
				JOptionPane.showMessageDialog(parent,
						"Unknown file format - "+ theFile.getName()+ 
							" could not be loaded.","Reading Error",
						JOptionPane.ERROR_MESSAGE);
				Toolkit.getDefaultToolkit().beep();
				break;

			case SAVE :
				Toolkit.getDefaultToolkit().beep();
				return JOptionPane.showConfirmDialog(parent,
							"File "+ theFile.getName() + " has not been saved - save now ?",
							"Save File",
							JOptionPane.YES_NO_CANCEL_OPTION);
		}
	return 0;
	}
	
	/**
	 * Method used typically when a string can be passed as an additional mean
	 * of information.
	 * @param type The type of message to be displayed
	 * @param text A string of additional information to be displayed within
	 * 				the message.
	 */
	static public int showDialog(int type, String text) {
		switch(type) {
			case NUMBER_FORMAT:
				Toolkit.getDefaultToolkit().beep();
				JOptionPane.showMessageDialog(parent,
						"Invalid number entered: "+ text,"Warning",
						JOptionPane.ERROR_MESSAGE);
				break;
			case UNSUPPORTED_LAF:
				Toolkit.getDefaultToolkit().beep();
				JOptionPane.showMessageDialog(parent,
						"This look and feel is not supported by the platform: \n"
							+ text,"Warning",
						JOptionPane.ERROR_MESSAGE);
				break;
       case BAD_HELP_FILE_URL:
				Toolkit.getDefaultToolkit().beep();
				JOptionPane.showMessageDialog(parent,
						"There was a problem reading the help file. \n"
							+ text,"Warning",
						JOptionPane.ERROR_MESSAGE);
				break;
			default :
			}
	return 0;
	}
}	
	