package puzzled.grid;

/**
 * This class simply acts as a data structure to regroup
 * the essential elements of a relationship.  They include
 * a value, two X-coordinate components, and two Y-coordinate
 * components.  All its members are public, therefore modifiable
 * by any class, similar to a class like Point, where point.x and
 * point.y would be available, or Dimension, where dimension.width
 * and dimension.height would also be available.  It is here made
 * serializable such that it is possible in the future to save
 * information of this class on a disk.
 *
 * @author Fr�d�ric Demers
 * @version 1.0 1 Sep 99
 */
public class Relation implements java.io.Serializable{
	/**
	 * First category index of the relationship (the smaller
	 * of the two.)
	 */
	public int cat1;

	/**
	 * Second category index of the relationship (the larger
	 * of the two, cannot be the same as cat1.)
	 */
	public int cat2;
	
	/** item index associated with the first category. */
	public int item1;

	/** item index associated with the second category. */
	public int item2;

	/**
	 * value associated with the relationship, such as in the
	 * Constants interface.
	 */
	public int value;
	
	/**
	 * Constructor, takes in the parameter required for a relationship,
	 * but the coordinate components can be in any order, since a 
	 * sorting operation is completed before the affectation.
	 *
	 * @param value_arg the value given to this relation
	 * @param XCat one of the category index of the relation
	 * @param XItem one of the item index of the relation
	 * @param YCat the other category index of the relation
	 * @param YItem the other item index of the relation
	 */
	public Relation(int value_arg, int XCat, int XItem, int YCat, int YItem) {
		value=value_arg;
		
		sortCoordinates(XCat,XItem,YCat,YItem);
		//System.out.println("Cat1:"+cat1+" Cat2:"+cat2);
	}
	
	/**
	 * Sorting operation called when constructing the relationship.
	 * It ensures the smallest category index is first, this in order
	 * to use only the top right triangle of the Grid's square matrix
	 *
	 * @param XCat_arg first category index
	 * @param XItem_arg first item index
	 * @param YCat_arg second category index
	 * @param YItem_arg second item index
	 */
	public void sortCoordinates(int XCat_arg, int XItem_arg, int YCat_arg, int YItem_arg) {
		if (XCat_arg < YCat_arg) {
			cat1=XCat_arg;
			cat2=YCat_arg;
			item1=XItem_arg;
			item2=YItem_arg;
		} else {
			cat1=YCat_arg;
			cat2=XCat_arg;
			item1=YItem_arg;
			item2=XItem_arg;
		}
	}
	
	/**
	 * Method used when displaying a relationship at the screen, in
	 * the text format.  It is automatically implied when using
	 * a relationship in a println statement.
	 * @return a string representing the relationship
	 */
	public String toString() {
	 return ("Rel: ("+cat1+","+item1+") and ("+cat2+","+item2+")="+value);
	}
	
}