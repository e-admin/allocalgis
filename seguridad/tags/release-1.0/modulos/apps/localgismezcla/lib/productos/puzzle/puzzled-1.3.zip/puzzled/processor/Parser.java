package puzzled.processor;

import java.util.Vector;
import java.util.StringTokenizer;
import java.util.NoSuchElementException;
import puzzled.ProblemSolver;
import puzzled.Constants;
import puzzled.grid.Grid;
import puzzled.grid.Clue;


/**
 * This class is the part of the application that understand the
 * hints entered by the user.  Its role is to interpret the 
 * given hint and derive what relationships can be deduced out of
 * the statement.  It understand multiple subjects and objects,
 * and the following relationships:
 * is, is not, left of, right of.
 *
 * @author Fr�d�ric Demers
 * @version 1.0 10 Sep 2001
 */
public class Parser implements Constants {
	
	/** Value used by the parser to signify that the string sent
	 * is being decoded properly.*/
	public static final boolean STATUS_OK=true;
	
	/** Value used by the parser to signify that the string sent
	 * can no longer be understood.*/
	public static final boolean STATUS_NOK=false;
	
	/** Tokenizer object used to parse the hint string received.*/
	private StringTokenizer tokenizer;

	/* local reference to the Grid object */
	private Grid myGrid;
	
	/**
	 * In many cases there will be more than one subject in the clue
	 * The subjects are kept in the vector and then treated one by one.
	 */
	private Vector subjectVector = new Vector();
	
	/**
	 * In many cases there will be more than one object in the clue
	 * The objects are kept in the vector and then treated one by one.
	 */
	private Vector objectVector = new Vector();
	
	private boolean status=STATUS_OK;
	
	private int digitFound=0;
	
	private int specialCatIndex;
	
	private ProblemSolver parent;
	
	private boolean caseSensitive;
	
	/**
	 * This variable keeps a reference to the current clue being parsed.
	 *
	 */
	private Clue currentClue;

	
	
	/**
	 * Constructor.  Accepts a reference to the data structure (Grid object),
	 * in order to be able to add relationships, or retreive relationship
	 * information.
	 *
	 * @param myGrid_arg the reference to the data structure grid
	 */
	public Parser(ProblemSolver parent_arg) {
		parent=parent_arg;
		myGrid= parent.getGrid();
		caseSensitive=parent.getStatus().caseSensitive;
		//DEBUG
		//System.out.println("new parser being created");
	}
	
	/**
	 * This method will actually do the job of understanding user clues.
	 * 
	 * @param currentClue_arg the reference to the Clue object being studied
	 */
	public boolean parse(Clue currentClue_arg) {

		//this varable will contain the current token
		String currentToken = new String();
		
		int actionCode=NO_ACTION;
		digitFound=0;
		
		//several methods require access to the current clue
		currentClue=currentClue_arg;
		
		tokenizer = new StringTokenizer(currentClue.getClueText());
		try {
			currentToken = caseSensitive?tokenizer.nextToken():tokenizer.nextToken().toLowerCase();
			
			//until we can identify an actual item, keep adding tokens together
			//example Into the Fire
			//problems will happen if one item is Into the and another one is Into the Fire
			while (myGrid.getItemIndex(currentToken)==NOT_VALID) {
				currentToken+=(" "+(caseSensitive?tokenizer.nextToken():tokenizer.nextToken().toLowerCase()));
			}				

			//DEBUG
			//System.out.println("Token "+currentToken+" recognized");
			
			//first subject
			subjectVector.addElement(currentToken);
			
			//nexttoken is either an action token or a junction token
			currentToken = caseSensitive?tokenizer.nextToken():tokenizer.nextToken().toLowerCase();
			
			//while there are more subjects, else, we have an action code and skip
			while (is(currentToken,JUNCTION_TOKEN) && (status==STATUS_OK)) {

				//in the English language, nor means really "and not".
				if (is(currentToken, NOR_TOKEN)) actionCode=ISNOT_ACTION;
				
				//if the OR keyword is detected a special logic is implied (action should be IS)
				if (is(currentToken, OR_TOKEN)) actionCode=OR_ACTION;
								
				//first word of the next subject token
				currentToken = caseSensitive?tokenizer.nextToken():tokenizer.nextToken().toLowerCase();

				//until we can identify an actual item, keep adding tokens together
				while (myGrid.getItemIndex(currentToken)==NOT_VALID){
					currentToken+=(" "+(caseSensitive?tokenizer.nextToken():tokenizer.nextToken().toLowerCase()));
				}

				subjectVector.addElement(currentToken);

				//DEBUG
				//System.out.println("adding "+currentToken+" to the subjects");

				//next token could be another junction token or an action token
				currentToken= caseSensitive?tokenizer.nextToken():tokenizer.nextToken().toLowerCase();
			} //end while more subjects
			
			//DEBUG
			//System.out.println("after the junction tokens, current is "+currentToken);

			//else we have no action???
			if (is(currentToken, ACTION_TOKEN)) {

				// there may be several action tokens; example "is not"
				while (is(currentToken, ACTION_TOKEN) && status==STATUS_OK) {

					if (is(currentToken, IS_TOKEN)) {
						//we might already no it is a ISNOT_ACTION or OR_ACTION - then no change
						if ((actionCode!=ISNOT_ACTION) && (actionCode!=OR_ACTION)) actionCode=IS_ACTION;
					}
					
					if (is(currentToken, LESS_TOKEN))
						   	actionCode=LESS_ACTION;
							
					if (is(currentToken, MORE_TOKEN))
							 	actionCode=MORE_ACTION;

					if (is(currentToken, NOT_TOKEN)) 
								actionCode=ISNOT_ACTION;

					if (is(currentToken, NEXT_TOKEN)) actionCode=NEXT_ACTION;

					if (is(currentToken, NOTNEXT_TOKEN)) actionCode=NOTNEXT_ACTION;
													
					if (is(currentToken, NUMBER_TOKEN)){

						//inefficient routine to determine the value of the
						//word found in the clue.
						//there must be an easier way to retrieve the position of an
						//element in an array. Consider using Vector instead...
						for (int r=0;r<NUMBER_TOKENS.length;r++)
							if (((currentToken.toLowerCase()).equals(NUMBER_TOKENS[r])) ||
							//for shorthand, accept numeral in the clue text
						 		((currentToken.toLowerCase()).equals(Integer.toString(r+1)))) {
								digitFound=r+1;
								break;
							}
					}
					
					//get the next action token
					currentToken= caseSensitive?tokenizer.nextToken():tokenizer.nextToken().toLowerCase();
					
					//in this case, we need to go all the way past the THAN or TO
					if (actionCode==MORE_ACTION || actionCode==LESS_ACTION || actionCode==NEXT_ACTION || actionCode==NOTNEXT_ACTION){
						
						//DEBUG
						//System.out.println("MORE/LESS_ACTION - value "+digitFound);
						
						//finding the special category (category of comparison)
						//if the current token is not valid, keep adding tokens together
						while (myGrid.getCatIndex(currentToken)==NOT_VALID){
							currentToken+=(" "+(caseSensitive?tokenizer.nextToken():tokenizer.nextToken().toLowerCase()));
						} //end while
						
						specialCatIndex=myGrid.getCatIndex(currentToken);
						
						//DEBUG
						System.out.println("special category found:"+currentToken+" no.:"+specialCatIndex);
						
						//expecting a THAN or TO unless shorthand so if it is either, discard and get next
						currentToken=caseSensitive?tokenizer.nextToken():tokenizer.nextToken().toLowerCase();

						if (is(currentToken,THAN_TOKEN) || is(currentToken, TO_TOKEN)) currentToken=caseSensitive?tokenizer.nextToken():tokenizer.nextToken().toLowerCase();

					}// end if
				} //end while more action tokens
			
				//DEBUG	action should be definitely identified by now	
				System.out.println("ActionCode="+actionCode);
			} else status=STATUS_NOK; //no action code found
			
			//keep adding token until an item is found
			while (myGrid.getItemIndex(currentToken)==NOT_VALID) {
				currentToken+=(" "+(caseSensitive?tokenizer.nextToken():tokenizer.nextToken().toLowerCase()));
			}
			
			//DEBUG
			//System.out.println("Token "+currentToken+" recognized");

			//first object element
			objectVector.addElement(currentToken);
			
			currentToken = caseSensitive?tokenizer.nextToken():tokenizer.nextToken().toLowerCase();
			while (is(currentToken,JUNCTION_TOKEN) && (status==STATUS_OK)) {
				
				//the ISNOT relationship takes precedence
				if (is(currentToken, NOR_TOKEN)) actionCode=ISNOT_ACTION;
				
				//the OR relationship in the objects is treated as an OR in the subjects
				//in fact if the OR is discovered in a ISNOT sentence, it is effectively an
				// AND relationship  (my color is not white or red => red and white are not my color)
				if ((is(currentToken, OR_TOKEN)) && (actionCode!=ISNOT_ACTION)) actionCode=OR_ACTION;
				
				//trying to find more objects
				currentToken = caseSensitive?tokenizer.nextToken():tokenizer.nextToken().toLowerCase();

					//if item not recognized, it may be an item with more than one word
					while (myGrid.getItemIndex(currentToken)==NOT_VALID) {
						currentToken+=(" "+(caseSensitive?tokenizer.nextToken():tokenizer.nextToken().toLowerCase()));
					}
				objectVector.addElement(currentToken);

				//DEBUG
				//System.out.println("adding "+currentToken+" to the objects");
				currentToken = caseSensitive?tokenizer.nextToken():tokenizer.nextToken().toLowerCase();
			} //end while
		} catch (NoSuchElementException e) {
			status = STATUS_NOK;
		}
		if (status=STATUS_OK)
		{    
			//where we actually do something with the clue we parsed
			return (discover(actionCode));
		}
		else  { 
			//DEBUG
			System.out.println("Problems parsing the clue: "+currentClue.getClueText() );	
			return false;
		}	
		
	}
	
	/**
	 * This method creates all relationships from the parsed clue.  It receives as
	 * a parameter the type of action discovered by the parse method.
	 * other required information is shared with private member variables such as
	 * subject and object vectors, and the digitFound variable
	 */
	private boolean discover(int actionCode){
		String currentSubject = new String();
		String currentObject = new String();
		Vector tempoVec;
		int oldClueUsage=currentClue.getUsage(); //will allow us to find out if new information is discovered
		int itemNumber=myGrid.getItemNumber();
		int tempValue;
		//variable used for NEXT, NOTNEXT to keep track of possible positions
		boolean possiblePosn[] = new boolean [itemNumber];
		
		//to keep track of a value;
		int buffer, firstUnknown;
		
		
		switch (actionCode){
			case (NEXT_ACTION) :
			case (NOTNEXT_ACTION) :
				//swap vectors if i==1
				for (int i=0; i<2; i++)  {

					//fill table with false values
					for (int j=0; j<itemNumber;j++)
						possiblePosn[j]=false;
						
					//check if subject has a define relation then setSpecial(false);
					
					//swap vectors if i==1
					if (i==1) {
					 tempoVec = objectVector;
					 objectVector=subjectVector;
					 subjectVector=tempoVec;
					}

					//more than one object or subject not supported in this case
					currentSubject = (String)subjectVector.elementAt(0);
					currentObject = (String)objectVector.elementAt(0);

					// since in this case it is impossible to vector check
					// on the subject vector, or the object vector, what
					// has to be checked is the vector containing the subject
					// and the object so that if they are from a different cat
					// their relation is added.
					tempoVec = new Vector();
					tempoVec.addElement(currentSubject);
					tempoVec.addElement(currentObject);

					vectorCheck(tempoVec,ISNOT_ACTION);

					if (myGrid.checkAnswer(currentSubject,specialCatIndex)!=-1)  {
						currentClue.setSpecial(false);
						continue;
					} else currentClue.setSpecial(true);
					
					//testing all positions of the object vector
					if (myGrid.getRelation(
							myGrid.getCatIndex(currentObject),
							myGrid.getItemIndex(currentObject),
							specialCatIndex,0)!=VALUE_NO) possiblePosn[1]=true;
					
					for (int k=1;k<itemNumber-2;k++)  {
						
						if (myGrid.getRelation(
							myGrid.getCatIndex(currentObject),
							myGrid.getItemIndex(currentObject),
							specialCatIndex,k)!=VALUE_NO) {
							
							possiblePosn[k-1]=true;		
							possiblePosn[k+1]=true;		
						}
					}
					
					if (myGrid.getRelation(
							myGrid.getCatIndex(currentObject),
							myGrid.getItemIndex(currentObject),
							specialCatIndex,itemNumber-1)!=VALUE_NO) 
						
						possiblePosn[itemNumber-2]=true; 
					
					//now setting the positions on the subject vector with what is found
					for (int k=0; k<itemNumber;k++)  {
						if (((!(possiblePosn[k]))&&(actionCode==NEXT_ACTION)) 
							|| ((possiblePosn[k])&& (actionCode==NOTNEXT_ACTION))) 
							
						if (myGrid.addRelation(VALUE_NO,
							myGrid.getCatIndex(currentSubject),
							myGrid.getItemIndex(currentSubject),
							specialCatIndex,k)) currentClue.incUsage();
					
					} //for k
					 
				} //for i
				break;
			case (IS_ACTION) : 
			case (ISNOT_ACTION) : 
				
				//is it really?
				//does Peyton nor Chapman wrote Starburst mean that Peyton is not Chapman
				vectorCheck(subjectVector,actionCode);
				
				//is it really?
				//does Peyton is not Starburst nor fantasy mean that Starburst is not fantasy
				vectorCheck(objectVector,actionCode);
				
				for (int i=0; i<subjectVector.size(); i++) {
					currentSubject = (String)subjectVector.elementAt(i);

					for (int j=0; j<objectVector.size(); j++) {
						currentObject = (String)objectVector.elementAt(j);

						//if this clue provides additional information, add one to usage
						if (myGrid.addRelation((actionCode==IS_ACTION)?VALUE_YES:VALUE_NO,
							myGrid.getCatIndex(currentSubject),
							myGrid.getItemIndex(currentSubject),
							myGrid.getCatIndex(currentObject),
							myGrid.getItemIndex(currentObject))) currentClue.incUsage(); 
														
					}
				}
				break;	
			case (MORE_ACTION) : 
			case (LESS_ACTION) :	
				
				currentSubject = (String)subjectVector.elementAt(0);
				currentObject = (String)objectVector.elementAt(0);
				
				//first check if we already know the subject, before swapping
				//the vector, then we don't need to go on.
				if (myGrid.checkAnswer(currentSubject,specialCatIndex) >-1) {
					currentClue.setSpecial(false);
					break;
				}

				
				//MORE or LESS have the same logic, just swap the vectors
				//because the equal is not possible
				if (actionCode==LESS_ACTION)  {
					tempoVec=objectVector;
					objectVector=subjectVector;
					subjectVector=tempoVec;				
				}

				//more than one object or subject not supported in this case
				currentSubject = (String)subjectVector.elementAt(0);
				currentObject = (String)objectVector.elementAt(0);

				// since in this case it is impossible to vector check
				// on the subject vector, or the object vector, what
				// has to be checked is the vector containing the subject
				// and the object so that if they are from a different cat
				// their relation is added.
				tempoVec = new Vector();
				tempoVec.addElement(currentSubject);
				tempoVec.addElement(currentObject);

				vectorCheck(tempoVec,ISNOT_ACTION);
				


				//different logic if there is a digit in the clue
				//such as Z has two more pages than Y
								
				if (digitFound>0)  {
					for (int k= 0; k<itemNumber; k++)  {
						//DEBUG
						System.out.println(" k= "+k+" itemNumber= "+itemNumber);
						if (k < digitFound) {

							//DEBUG
							//System.out.println("loop where k<digitFound");							

							if (myGrid.addRelation(VALUE_NO,
							myGrid.getCatIndex(currentSubject),
							myGrid.getItemIndex(currentSubject),
							specialCatIndex,k)) currentClue.incUsage(); 
							
							if (myGrid.addRelation(VALUE_NO,
							myGrid.getCatIndex(currentObject),
							myGrid.getItemIndex(currentObject),
							specialCatIndex,itemNumber-1-k)) currentClue.incUsage(); 

						} else  {
							//DEBUG
							//System.out.println("loop where k>digitFound");							
							tempValue= myGrid.getRelation(
							myGrid.getCatIndex(currentObject),
							myGrid.getItemIndex(currentObject),
							specialCatIndex,k-digitFound); 

							if (myGrid.addRelation(tempValue,
							myGrid.getCatIndex(currentSubject),
							myGrid.getItemIndex(currentSubject),
							specialCatIndex,k)) currentClue.incUsage();
							
							if (tempValue==VALUE_YES)   {
								currentClue.setSpecial(false);
								break;
							}  

							tempValue= myGrid.getRelation(
							myGrid.getCatIndex(currentSubject),
							myGrid.getItemIndex(currentSubject),
							specialCatIndex,itemNumber-1-k+digitFound); 

							if (myGrid.addRelation(tempValue,
							myGrid.getCatIndex(currentObject),
							myGrid.getItemIndex(currentObject),
							specialCatIndex,itemNumber-1-k)) currentClue.incUsage();

							if (tempValue==VALUE_YES)   {
								currentClue.setSpecial(false);
								break;
							}  

						} //k<digit
					}	//for																
				
				
				//different logic if there is no digit in the clue
				//such as Z has more pages than Y
				} else  {
				
					if (myGrid.addRelation(VALUE_NO,
					myGrid.getCatIndex(currentSubject),
					myGrid.getItemIndex(currentSubject),
					specialCatIndex,0)) currentClue.incUsage(); 
					
					if (myGrid.addRelation(VALUE_NO,
					myGrid.getCatIndex(currentObject),
					myGrid.getItemIndex(currentObject),
					specialCatIndex,itemNumber-1)) currentClue.incUsage();
					
					//had to replicate the loops since the break statement
					for (int k=0; k < itemNumber-1; k++)  {
						//DEBUG
						//System.out.println("i= "+i+" j= "+j+" k= "+k+" itemNumber= "+itemNumber);
						
						if (myGrid.getRelation(
						myGrid.getCatIndex(currentObject),
						myGrid.getItemIndex(currentObject),
						specialCatIndex,k)==VALUE_NO)  {
							//DEBUG
							//System.out.println("Hey found one!");
							
							if (myGrid.addRelation(VALUE_NO,
							myGrid.getCatIndex(currentSubject),
							myGrid.getItemIndex(currentSubject),
							specialCatIndex,k+1)) currentClue.incUsage();
							//DEBUG
							//System.out.println("Hey made one!");  		
						} else break;

					} //for
					
					
					for (int k=0; k < itemNumber-1; k++)  {								

						if (myGrid.getRelation(
						myGrid.getCatIndex(currentSubject),
						myGrid.getItemIndex(currentSubject),
						specialCatIndex,itemNumber-1-k)==VALUE_NO)  {
							
							if (myGrid.addRelation(VALUE_NO,
							myGrid.getCatIndex(currentObject),
							myGrid.getItemIndex(currentObject),
							specialCatIndex,itemNumber-2-k)) currentClue.incUsage();
						} else break;
					
					} //for

				} // else digitFound
		
				//by setting this flag to true, a method in the parser
				//systematically reparse and reassess the clue each time
				currentClue.setSpecial(true);
				break;
			
			case (OR_ACTION) :
				//one of the object or subject vector should be one.  This will swap
				//the vectors if object has more than one.
				
				//by setting this flag to true, a method in the processor will ask
				//the clue be reparsed after each new entry.
				currentClue.setSpecial(true);
			
				if (objectVector.size()>1) 
				{
					tempoVec=objectVector;
					objectVector=subjectVector;
					subjectVector=tempoVec;
				}
				
				//if some subjects belong to different categories, new relations can be 
				//drawn
				vectorCheck(subjectVector,ISNOT_ACTION);
				
				currentObject = (String)objectVector.elementAt(0);

				//reset this value (-1 nothing found, -2 more than one unknown found)
				firstUnknown = -1;
				
				//look at all the alternatives to find if one has it, if so, set all others to no
				for (int i=0; i<subjectVector.size(); i++) {
					currentSubject = (String)subjectVector.elementAt(i);
					
					buffer = myGrid.getRelation(myGrid.getCatIndex(currentSubject),
									 myGrid.getItemIndex(currentSubject),
									 myGrid.getCatIndex(currentObject),
									 myGrid.getItemIndex(currentObject));
					if (buffer==VALUE_YES)  {
						//we found one true so we set all others to false
						for (int j=0; i<subjectVector.size(); i++)  {
							currentSubject = (String)subjectVector.elementAt(j);
							
							//skip the one found at the last step.. it's already at VALUE_YES
							if (myGrid.addRelation(VALUE_NO,
									myGrid.getCatIndex(currentSubject),
									myGrid.getItemIndex(currentSubject),
									myGrid.getCatIndex(currentObject),
									myGrid.getItemIndex(currentObject))) currentClue.incUsage();
						}
						//don't need to continue searching
						
						//once a VALUE_YES has been found, this clue need not to be reassessed
						currentClue.setSpecial(false);
						
						break;

					//can we find only one that is still unknown? if so, it's the winner
					} else if (buffer==VALUE_UNKNOWN)  {
						
						//still the first one?
						if (firstUnknown==-1) {
						 	firstUnknown = i;

						//there was one earlier so that's it, no luck
						} else  { 
							firstUnknown=-2;
							//there's still a chance that a VALUE_YES is found...
							continue; 
						}
					} //if buffer is either VALUE_YES or unknown


				} //for 
				
				//have we found only one
				if (firstUnknown>-1)  {
					currentSubject = (String)subjectVector.elementAt(firstUnknown);
					
					
					if (myGrid.addRelation(VALUE_YES,
							myGrid.getCatIndex(currentSubject),
							myGrid.getItemIndex(currentSubject),
							myGrid.getCatIndex(currentObject),
							myGrid.getItemIndex(currentObject))) currentClue.incUsage();

					//once a VALUE_YES has been determined,
					// this clue need not to be reassessed
					currentClue.setSpecial(false);
							
				}	//we found only one in the vector who was unknown	
				break;
				
				
	
		}	//end switch
		
		subjectVector.removeAllElements();
		objectVector.removeAllElements();
		return (currentClue.getUsage()>oldClueUsage); //we have gained information

	}
	
	/**
	 * The purpose of this method is to determine if another relationship
	 * can be drawn if subject elements or object elements are not
	 * in the same category.
	 */
	private void vectorCheck(Vector vect,int actionCode) {
		String element1;
		String element2;
		
		if (vect.size()>1)
			for (int i=0; i<vect.size(); i++) {
				element1 = (String)vect.elementAt(i);
				for (int j=i+1; j<vect.size(); j++)  {
					element2 = (String)vect.elementAt(j);
					if ((myGrid.getCatIndex(element1)!=myGrid.getCatIndex(element2))
						 && (actionCode==ISNOT_ACTION))
						if (myGrid.addRelation(VALUE_NO,
							myGrid.getCatIndex(element1),
							myGrid.getItemIndex(element1),
							myGrid.getCatIndex(element2),
							myGrid.getItemIndex(element2))) currentClue.incUsage();
				}
			}
	}
	
	
	/**
	 * This method allows to determine whether the token is
	 * a relevant token.  It performs the check with the proper
	 * token in lower case. It also
	 * performs more complicated checks to determine categories
	 */
	private boolean is(String word,String tokenID) {
			if (tokenID.equals(JUNCTION_TOKEN)) {
				// recursive checking...
				if (is(word,AND_TOKEN) || is(word,OR_TOKEN) ||is(word,NOR_TOKEN)) {

					//DEBUG
					//System.out.println("JUNCTION TOKEN: "+word);
					return true;
				}
				else {
					return false;
				}
			} else if (tokenID.equals(ACTION_TOKEN)) {
				if (is(word,IS_TOKEN) || is(word,NOT_TOKEN) ||
					is(word,THAN_TOKEN) || is(word,MORE_TOKEN) || is(word,LESS_TOKEN) ||
					is(word,NUMBER_TOKEN) || is(word,NEXT_TOKEN) ||
					is(word,NOTNEXT_TOKEN)) {
								//DEBUG
								//System.out.println("Action token found: "+word);
								return true;
				} else return false;
			}	else if (tokenID.equals(IS_TOKEN)){
					for (int r=0; r<IS_TOKENS.length; r++)
						if ((word.toLowerCase()).equals(IS_TOKENS[r]) ||
							   (word.toLowerCase().substring(0,word.length()-1)).equals(IS_TOKENS[r])) return true;
					return false;
			}	else if (tokenID.equals(NUMBER_TOKEN)){
					for (int r=0; r<NUMBER_TOKENS.length; r++)
						if (((word.toLowerCase()).equals(NUMBER_TOKENS[r])) ||
							//for shorthand, accept numeral in the clue text
						 ((word.toLowerCase()).equals(Integer.toString(r+1)))) return true;
					return false;
			}	else if (tokenID.equals(NOT_TOKEN)){
					for (int r=0; r<NOT_TOKENS.length; r++)
						if ((word.toLowerCase()).equals(NOT_TOKENS[r])) return true;
					return false;
			}	else if (tokenID.equals(AND_TOKEN)){
					for (int r=0; r<AND_TOKENS.length; r++)
						if ((word.toLowerCase()).equals(AND_TOKENS[r])) return true;
					return false;	
			}	else if (tokenID.equals(OR_TOKEN)){
					for (int r=0; r<OR_TOKENS.length; r++)
						if ((word.toLowerCase()).equals(OR_TOKENS[r])) return true;
					return false;
			}	else if (tokenID.equals(MORE_TOKEN)){
					for (int r=0; r<MORE_TOKENS.length; r++)
						if ((word.toLowerCase()).equals(MORE_TOKENS[r])) return true;
					return false;
			}	else if (tokenID.equals(LESS_TOKEN)){
					for (int r=0; r<LESS_TOKENS.length; r++)
						if ((word.toLowerCase()).equals(LESS_TOKENS[r])) return true;
					return false;
			}	else if (tokenID.equals(NEXT_TOKEN)){
					for (int r=0; r<NEXT_TOKENS.length; r++)
						if ((word.toLowerCase()).equals(NEXT_TOKENS[r])) return true;
					return false;
			} else {
					//DEBUG
					//System.out.println("result of is: "+(word.toLowerCase()).equals(tokenID));
					//in these cases, the word is simply compared to the TOKEN sent in the argument,
					// which must be a known constant.
					return (word.toLowerCase()).equals(tokenID);
				}
	}
	
}