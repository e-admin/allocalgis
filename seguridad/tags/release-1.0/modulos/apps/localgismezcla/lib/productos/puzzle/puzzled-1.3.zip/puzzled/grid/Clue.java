package puzzled.grid;

/**
 * This class simply acts as a data structure to represent
 * the clues entered by the user.  They contain the clue text,
 * the number of times they produced new information, and their
 * specialClue status, which is used for clues have a OR relationship 
 * in their text or having a MORE/LESS relationships.
 *
 * @author Fr�d�ric Demers
 * @version 1.0 26 Aug 2001
 */
public class Clue implements java.io.Serializable{

	/**
	 * Text of the clue as entered in the text box
	 */
	private String clueText;

	/**
	 * Variable containing the number of times this clue brought
	 * useful information to the puzzle.  Typically 1 for normal clues
	 * but possibly several for specialClues which are reassessed 
	 * several times.  It also provides the user the ability to discover
	 * a useless clue, which for problem creators, is essential information.
	 * although it largely depends on what order the clues are entered.  Indeed
	 * one clue (B) can provide two pieces of information, one of which is already
	 * known by and earlier clue (A).  Both will then have a "usage" greater than one, 
	 * but it can be later discovered that clue A is useless, if clue B is entered
	 * first.  There are no mechanism at this time to discover such thing.
	 * Possibly, an "optimize" function could try solving the puzzle with all possible
	 * clue order to determine if any clue is irrelevant.
	 */
	private int usage;
	
	/**
	 * Set to true if the clue is of a special status and needs to be reassessed
	 * several times.  The requirements for a clue to be special are the following:
	 * Subject and/or object vectors have mutiple items linked by OR_TOKEN; or
	 * there is the presence of a MORE/LESS relationship.
     */
	private boolean specialClue;

	/**
	 * Constructor, takes in the parameter required for a relationship,
	 *
	 * @param clueText the text string of the clue as entered in Puzzled
	 * @param usage the number of times this clue provided new information
	 * @param specialClue attribute given to clues needing periodical re-evaluation
	 */
	public Clue(String clueText_arg, int usage_arg,boolean specialClue_arg) {
		clueText = clueText_arg;
		usage = usage_arg;
		specialClue = specialClue_arg;
	}
	
	
	/**
	 * Method used when displaying the textual value of the clue
	 */
	public String toString() {
	 return ("Clue text: "+clueText+" usage: "+usage+(specialClue?" (special) ":" "));
	}
	
	public String getClueText()  {
		return clueText;
	}
	
	public int getUsage()  {
		return usage;
	}
	
	public void incUsage()  {
		usage++;
		System.out.println("Clue: "+clueText+" now has usage of: "+usage);
	}
	
	public void setSpecial(boolean newValue)  {
		specialClue = newValue;
		System.out.println("Clue: "+clueText+(newValue?" is now special":" is not special anymore"));
	}
	
	
	public boolean isSpecial()  {
		return specialClue;
	}
	
	
}