package puzzled.grid;

import java.awt.*;
import java.awt.event.*;
import java.awt.print.*;
import java.io.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.border.*;
import puzzled.*;

/**
 * The canvas class represent the graphical display of 
 * the grid, and the relationships between the various items.
 * A reference to an object of this class is kept by the Grid
 * object.
 *
 * @author Fr�d�ric Demers
 * @version 1.0 26 Aug 99
 */
public class GridCanvas extends JPanel implements Constants, Printable{
	
	
	ProblemSolver parent;
	Grid myGrid;
	
	/** see Grid class for an explanation of this variable.*/
	int catNumber,itemNumber,gridSize;
	
	/** see Grid class for an explanation of this variable.*/
	String categories[],items[][];
	
	/**
	 * A vector containing all the relationships between the
	 * items.  It is then used when drawing the component.
	 * It is more efficient than a loop at the beginning of the
	 * problem, but probably less efficient towards the end.
	 */
	private Vector relationsVector = new Vector();
	
	
	private final int CELL_WIDTH = 30;
	
	private final int CELL_HEIGHT = 20;
	
	/** The offset required for the side headers and items.*/
	private final int X_OFFSET = 200;
	
	/** The offset required for the top headers and items.*/
	private final int Y_OFFSET = 200;

	/** Values used for the determination of the screen coordinates.*/
  private int XCatPos=0, YCatPos=0, XItemPos=0, YItemPos=0;
			
	/**
	 * The size of the border that surrounds the grid.
	 * A translation is used at the end in order to obtain this 
	 * border.
	 */
	private final int BORDER = 10;
	
	/**
	 * Header Factor.  The header factor is the factor that
	 * multiplies the cell size in order to obtain the size of the
	 * space left for the headers.
	 */
	private final float H_FACTOR = 1.5f;
	
	/**
	 * Class constant representing the thick lines separating the 
	 * categories.
	 */
	private static final BasicStroke thickStroke = new BasicStroke(1.3f);

	/**
	 * Class constant representing the thick lines separating the 
	 * categories.
	 */
	private static final BasicStroke thinStroke = new BasicStroke(1f);
	
	/**
	 * Constructor.  Receive the required information as parameter,
	 * and creates the GridCanvas with the proper dimensions, which
	 * depend on the size of the problem.  The painting is automatical-
	 * ly called when added to the scrollpane, where the paintCompo-
	 * nent method is called.
	 * @param catNumber_arg The number of categories.
	 * @param itemNumber_arg The number of items per category.
	 * @param categories Array representing the names of the categories.
	 * @param items 2D array representing the names of the items.
	 */
	public GridCanvas(ProblemSolver parent_arg,Grid myGrid_arg) {
		/* setting the object variables from the constructor's parameters.*/
		parent = parent_arg;
		myGrid = myGrid_arg;
		catNumber=myGrid.getCatNumber();
		itemNumber=myGrid.getItemNumber();
		categories=myGrid.getCategories();
		items=myGrid.getItems();
		
		gridSize = (catNumber-1)*itemNumber;
		
		setLayout(null);
		
		/* The size depends on the number of items, categories, the
		 * OFFSETs and the BORDERs.
		 */
		setPreferredSize(new Dimension(gridSize*CELL_WIDTH+X_OFFSET+2*BORDER,
																		gridSize*CELL_HEIGHT+Y_OFFSET+2*BORDER));
		setBackground(Color.white);
	}
	
  /**
   * Draws the grid.  A series of for loops is being used after the
   * top and side headers are drawn.  Consideration is given for
   * the category separators with respect to thickness and color.
   * This method is called from the paintComponent method, which
   * passes its graphics (Graphics2D) context as a parameter.
   * It also paints the string representing the names of the
   * categories and the items.
   *
   * @param g2 The graphic contexts used to draw the grid.
   */
	public void drawGrid(Graphics2D g2) {
		/* We want a white empty border around the grid so the lines
		 * are all visible.
		 */
		g2.translate(BORDER,BORDER);
		
		g2.setStroke(thickStroke);
	
		//top headers - category boxes
    g2.setPaint(Color.blue.darker());
    g2.drawLine(X_OFFSET,0,gridSize*CELL_WIDTH+X_OFFSET,0);
    g2.drawLine(X_OFFSET,(int)(H_FACTOR*CELL_HEIGHT),gridSize*CELL_WIDTH+X_OFFSET,(int)(H_FACTOR*CELL_HEIGHT));
    
    //side headers - category boxes
    g2.drawLine(0,Y_OFFSET,0,Y_OFFSET+gridSize*CELL_HEIGHT);
    g2.drawLine((int)(H_FACTOR*CELL_WIDTH),Y_OFFSET,(int)(H_FACTOR*CELL_WIDTH),Y_OFFSET+gridSize*CELL_HEIGHT);
    
    //long horizontal - first full horizontal line
    g2.drawLine(0,Y_OFFSET,gridSize*CELL_WIDTH+X_OFFSET,Y_OFFSET);
    //long vertical - first full vertical line
    g2.drawLine(X_OFFSET,0,X_OFFSET,Y_OFFSET+gridSize*CELL_HEIGHT);
    
    //main grid
    for (int i= 1; i<=itemNumber; i++)
    	for (int j= 0; j < (catNumber-1);j++) {
    		if (i==itemNumber){
    			//separator: thicker blue line
    			g2.setPaint(Color.blue.darker());
    			g2.setStroke(thickStroke);
    		}
    		else {
    			g2.setPaint(Color.black);
    			g2.setStroke(thinStroke);
    		}
    		//horizontals
    		//separators start at 0, others at H_FACTOR*CELL_WIDTH
    		g2.drawLine((i==itemNumber)?0:(int)(H_FACTOR*CELL_WIDTH),//a longer line at each section
    			Y_OFFSET+i*CELL_HEIGHT+j*CELL_HEIGHT*itemNumber,
    			gridSize*CELL_WIDTH+X_OFFSET-j*CELL_WIDTH*itemNumber,
    			Y_OFFSET+i*CELL_HEIGHT+j*CELL_HEIGHT*itemNumber);
				
				//verticals
				//separators start at 0, others at H_FACTOR*CELL_HEIGHT
				g2.drawLine(X_OFFSET+i*CELL_WIDTH+j*CELL_WIDTH*itemNumber,
					(i==itemNumber)?0:(int)(H_FACTOR*CELL_HEIGHT), //a longer line at each section
					X_OFFSET+i*CELL_WIDTH+j*CELL_WIDTH*itemNumber,
					gridSize*CELL_HEIGHT+Y_OFFSET-j*CELL_HEIGHT*itemNumber);
    	}

		/* writing the categories and items*/
		g2.setFont(new Font("Helvetica",Font.PLAIN,10));
		g2.setPaint(Color.black);
		
		//top headers - category names
		for (int i=1; i<catNumber; i++)
			g2.drawString(categories[i],X_OFFSET+(i-1)*itemNumber*CELL_WIDTH+centerOffset(categories[i],itemNumber*CELL_WIDTH),CELL_HEIGHT);
    
    //side items - item names
    for (int i=0; i<(catNumber-1); i++)
    	for (int j=0; j<itemNumber; j++)
    		if (i==0)
    			g2.drawString(items[i][j],H_FACTOR*CELL_WIDTH+5,Y_OFFSET+i*itemNumber*CELL_HEIGHT+(j+1)*CELL_HEIGHT-2);
    		else 
    			g2.drawString(items[catNumber-i][j],H_FACTOR*CELL_WIDTH+5,Y_OFFSET+i*itemNumber*CELL_HEIGHT+(j+1)*CELL_HEIGHT-2);


		//side headers - these category names are read bottom to top
   	g2.translate(CELL_WIDTH,Y_OFFSET+gridSize*CELL_HEIGHT);
    g2.rotate(Math.toRadians(-90));
    
    for (int i=0; i<(catNumber-1); i++)
    		if (i==0)
    			g2.drawString(categories[i],(catNumber-2)*itemNumber*CELL_HEIGHT+centerOffset(categories[i],itemNumber*CELL_HEIGHT),0);
    		else
    			g2.drawString(categories[catNumber-i],(catNumber-i-2)*itemNumber*CELL_HEIGHT+centerOffset(categories[catNumber-i],itemNumber*CELL_HEIGHT),0);
		
		/* These next transformations are necessary so that the previous ones
		 * only affect the side headers, and not the top items as well.
		 * The next two transformations are the reverse of the previous
		 * two.
		 */
		g2.rotate(Math.toRadians(90));
		g2.translate(-CELL_WIDTH,-(Y_OFFSET+gridSize*CELL_HEIGHT));
		
		//top items - these item names are also read bottom to top
    g2.translate(X_OFFSET+24,Y_OFFSET-2);
    g2.rotate(Math.toRadians(-90));
    
    for (int i=1; i<catNumber; i++)
    	for (int j=0; j<itemNumber; j++)
    			g2.drawString(items[i][j],0,(i-1)*itemNumber*CELL_WIDTH+(j)*CELL_WIDTH);
		
  }
	
	/**
	 * Method used to determine the position of a string of text
	 * that needs to be centered, such as the category names.
	 *
	 * @param text The text string needing to be centered.
	 * @param space The total number of pixels available for this
	 *				text string.
	 */
	private int centerOffset(String text, int space) {
		//7.5 is an acceptable value for Helvetica 10
		return (int)((space-7.5*text.length())/2);
	}
	
	/**
	 * Overriden method which is invoked when the component needs
	 * to be repainted.  It involves a grid painting (drawGrid)
	 * following drawing of all the know relationships (contained
	 * in a vector.  (The other way would not work because of the
	 * multiple translations/rotations done in the drawGrid method.
	 *
	 * @param g The graphic context used to draw the grid.
	 */
	public void paintComponent(Graphics g) {
    super.paintComponent(g);
		Dimension d = getSize();
		
  	/* here is the little workaround to have the white background.
  	 * g.clearRect does not use the proper background color.
  	 */
  	Graphics2D g2 = (Graphics2D)g;
    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
    	 RenderingHints.VALUE_ANTIALIAS_ON);

  	g2.setBackground(Color.white);
  	g2.clearRect(0,0,d.width,d.height);
  	
  	//drawing the known relationships
  	if (parent.getStatus().displayRelations)
  		for (int i=0; i<relationsVector.size(); i++)
  			drawRelationship(g2, (Relation)relationsVector.elementAt(i));
  	
  	//drawing the grid
  	drawGrid(g2);
  }

	/**
   * Prints the current GridCanvas on the printer. In order to do so, we must
   * first find the upper left and lower right corners of the single line
   * diagram printed on this Woksheet. Then we scale the single line diagram
   * in both width and height, using the maximum scaling value for both, in
   * in order to keep the same aspect ratio. Once this is done, the single line
   * diagram is rotated 90 degress in order to be printed in landscape format.
   * we also have to move the diagram to the right by the same value as the
   * height.
   *
   * @param g    the graphics context
   * @param pf   the page format
   * @param pi   page index
   */
  public int print(Graphics g, PageFormat pf, int pi)
                                      throws PrinterException {
      // There is only one page so this check is ok
      if (pi >= 1) {
         return Printable.NO_SUCH_PAGE;
      }
			
			int drawingWidth = getSize().width;
			int drawingHeight = getSize().height;
      double scaleX=1d;
      double scaleY=1d;
  		double minScale=1d;
  		    
      if (drawingWidth > pf.getImageableHeight()) 
      	scaleX = pf.getImageableHeight()/drawingWidth;
      if (drawingHeight > pf.getImageableWidth()) 
      	scaleY = pf.getImageableWidth()/drawingHeight;
      
      minScale = Math.min(scaleX,scaleY);
      	
      Graphics2D g2 = (Graphics2D) g;
      
      g2.translate(pf.getImageableX(), pf.getImageableY());
      g2.translate(pf.getImageableWidth(),0);
      if (minScale < 1d) g2.scale(minScale,minScale);
      g2.rotate(Math.toRadians(90));
      
      Font f = new Font("Courier", Font.PLAIN, 12);
      g2.setFont (f);
			g2.setPaint(Color.black);
			g2.drawString(myGrid.getCurrentFile().getName(),
					(int)(pf.getImageableHeight()-
						20*(myGrid.getCurrentFile().getName().length())),10);

  	//drawing the known relationships
  	if (parent.getStatus().displayRelations)
  		for (int i=0; i<relationsVector.size(); i++)
  			drawRelationship(g2, (Relation)relationsVector.elementAt(i));
  	
  	//drawing the grid
  	drawGrid(g2);


	return Printable.PAGE_EXISTS;
  }

	
	/**
	 * Method used to draw a relationship given as parameter.
	 * The relation is given with a value a coordinates allowing
	 * to locate the exact location of the relationship symbol.
	 * A circle represent a definite match, and an X represent a 
	 * definite no-match.
	 *
	 * @param g2 The graphic context used to draw the symbol.
	 * @param rel The reference to the relation to be drawn.  See
	 * 				class Relation.
	 */
	public void drawRelationship(Graphics2D g2,Relation rel) {
		//to convert the relationship indexes in screen positions
			findPos(rel);
			
			if (rel.value==VALUE_NO){
			//draw an X
			g2.drawLine(X_OFFSET+BORDER+(XCatPos*itemNumber+XItemPos)*CELL_WIDTH+2,
				Y_OFFSET+BORDER+(YCatPos*itemNumber+YItemPos)*CELL_HEIGHT+2,
				X_OFFSET+BORDER+(XCatPos*itemNumber+XItemPos+1)*CELL_WIDTH-2,
				Y_OFFSET+BORDER+(YCatPos*itemNumber+YItemPos+1)*CELL_HEIGHT-2);
			g2.drawLine(X_OFFSET+BORDER+(XCatPos*itemNumber+XItemPos+1)*CELL_WIDTH-2,
				Y_OFFSET+BORDER+(YCatPos*itemNumber+YItemPos)*CELL_HEIGHT+2,
				X_OFFSET+BORDER+(XCatPos*itemNumber+XItemPos)*CELL_WIDTH+2,
				Y_OFFSET+BORDER+(YCatPos*itemNumber+YItemPos+1)*CELL_HEIGHT-2);
		} else if (rel.value==VALUE_YES)
			/* draw a circle (using the CELL_HEIGHT, which is smaller than
			 * the CELL_WIDTH.
			 */
			g2.drawOval(X_OFFSET+BORDER+(XCatPos*itemNumber+XItemPos)*CELL_WIDTH+(int)((CELL_WIDTH-CELL_HEIGHT)/2)+2,
				Y_OFFSET+BORDER+(YCatPos*itemNumber+YItemPos)*CELL_HEIGHT+2,
				CELL_HEIGHT-4,
				CELL_HEIGHT-4);
	}
	
	/**
	 * Method converting the relationship indexes into screen relative
	 * positions.  This is required because the categories on the 
	 * gridCanvas are not placed in order ( the vertical axis for example
	 * goes from zero to the catNumber-1 and back down to 1.
	 *
	 * @param rel the relationship needing to be converted
	 */
	private void findPos(Relation rel){
		if (rel.cat1==0) {
			XCatPos = rel.cat2-1;
			XItemPos = rel.item2;
			YCatPos = 0;
			YItemPos = rel.item1;
		} else {
			XCatPos = rel.cat1-1;
			XItemPos = rel.item1;
			YCatPos = catNumber-rel.cat2;
			YItemPos = rel.item2;
		}
	}
		
	
	/**
	 * Method used to add a relationship to the relationship vector.
	 * It is called by the grid's equivalent method, which takes care
	 * of the logical consequences.  This method is only responsible
	 * for representing the graphical symbol where appropriate.
	 * @param rel The relationship that needs to be represented.
	 */
	public void addRelation(Relation rel) {
		relationsVector.addElement(rel);
		/* Require a call to the repaint() method which calls the
		 * paintComponent() automatically.
		 */
		repaint();
	}
	
	
	/**
	 * Method used to remove all relations and redraw a plain grid.
	 */
	public void reset() {
		relationsVector.removeAllElements();
		repaint();
	}
}