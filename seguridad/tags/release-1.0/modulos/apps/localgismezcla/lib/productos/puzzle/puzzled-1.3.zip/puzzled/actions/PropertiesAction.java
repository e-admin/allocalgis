package puzzled.actions;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import puzzled.ProblemSolver;
import puzzled.dialogs.*;
import puzzled.grid.Grid;

/**
 * The PreferencesAction class is composed of a string and an icon,
 * and is added to the menu bar.  It has the action
 * performed method that is called when the menu item is clicked.
 *
 * @author Fr�d�ric Demers
 * @version 1.54
 */
public class PropertiesAction extends AbstractAction {
	private Grid grid;
	private ProblemSolver parent;
	private JPanel choicePanel;
	private ButtonGroup bg;
	//the first one for the category names, the array for the items 
	// in each category	
	private	JRadioButton categoryRB;
	private JRadioButton[] rbArray;
	
	public PropertiesAction(ProblemSolver parent_arg) {
		super("Properties...",new ImageIcon("resources/properties.gif"));
		parent = parent_arg;
	}
	
  public void actionPerformed(ActionEvent e) {
		DataPanel dataPanel;
		bg = new ButtonGroup();
		grid = parent.getGrid();
		
		if (grid.getCatNumber()==0) {
			ProblemConfig problemConfig = new ProblemConfig(parent, grid);
			if (problemConfig.showConfigDialog()) {
				parent.setStatusMessage("New file created");
				parent.refresh();
			}
		}

		
		createChoicePanel();
		
		int value = JOptionPane.showConfirmDialog(
			parent,
			choicePanel,
			"Problem Configuration:",
			JOptionPane.OK_CANCEL_OPTION,
			JOptionPane.PLAIN_MESSAGE
			);
		
		
		if (value==JOptionPane.CANCEL_OPTION) return;
		else {
			if (getSelectedItem()==DataPanel.CATEGORY_NAMES) {
				dataPanel = new DataPanel(grid,DataPanel.CATEGORY_NAMES);
				value = JOptionPane.showConfirmDialog(
					parent,
					dataPanel,
					"Category Names",
					JOptionPane.OK_CANCEL_OPTION,
					JOptionPane.PLAIN_MESSAGE
					);
				if (value==JOptionPane.OK_OPTION) {
					if (!dataPanel.allFieldsFilled()) {
						System.out.println("You must fill all the fields");
					} else {
						for (int i=0; i<grid.getCatNumber() ; i++)
							grid.setCategory(i,dataPanel.getString(i));
						parent.refresh();
					} //end else
				}	else return;
			} else { //items in one of the categories
			
				dataPanel = new DataPanel(grid,getSelectedItem());
				value = JOptionPane.showConfirmDialog(
					parent,
					dataPanel,
					"Item Names",
					JOptionPane.OK_CANCEL_OPTION,
					JOptionPane.PLAIN_MESSAGE
					);
				if (value==JOptionPane.OK_OPTION) {
					if (!dataPanel.allFieldsFilled()) {
						System.out.println("You must fill all the fields");
					} else {
						for (int i=0; i<grid.getItemNumber() ; i++) 
							grid.setItem(getSelectedItem(),i,dataPanel.getString(i));
						parent.refresh();
					} //end else
				}	else return; //end if
			} //end else a given category, not the category names
		}// end else OK_OPTION
  }
  
  private void createChoicePanel(){
  	int number = grid.getCatNumber();
  	
  	choicePanel = new JPanel();
  	
  	rbArray = new JRadioButton[number];
  	choicePanel.setLayout(new BoxLayout(choicePanel,BoxLayout.Y_AXIS));
  	choicePanel.setBorder(BorderFactory.createTitledBorder("Available choices"));
  	
  	categoryRB = new JRadioButton("Category names");
		categoryRB.setSelected(true);
  	choicePanel.add(categoryRB);
  	bg.add(categoryRB);
  	
  	for (int i=0; i<number; i++){
  		rbArray[i] = new JRadioButton("Items in "+grid.getCategory(i));
	  	choicePanel.add(rbArray[i]);
  		bg.add(rbArray[i]);
  	}
  	
  }
  
  private int getSelectedItem() {
  	if (categoryRB.isSelected()) return DataPanel.CATEGORY_NAMES;
  	for (int i=0; i<grid.getCatNumber(); i++)
  		if (rbArray[i].isSelected()) return i;
  	return 0;
  }
}