package puzzled;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

/**
 * The status panel is a panel that displays information about the
 * application at the bottom of the window.  This version allows a
 * message string and two other components.  It is inspired from 
 * the Tech Talk magazine Volume 2, Number 6, Java from the Trenches.
 * http://www.booksonline.com./techtalk/teche.html#java
 *
 * @author Fr�d�ric Demers
 * @version 1.0 27 Aug 99
 */
public class StatusPanel extends JPanel{
	JLabel statusMessage;
	JLabel modeMessage;
		//JLabel works better than JTextField in this case, since it is 
		// easier to prevent the selection of the text and the JLabel
	  // keeps the same LAF as the rest of the application, whereas
		// the JTextField takes a different look with the Windows LAF.

	/**
	 * Default constructor, calls the other constructor with a null parameter
	 */
  public StatusPanel()
  {
    this(null);
  	setText("");
  }

	/**
	 * Constructor which allows the addition of a JComponent as the third box
	 * @param a JComponent to be located in the third box
	 */
  public StatusPanel(JComponent thirdBox)
   {
     this.setLayout(new BorderLayout(2,2));
     JPanel eastPanel = new JPanel(new FlowLayout(FlowLayout.LEFT,2,0));
     this.setBorder(new SoftBevelBorder(BevelBorder.RAISED));
     statusMessage = new JLabel();
   	 statusMessage.setBorder(new EtchedBorder(EtchedBorder.LOWERED));
     this.add("Center", statusMessage);
     
     modeMessage = new JLabel();
     modeMessage.setBorder(new EtchedBorder(EtchedBorder.LOWERED));
   	 eastPanel.add(modeMessage);
	   
	   if (thirdBox == null)
       thirdBox = new SpaceCanvas();
     thirdBox.setBorder(new EtchedBorder(EtchedBorder.LOWERED));
     eastPanel.add(thirdBox);
     this.add("East", eastPanel);
   }

  /**
   * Method used to set the message string
   * @param sText message string
   */
  public void setText(String sText){
  	statusMessage.setText(sText);
  	/* This following line is needed to ensure the StatusBar is 
  	 * always displaying the right string.
  	 */
   	paintImmediately(0,0,getWidth(),getHeight());
  }

	/**
	 * Method returning the current message string.
	 * @return current message string
	 */
  public String getText(){
  	return statusMessage.getText();
  }

}//class StatusPanel

/** class creating an empty box when no third component is created. */
class SpaceCanvas extends JComponent{
	
	/**
	 * Method returning the minimumSize of this empty box
	 * @return the minimum dimensions
	 */
	public Dimension getMinimumSize(){
  	Dimension d = getParent().getSize();
    int w = 60, h = 20;
    if (d.height >  h)
    	h = d.height - 1;
    return new Dimension(w,h);
	}
  
	/**
	 * Method returning the minimumSize of this empty box
	 * @return the preferred dimensions
	 */
	public Dimension getPreferredSize() {
  	return getMinimumSize(); 
  }
}